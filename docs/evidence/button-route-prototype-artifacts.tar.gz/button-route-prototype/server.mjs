var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __esm = (fn, res, err) => function __init() {
  if (err) throw err[0];
  try {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  } catch (e) {
    throw err = [e], e;
  }
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// registry/cadence/code-highlight/highlight.tsx
var highlight_exports = {};
__export(highlight_exports, {
  highlightCode: () => highlightCode,
  loadHighlighter: () => loadHighlighter,
  resolveLanguage: () => resolveLanguage
});
import { createHighlighterCore } from "shiki/core";
import { createJavaScriptRegexEngine } from "shiki/engine/javascript";
import { jsx as jsx15 } from "react/jsx-runtime";
function getCore() {
  core ??= createHighlighterCore({
    themes: [
      import("shiki/themes/github-light-high-contrast.mjs"),
      import("shiki/themes/github-dark-high-contrast.mjs")
    ],
    // Languages load on demand in `loadHighlighter`; bundling them here would ship
    // thirteen grammars to a page that shows one.
    langs: [],
    engine: createJavaScriptRegexEngine({ forgiving: true })
  });
  return core;
}
function resolveLanguage(language) {
  const name = language.toLowerCase();
  if (name in languages) return name;
  return aliases[name] ?? null;
}
async function loadHighlighter(language) {
  const lang = resolveLanguage(language);
  if (!lang) return null;
  const shiki = await getCore();
  if (!shiki.getLoadedLanguages().includes(lang)) await shiki.loadLanguage(languages[lang]);
  return {
    highlight: (code, state) => {
      const result = shiki.codeToTokens(code, {
        lang,
        themes: { light: "github-light-high-contrast", dark: "github-dark-high-contrast" },
        defaultColor: false,
        grammarState: state
      });
      return {
        lines: result.tokens.map(
          (line) => line.map((token) => (
            // A token's offset in the source is unique within its line and survives
            // re-tokenization, which an array index does not.
            /* @__PURE__ */ jsx15("span", { className: tokenClass, style: token.htmlStyle, children: token.content }, token.offset)
          ))
        ),
        state: result.grammarState
      };
    }
  };
}
async function highlightCode(code, language) {
  const highlighter = await loadHighlighter(language);
  if (!highlighter) return null;
  return highlighter.highlight(code.endsWith("\n") ? code.slice(0, -1) : code).lines;
}
var languages, aliases, tokenClass, core;
var init_highlight = __esm({
  "registry/cadence/code-highlight/highlight.tsx"() {
    "use strict";
    languages = {
      bash: () => import("shiki/langs/shellscript.mjs"),
      css: () => import("shiki/langs/css.mjs"),
      diff: () => import("shiki/langs/diff.mjs"),
      html: () => import("shiki/langs/html.mjs"),
      javascript: () => import("shiki/langs/javascript.mjs"),
      json: () => import("shiki/langs/json.mjs"),
      jsx: () => import("shiki/langs/jsx.mjs"),
      markdown: () => import("shiki/langs/markdown.mjs"),
      python: () => import("shiki/langs/python.mjs"),
      sql: () => import("shiki/langs/sql.mjs"),
      tsx: () => import("shiki/langs/tsx.mjs"),
      typescript: () => import("shiki/langs/typescript.mjs"),
      yaml: () => import("shiki/langs/yaml.mjs")
    };
    aliases = {
      js: "javascript",
      md: "markdown",
      py: "python",
      sh: "bash",
      shell: "bash",
      shellscript: "bash",
      ts: "typescript",
      yml: "yaml",
      zsh: "bash"
    };
    tokenClass = "text-(--shiki-light) dark:text-(--shiki-dark)";
  }
});

// .cache/button-route-prototype/server.jsx
import { createElement as createElement3, isValidElement as isValidElement5, Fragment as Fragment43 } from "react";
import { renderToString } from "react-dom/server";

// .cache/button-route-prototype/link.jsx
import { createElement } from "react";
function PrototypeLink({ href, prefetch, replace, scroll, onClick, ...props }) {
  return createElement("a", { ...props, href, onClick(e) {
    onClick?.(e);
    if (!e.defaultPrevented && e.button === 0 && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey && href.startsWith("/") && !href.startsWith("/r/")) {
      e.preventDefault();
      window.__navigate(href, replace, scroll);
    }
  } });
}
var link_default = PrototypeLink;

// components/site/motion-mode.tsx
import { createContext as createContext3, useContext as useContext3, useEffect as useEffect4, useState as useState3 } from "react";

// registry/cadence/button/index.tsx
import { Button as ButtonPrimitive } from "@base-ui/react/button";
import { cva } from "class-variance-authority";

// registry/cadence/lib/cn.ts
import { clsx } from "clsx";
import { twMerge } from "tailwind-merge";
function cn(...inputs) {
  return twMerge(clsx(inputs));
}

// registry/cadence/lib/motion.ts
var duration = {
  instant: 0.1,
  fast: 0.16,
  base: 0.22,
  slow: 0.32,
  page: 0.45
};
var ease = {
  out: [0.22, 1, 0.36, 1],
  inOut: [0.65, 0, 0.35, 1],
  in: [0.7, 0, 0.84, 0]
};
var spring = {
  press: { type: "spring", visualDuration: 0.24, bounce: 0.12 },
  snappy: { type: "spring", visualDuration: 0.26, bounce: 0 },
  travel: { type: "spring", visualDuration: 0.3, bounce: 0 },
  smooth: { type: "spring", visualDuration: 0.4, bounce: 0 },
  morph: { type: "spring", visualDuration: 0.42, bounce: 0 }
};
var distance = { xs: 4, sm: 8, md: 12, lg: 24, xl: 48 };
var scale = { in: 0.96, pop: 1.02, press: 0.97 };
var carouselClock = { unitsPerSecond: 100 };
var reducedDurationScale = 0.6;
var VISUAL_SETTLE = 1.2;
function physicalSpring(visualDuration, bounce = 0) {
  if (!Number.isFinite(visualDuration) || visualDuration < 0)
    throw new RangeError("visualDuration must be finite and non-negative");
  if (visualDuration === 0) return { duration: 0 };
  const dampingRatio = Math.max(1 - bounce, 0.05);
  const undamped = 2 * Math.PI / (visualDuration * VISUAL_SETTLE);
  return {
    type: "spring",
    stiffness: undamped * undamped,
    damping: 2 * dampingRatio * undamped,
    mass: 1
  };
}
var recipes = {
  reveal: { kind: "tween", duration: duration.base, ease: ease.out },
  "enter.pop": { kind: "spring", spring: "snappy" },
  "exit.fade": { kind: "tween", duration: duration.fast, ease: ease.in },
  "exit.shrink": { kind: "tween", duration: duration.fast, ease: ease.in },
  "popup.anchored": { kind: "spring", spring: "smooth" },
  "layout.move": { kind: "spring", spring: "smooth", continuity: "velocity" },
  "layout.shared": { kind: "spring", spring: "morph", continuity: "velocity" },
  "list.stagger": { kind: "tween", duration: duration.base, ease: ease.out },
  "gesture.drag": { kind: "spring", spring: "snappy" },
  "scroll.progress": { kind: "spring", spring: "smooth" },
  "scroll.story": { kind: "tween", duration: duration.slow, ease: ease.out },
  "text.reveal": { kind: "tween", duration: duration.slow, ease: ease.out },
  "text.split": { kind: "tween", duration: duration.slow, ease: ease.out },
  "number.roll": { kind: "spring", spring: "snappy" },
  "data.transition": { kind: "tween", duration: duration.base, ease: ease.out },
  "state.morph": { kind: "spring", spring: "morph" },
  "geometry.resize": { kind: "spring", spring: "morph", continuity: "velocity", reduced: "jump" },
  handoff: { kind: "spring", spring: "travel", continuity: "velocity" },
  "feedback.press": { kind: "spring", spring: "press" }
};
function transitionFor(recipe, mode, options2 = {}) {
  if (mode === "none") return { duration: 0 };
  const timeScale = options2.timeScale ?? 1;
  if (!Number.isFinite(timeScale) || timeScale < 0) throw new RangeError("timeScale must be finite and non-negative");
  if (timeScale === 0) return { duration: 0, delay: 0 };
  const delay = (options2.delay ?? 0) * timeScale;
  const spec = recipes[recipe];
  if (spec.kind === "spring") {
    if (mode === "reduced") {
      if (spec.reduced === "jump") return { duration: 0, delay };
      return { duration: duration.fast * timeScale, ease: [...ease.out], delay };
    }
    const token = spring[spec.spring];
    const visualDuration = token.visualDuration * timeScale;
    if (spec.continuity === "velocity") return { ...physicalSpring(visualDuration, token.bounce), delay };
    return { ...token, visualDuration, delay };
  }
  const scaleFactor = mode === "reduced" ? reducedDurationScale : 1;
  return {
    duration: (options2.duration ?? spec.duration * scaleFactor) * timeScale,
    ease: [...spec.ease],
    delay
  };
}

// registry/cadence/lib/press-button.tsx
import { motion as motion3 } from "motion/react";
import { useCallback, useEffect as useEffect2, useLayoutEffect as useLayoutEffect2, useRef, useState } from "react";

// registry/cadence/lib/control-animation.tsx
import { cancelFrame, frame, motion as motion2, useAnimationControls } from "motion/react";
import { useEffect, useLayoutEffect } from "react";

// registry/cadence/lib/native-div.tsx
import { motion } from "motion/react";
import { jsx } from "react/jsx-runtime";
function NativeDiv({
  nativeEvents,
  nativeRef,
  ref,
  ...props
}) {
  const motionRef = useNativeMotionRef(ref, nativeRef);
  return /* @__PURE__ */ jsx("div", { ...props, ...nativeEvents, ref: motionRef });
}
var MotionNativeDiv = motion.create(NativeDiv);
function NativeMotionDiv({
  ref,
  onAnimationStart,
  onDrag,
  onDragStart,
  onDragEnd,
  ...props
}) {
  return /* @__PURE__ */ jsx(MotionNativeDiv, { ...props, nativeRef: ref, nativeEvents: { onAnimationStart, onDrag, onDragStart, onDragEnd } });
}

// registry/cadence/lib/control-animation.tsx
import { jsx as jsx2 } from "react/jsx-runtime";
var useCommittedEffect = typeof window === "undefined" ? useEffect : useLayoutEffect;
function useControlAnimation(target, transition) {
  const controls = useAnimationControls();
  const signature = JSON.stringify([target, transition]);
  useCommittedEffect(() => {
    controls.stop();
    const settle = () => controls.set(target);
    if (transition.duration === 0) {
      settle();
      frame.update(settle);
    } else void controls.start(target, transition);
    return () => {
      cancelFrame(settle);
      controls.stop();
    };
  }, [signature, controls]);
  return controls;
}
function ControlSpan({ target, transition, ...props }) {
  const controls = useControlAnimation(target, transition);
  return /* @__PURE__ */ jsx2(motion2.span, { ...props, initial: target, animate: controls });
}
function ControlDiv({ target, transition, ...props }) {
  const controls = useControlAnimation(target, transition);
  return /* @__PURE__ */ jsx2(motion2.div, { ...props, initial: target, animate: controls });
}
function NativeControlDiv({
  target,
  transition,
  ...props
}) {
  const controls = useControlAnimation(target, transition);
  return /* @__PURE__ */ jsx2(NativeMotionDiv, { ...props, initial: target, animate: controls });
}

// registry/cadence/lib/press-button.tsx
import { jsx as jsx3 } from "react/jsx-runtime";
var useCommittedEffect2 = typeof window === "undefined" ? useEffect2 : useLayoutEffect2;
function useNativeMotionRef(ref, nativeRef) {
  const node = useRef(null);
  const motionRef = useCallback(
    (instance) => {
      node.current = instance;
      if (typeof ref === "function") return ref(instance);
      if (ref) ref.current = instance;
    },
    [ref]
  );
  useCommittedEffect2(() => {
    const instance = node.current;
    if (!nativeRef || !instance) return;
    if (typeof nativeRef === "function") {
      const cleanup = nativeRef(instance);
      return () => {
        if (typeof cleanup === "function") cleanup();
        else nativeRef(null);
      };
    }
    nativeRef.current = instance;
    return () => {
      nativeRef.current = null;
    };
  }, [nativeRef]);
  return motionRef;
}
function NativeButton({
  nativeEvents,
  nativeRef,
  ref,
  ...props
}) {
  const motionRef = useNativeMotionRef(ref, nativeRef);
  return /* @__PURE__ */ jsx3("button", { ...props, ...nativeEvents, ref: motionRef });
}
var MotionNativeButton = motion3.create(NativeButton);
function PressButton({
  ref,
  onAnimationStart,
  onDrag,
  onDragStart,
  onDragEnd,
  whileTap,
  transition = {},
  ...props
}) {
  const [pressed, setPressed] = useState(false);
  const owner = useRef(null);
  const release = useCallback(() => {
    owner.current = null;
    setPressed(false);
  }, []);
  const disabled = props.disabled || props["aria-disabled"] === true || props["aria-disabled"] === "true";
  const enabled = !disabled && !!whileTap;
  useCommittedEffect2(() => {
    if (!pressed) return;
    const releasePointer = (event) => {
      if (event.isTrusted && event.pointerId === owner.current) release();
    };
    window.addEventListener("pointerup", releasePointer);
    window.addEventListener("pointercancel", releasePointer);
    return () => {
      window.removeEventListener("pointerup", releasePointer);
      window.removeEventListener("pointercancel", releasePointer);
    };
  }, [pressed, release]);
  useCommittedEffect2(() => {
    if (!enabled) release();
  }, [enabled, release]);
  const pressScale = typeof whileTap === "object" && "scale" in whileTap ? whileTap.scale : 1;
  const controls = useControlAnimation(
    { scale: pressed && !disabled && typeof pressScale === "number" ? pressScale : 1 },
    disabled || !whileTap ? { duration: 0 } : transition
  );
  return /* @__PURE__ */ jsx3(
    MotionNativeButton,
    {
      ...props,
      initial: false,
      animate: controls,
      onPointerDown: (event) => {
        props.onPointerDown?.(event);
        if (enabled && event.button === 0 && event.isPrimary && owner.current === null) {
          owner.current = event.pointerId;
          setPressed(true);
        }
      },
      onPointerUp: (event) => {
        props.onPointerUp?.(event);
        if (event.pointerId === owner.current) release();
      },
      onPointerCancel: (event) => {
        props.onPointerCancel?.(event);
        if (event.pointerId === owner.current) release();
      },
      onKeyDown: (event) => {
        props.onKeyDown?.(event);
        if (enabled && event.key === "Enter" && event.target === event.currentTarget && owner.current === null) {
          owner.current = "Enter";
          setPressed(true);
        }
      },
      onKeyUp: (event) => {
        props.onKeyUp?.(event);
        if (event.key === "Enter" && owner.current === "Enter") release();
      },
      onBlur: (event) => {
        props.onBlur?.(event);
        release();
      },
      nativeRef: ref,
      nativeEvents: { onAnimationStart, onDrag, onDragStart, onDragEnd }
    }
  );
}

// registry/cadence/lib/provider.tsx
import { MotionConfig } from "motion/react";
import { createContext, useContext, useSyncExternalStore } from "react";
import { jsx as jsx4 } from "react/jsx-runtime";
var REDUCED_QUERY = "(prefers-reduced-motion: reduce)";
function subscribeReducedMotion(onChange) {
  const query = window.matchMedia(REDUCED_QUERY);
  query.addEventListener("change", onChange);
  return () => query.removeEventListener("change", onChange);
}
function useSystemReducedMotion() {
  return useSyncExternalStore(
    subscribeReducedMotion,
    () => window.matchMedia(REDUCED_QUERY).matches,
    () => false
  );
}
var CadenceContext = createContext(null);
var FALLBACK_MODE = "full";
function createMotion(mode, timeScale = 1) {
  return {
    mode,
    reduced: mode !== "full",
    disabled: mode === "none",
    timeScale,
    transition: (recipe, options2) => transitionFor(recipe, mode, { timeScale, ...options2 }),
    distance,
    spring
  };
}
function CadenceProvider({ mode, timeScale, children, className }) {
  const parent = useContext(CadenceContext);
  const requested = mode ?? parent?.mode ?? FALLBACK_MODE;
  const scale2 = timeScale ?? parent?.timeScale ?? 1;
  const systemReduced = useSystemReducedMotion();
  if (!Number.isFinite(scale2) || scale2 < 0) throw new RangeError("timeScale must be finite and non-negative");
  const effective = requested === "none" ? "none" : systemReduced ? "reduced" : requested;
  const value = createMotion(effective, scale2);
  return /* @__PURE__ */ jsx4(CadenceContext.Provider, { value, children: /* @__PURE__ */ jsx4(
    MotionConfig,
    {
      reducedMotion: "user",
      transition: {
        duration: duration.base * scale2,
        ease: ease.out
      },
      children: /* @__PURE__ */ jsx4("div", { "data-motion": effective, className: cn("contents", className), children })
    }
  ) });
}
function useCadenceMotion() {
  const context = useContext(CadenceContext);
  const systemReduced = useSystemReducedMotion();
  return context ?? createMotion(systemReduced ? "reduced" : FALLBACK_MODE);
}

// registry/cadence/button/index.tsx
import { jsx as jsx5 } from "react/jsx-runtime";
var buttonVariants = cva(
  "group/button inline-flex shrink-0 select-none items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium outline-none transition-[color,background-color,border-color,box-shadow] ease-out focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 disabled:pointer-events-none disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        destructive: "bg-destructive text-white hover:bg-destructive/90 focus-visible:ring-destructive/20 dark:bg-destructive/60 dark:focus-visible:ring-destructive/40",
        outline: "border bg-background shadow-xs hover:bg-accent hover:text-accent-foreground dark:border-input dark:bg-input/30 dark:hover:bg-input/50",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground dark:hover:bg-accent/50",
        link: "text-primary underline-offset-4 hover:underline"
      },
      size: {
        default: "h-9 px-4 py-2 has-[>svg]:px-3",
        xs: "h-6 gap-1 rounded-md px-2 text-xs has-[>svg]:px-1.5 [&_svg:not([class*='size-'])]:size-3",
        sm: "h-8 gap-1.5 rounded-md px-3 has-[>svg]:px-2.5",
        lg: "h-10 rounded-md px-6 has-[>svg]:px-4",
        icon: "size-9",
        "icon-xs": "size-6 rounded-md [&_svg:not([class*='size-'])]:size-3",
        "icon-sm": "size-8",
        "icon-lg": "size-10"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
function Button({ className, variant = "default", size = "default", ...props }) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx5(
    ButtonPrimitive,
    {
      "data-slot": "button",
      "data-variant": variant,
      "data-size": size,
      "data-motion": cm.mode,
      className: typeof className === "function" ? (state) => cn(buttonVariants({ variant, size }), className(state)) : cn(buttonVariants({ variant, size }), className),
      render: /* @__PURE__ */ jsx5(
        PressButton,
        {
          whileTap: cm.reduced ? void 0 : { scale: scale.press },
          transition: cm.transition("feedback.press")
        }
      ),
      ...props
    }
  );
}

// registry/cadence/select/index.tsx
import { Select as SelectPrimitive } from "@base-ui/react/select";
import { CheckIcon, ChevronDownIcon, ChevronUpIcon } from "lucide-react";
import { animate, motion as motion4, useMotionValue, useTransform } from "motion/react";
import {
  Children,
  createContext as createContext2,
  isValidElement,
  useCallback as useCallback2,
  useContext as useContext2,
  useEffect as useEffect3,
  useLayoutEffect as useLayoutEffect3,
  useRef as useRef2,
  useState as useState2
} from "react";
import { createPortal } from "react-dom";

// registry/cadence/lib/geometry.ts
function measureOrigin(source, target) {
  return {
    x: source.left - target.left,
    y: source.top - target.top,
    scaleX: target.width > 0 ? source.width / target.width : 1,
    scaleY: target.height > 0 ? source.height / target.height : 1
  };
}
function clampMeasuredSize(value, min) {
  return Math.max(value, min);
}

// registry/cadence/lib/popup-style.ts
function stateClasses(base, value) {
  return typeof value === "function" ? (state) => cn(base, value(state)) : cn(base, value);
}
function popupStyle(cm, value) {
  const factor = (cm.disabled ? 0 : cm.reduced ? reducedDurationScale : 1) * cm.timeScale;
  const clock2 = Object.fromEntries(
    Object.entries(duration).map(([key, seconds]) => [`--motion-duration-${key}`, `${seconds * factor}s`])
  );
  return typeof value === "function" ? (state) => ({ ...clock2, ...value(state) }) : { ...clock2, ...value };
}
function popupClasses(cm, base, value) {
  const classes2 = cm.disabled ? base.split(" ").filter((part) => !part.includes(":opacity-0")).join(" ") : base;
  return stateClasses(
    cn(classes2, cm.disabled ? "transition-none" : cm.reduced ? "transition-opacity" : void 0),
    value
  );
}

// registry/cadence/select/index.tsx
import { Fragment, jsx as jsx6, jsxs } from "react/jsx-runtime";
var useIsomorphicLayoutEffect = typeof window === "undefined" ? useEffect3 : useLayoutEffect3;
var SelectContext = createContext2(null);
function collectLabels(children, labels = /* @__PURE__ */ new Map()) {
  Children.forEach(children, (child) => {
    if (!isValidElement(child)) return;
    if (child.type === SelectItem) {
      const item = child.props;
      if (item.value !== void 0) labels.set(item.value, item.children);
      return;
    }
    const nested = child.props.children;
    if (nested) collectLabels(nested, labels);
  });
  return labels;
}
function Select(props) {
  const [pending, setPending] = useState2(null);
  const [flying, setFlying] = useState2(false);
  const cancelled = useRef2(false);
  const labels = props.items ? null : collectLabels(props.children);
  const value = { pending, setPending, flying, setFlying, labels, cancelled };
  return /* @__PURE__ */ jsx6(SelectContext.Provider, { value, children: /* @__PURE__ */ jsx6(
    SelectPrimitive.Root,
    {
      ...props,
      onValueChange: (value2, details) => {
        props.onValueChange?.(value2, details);
        cancelled.current = details.isCanceled;
        if (details.isCanceled) setPending(null);
      }
    }
  ) });
}
function SelectValue({ className, ...props }) {
  const cm = useCadenceMotion();
  const context = useContext2(SelectContext);
  const hostRef = useRef2(null);
  const width = useMotionValue("auto");
  const target = useRef2(0);
  const floor = useRef2(0);
  const clock2 = JSON.stringify(cm.transition("geometry.resize"));
  const activeClock = useRef2(clock2);
  const rendered = useTransform(
    width,
    (value) => typeof value === "number" ? clampMeasuredSize(value, floor.current) : value
  );
  const formatter = props.children ?? (context?.labels ? (value) => {
    if (value == null || Array.isArray(value) && value.length === 0) return props.placeholder ?? null;
    if (Array.isArray(value)) return value.map((entry) => context.labels?.get(entry) ?? entry);
    return context.labels?.get(value) ?? value;
  } : void 0);
  useIsomorphicLayoutEffect(() => {
    const host = hostRef.current;
    if (!host) return;
    const measure = () => {
      const next = host.firstElementChild?.scrollWidth || host.scrollWidth;
      if (!next) return;
      const current = width.get();
      const transition = cm.transition("geometry.resize");
      const clockChanged = activeClock.current !== clock2;
      activeClock.current = clock2;
      if (current === "auto" || cm.reduced || transition.duration === 0) {
        floor.current = 0;
        const resting = cm.reduced ? "auto" : next;
        width.jump(resting);
        host.style.width = typeof resting === "number" ? `${resting}px` : resting;
        target.current = next;
        return;
      }
      floor.current = next < current ? next : 0;
      if (target.current === next && !clockChanged) return;
      target.current = next;
      animate(width, next, transition);
    };
    measure();
    const observer = new ResizeObserver(measure);
    if (host.firstElementChild) observer.observe(host.firstElementChild);
    return () => observer.disconnect();
  });
  useIsomorphicLayoutEffect(() => () => width.stop(), [width]);
  return /* @__PURE__ */ jsx6(
    motion4.span,
    {
      ref: hostRef,
      "data-slot": "select-value",
      "data-motion": cm.mode,
      style: { width: rendered, opacity: context?.flying ? 0 : 1 },
      className: "relative block min-w-0 overflow-hidden whitespace-nowrap",
      children: /* @__PURE__ */ jsx6(SelectPrimitive.Value, { ...props, className: stateClasses("block w-max", className), children: formatter })
    }
  );
}
function SelectTrigger({
  className,
  ref,
  size = "default",
  children,
  ...props
}) {
  const cm = useCadenceMotion();
  const context = useContext2(SelectContext);
  const triggerRef = useRef2(null);
  const mergedRef = useCallback2(
    (node) => {
      triggerRef.current = node;
      if (typeof ref === "function") {
        const cleanup = ref(node);
        return () => {
          triggerRef.current = null;
          if (cleanup) cleanup();
          else ref(null);
        };
      }
      if (ref) ref.current = node;
      return () => {
        triggerRef.current = null;
        if (ref) ref.current = null;
      };
    },
    [ref]
  );
  const [flight, setFlight] = useState2(null);
  useIsomorphicLayoutEffect(() => {
    if (!context?.pending) return;
    if (cm.reduced) {
      context.setPending(null);
      return;
    }
    const trigger = triggerRef.current;
    const slot = trigger?.querySelector('[data-slot="select-value"]');
    const text = slot?.firstElementChild;
    const rect = (text ?? slot)?.getBoundingClientRect();
    if (!rect?.width) {
      context.setPending(null);
      return;
    }
    setFlight({ origin: measureOrigin(context.pending.rect, rect), text: context.pending.text, rect });
    context.setFlying(true);
    context.setPending(null);
  }, [context, cm.reduced]);
  useIsomorphicLayoutEffect(() => {
    if (cm.reduced && flight) {
      setFlight(null);
      context?.setFlying(false);
    }
  }, [cm.reduced, flight, context]);
  const finish = () => {
    setFlight(null);
    context?.setFlying(false);
  };
  return /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsxs(
      SelectPrimitive.Trigger,
      {
        ref: mergedRef,
        "data-slot": "select-trigger",
        "data-size": size,
        "data-motion": cm.mode,
        className: stateClasses(
          cn(
            "relative flex h-9 w-fit items-center justify-between gap-2 overflow-hidden rounded-md border border-input bg-transparent px-3 pr-8 text-sm whitespace-nowrap shadow-xs transition-[color,box-shadow] outline-none select-none",
            "focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50",
            "disabled:cursor-not-allowed disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-destructive/20",
            "data-[placeholder]:text-muted-foreground data-[size=default]:h-9 data-[size=sm]:h-8",
            "[&_[data-placeholder]]:text-muted-foreground",
            "dark:bg-input/30 dark:hover:bg-input/50 dark:aria-invalid:ring-destructive/40"
          ),
          className
        ),
        ...props,
        children: [
          children,
          /* @__PURE__ */ jsx6(
            SelectPrimitive.Icon,
            {
              render: /* @__PURE__ */ jsx6(ChevronDownIcon, { className: "pointer-events-none absolute top-1/2 right-3 size-4 -translate-y-1/2 opacity-50" })
            }
          )
        ]
      }
    ),
    flight && typeof document !== "undefined" ? createPortal(/* @__PURE__ */ jsx6(SelectHandoff, { flight, onComplete: finish }), document.body) : null
  ] });
}
function SelectHandoff({
  flight,
  onComplete
}) {
  const cm = useCadenceMotion();
  const transition = cm.transition("handoff");
  const controls = useControlAnimation({ x: 0, y: 0 }, transition);
  useIsomorphicLayoutEffect(() => {
    if (transition.duration === 0) onComplete();
  }, [transition.duration, onComplete]);
  return /* @__PURE__ */ jsx6(
    motion4.span,
    {
      "aria-hidden": true,
      "data-motion": cm.mode,
      "data-slot": "select-handoff",
      initial: { x: flight.origin.x, y: flight.origin.y },
      animate: controls,
      onAnimationComplete: onComplete,
      style: {
        position: "fixed",
        left: flight.rect.left,
        top: flight.rect.top,
        width: flight.rect.width,
        height: flight.rect.height
      },
      className: "pointer-events-none z-[60] flex items-center overflow-hidden text-sm whitespace-nowrap",
      children: flight.text
    }
  );
}
function SelectContent({
  className,
  style,
  children,
  side = "bottom",
  sideOffset = 4,
  align = "center",
  alignOffset = 0,
  alignItemWithTrigger = true,
  ...props
}) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx6(SelectPrimitive.Portal, { children: /* @__PURE__ */ jsx6(
    SelectPrimitive.Positioner,
    {
      side,
      sideOffset,
      align,
      alignOffset,
      alignItemWithTrigger,
      className: "isolate z-50",
      children: /* @__PURE__ */ jsxs(
        SelectPrimitive.Popup,
        {
          "data-slot": "select-content",
          "data-motion": cm.mode,
          "data-align-trigger": alignItemWithTrigger,
          style: popupStyle(cm, style),
          className: popupClasses(
            cm,
            cn(
              "relative z-50 max-h-(--available-height) w-(--anchor-width) min-w-[8rem] origin-(--transform-origin) overflow-x-hidden overflow-y-auto rounded-md border bg-popover text-popover-foreground shadow-md outline-none",
              "transition-[opacity,scale] ease-cadence-out duration-(--motion-duration-fast) data-[ending-style]:opacity-0 data-[starting-style]:opacity-0",
              !cm.reduced && "data-[ending-style]:scale-(--motion-scale-in) data-[starting-style]:scale-(--motion-scale-in)"
            ),
            className
          ),
          ...props,
          children: [
            /* @__PURE__ */ jsx6(SelectScrollUpButton, {}),
            /* @__PURE__ */ jsx6(SelectPrimitive.List, { className: "p-1", children }),
            /* @__PURE__ */ jsx6(SelectScrollDownButton, {})
          ]
        }
      )
    }
  ) });
}
function SelectItem({ className, children, onClick, ...props }) {
  const cm = useCadenceMotion();
  const context = useContext2(SelectContext);
  return /* @__PURE__ */ jsxs(
    SelectPrimitive.Item,
    {
      "data-slot": "select-item",
      className: stateClasses(
        cn(
          "relative flex w-full cursor-default items-center gap-2 rounded-sm py-1.5 pr-8 pl-2 text-sm outline-hidden select-none",
          "data-highlighted:bg-accent data-highlighted:text-accent-foreground",
          "data-disabled:pointer-events-none data-disabled:opacity-50",
          "[&_svg]:pointer-events-none [&_svg]:shrink-0"
        ),
        className
      ),
      onClick: (event) => {
        onClick?.(event);
        if (event.defaultPrevented || context?.cancelled.current || event.currentTarget.hasAttribute("data-selected"))
          return;
        const text = event.currentTarget.querySelector('[data-slot="select-item-text"]');
        const rect = (text ?? event.currentTarget).getBoundingClientRect();
        context?.setPending({ rect, text: text?.textContent?.trim() ?? "" });
      },
      ...props,
      children: [
        /* @__PURE__ */ jsx6(SelectPrimitive.ItemText, { "data-slot": "select-item-text", className: "shrink-0 whitespace-nowrap", children }),
        /* @__PURE__ */ jsx6(
          SelectPrimitive.ItemIndicator,
          {
            keepMounted: true,
            render: (indicatorProps, state) => {
              const { className: indicatorClassName, ...rest } = indicatorProps;
              return /* @__PURE__ */ jsx6(
                ControlSpan,
                {
                  ...rest,
                  "data-slot": "select-item-indicator",
                  "data-motion": cm.mode,
                  className: cn("absolute right-2 flex size-3.5 items-center justify-center", indicatorClassName),
                  target: state.selected ? { opacity: 1, scale: 1 } : { opacity: 0, scale: cm.reduced ? 1 : scale.in },
                  transition: { ...cm.transition("state.morph"), ...cm.reduced ? { scale: { duration: 0 } } : {} },
                  children: /* @__PURE__ */ jsx6(CheckIcon, { className: "size-4" })
                }
              );
            }
          }
        )
      ]
    }
  );
}
function SelectScrollUpButton({ className, ...props }) {
  return /* @__PURE__ */ jsx6(
    SelectPrimitive.ScrollUpArrow,
    {
      "data-slot": "select-scroll-up-button",
      className: stateClasses(
        cn("sticky top-0 z-[1] flex w-full cursor-default items-center justify-center bg-popover py-1"),
        className
      ),
      ...props,
      children: /* @__PURE__ */ jsx6(ChevronUpIcon, { className: "size-4" })
    }
  );
}
function SelectScrollDownButton({ className, ...props }) {
  return /* @__PURE__ */ jsx6(
    SelectPrimitive.ScrollDownArrow,
    {
      "data-slot": "select-scroll-down-button",
      className: stateClasses(
        cn("sticky bottom-0 z-[1] flex w-full cursor-default items-center justify-center bg-popover py-1"),
        className
      ),
      ...props,
      children: /* @__PURE__ */ jsx6(ChevronDownIcon, { className: "size-4" })
    }
  );
}

// components/site/motion-mode.tsx
import { jsx as jsx7, jsxs as jsxs2 } from "react/jsx-runtime";
var MODE_KEY = "cadence-motion";
var SPEED_KEY = "cadence-motion-speed";
var MODES = ["full", "reduced", "none"];
var SPEEDS = [2, 1, 0.5, 0.25];
var MotionModeContext = createContext3(null);
function isMode(value) {
  return value === "full" || value === "reduced" || value === "none";
}
function parseSpeed(value) {
  const parsed = Number(value);
  return SPEEDS.includes(parsed) ? parsed : null;
}
function readStored(key) {
  try {
    return localStorage.getItem(key);
  } catch {
    return null;
  }
}
function MotionModeProvider({ children }) {
  const [mode, setModeState] = useState3("full");
  const [speed, setSpeedState] = useState3(1);
  useEffect4(() => {
    const params = new URLSearchParams(window.location.search);
    const fromUrl = params.get("motion");
    if (isMode(fromUrl)) {
      setModeState(fromUrl);
    } else {
      const stored = readStored(MODE_KEY);
      if (isMode(stored)) setModeState(stored);
    }
    const speedFromUrl = parseSpeed(params.get("speed"));
    if (speedFromUrl) {
      setSpeedState(speedFromUrl);
    } else {
      const stored = parseSpeed(readStored(SPEED_KEY));
      if (stored) setSpeedState(stored);
    }
  }, []);
  const setMode = (next) => {
    setModeState(next);
    try {
      localStorage.setItem(MODE_KEY, next);
    } catch {
    }
    const url = new URL(window.location.href);
    if (next === "full") url.searchParams.delete("motion");
    else url.searchParams.set("motion", next);
    window.history.replaceState(null, "", url);
  };
  const setSpeed = (next) => {
    setSpeedState(next);
    try {
      localStorage.setItem(SPEED_KEY, String(next));
    } catch {
    }
    const url = new URL(window.location.href);
    if (next === 1) url.searchParams.delete("speed");
    else url.searchParams.set("speed", String(next));
    window.history.replaceState(null, "", url);
  };
  const value = { mode, setMode, speed, setSpeed, timeScale: 1 / speed };
  return /* @__PURE__ */ jsx7(MotionModeContext.Provider, { value, children: /* @__PURE__ */ jsx7(CadenceProvider, { mode, timeScale: value.timeScale, children }) });
}
function useMotionMode() {
  return useContext3(MotionModeContext) ?? {
    mode: "full",
    setMode: () => {
    },
    speed: 1,
    setSpeed: () => {
    },
    timeScale: 1
  };
}
function MotionModeSwitch({ className }) {
  const { mode, setMode } = useMotionMode();
  return /* @__PURE__ */ jsx7(
    "fieldset",
    {
      "aria-label": "Motion mode",
      className: cn("hidden items-center gap-0.5 rounded-md border border-border p-0.5 sm:flex", className),
      children: MODES.map((value) => /* @__PURE__ */ jsx7(
        Button,
        {
          size: "xs",
          variant: mode === value ? "secondary" : "ghost",
          "aria-pressed": mode === value,
          onClick: () => setMode(value),
          className: "h-6 px-2 text-[11px] capitalize",
          children: value
        },
        value
      ))
    }
  );
}
function MotionSpeedSelect({ className }) {
  const { speed, setSpeed } = useMotionMode();
  return /* @__PURE__ */ jsxs2(
    Select,
    {
      value: String(speed),
      onValueChange: (value) => {
        const next = parseSpeed(value);
        if (next) setSpeed(next);
      },
      children: [
        /* @__PURE__ */ jsx7(
          SelectTrigger,
          {
            size: "sm",
            "aria-label": "Motion speed",
            title: "Playback speed for the whole site",
            className: cn("text-[11px]", className),
            children: /* @__PURE__ */ jsx7(SelectValue, {})
          }
        ),
        /* @__PURE__ */ jsx7(SelectContent, { align: "end", sideOffset: 6, alignItemWithTrigger: false, children: SPEEDS.map((value) => /* @__PURE__ */ jsxs2(SelectItem, { value: String(value), className: "text-xs", children: [
          value,
          "\xD7"
        ] }, value)) })
      ]
    }
  );
}

// components/site/theme-toggle.tsx
import { Moon, Sun } from "lucide-react";
import { useEffect as useEffect5, useState as useState4 } from "react";
import { jsx as jsx8 } from "react/jsx-runtime";
function ThemeToggle() {
  const [mounted, setMounted] = useState4(false);
  const [dark, setDark] = useState4(false);
  useEffect5(() => {
    const frame2 = requestAnimationFrame(() => {
      setDark(document.documentElement.classList.contains("dark"));
      setMounted(true);
    });
    return () => cancelAnimationFrame(frame2);
  }, []);
  const toggle = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.classList.toggle("dark", next);
    try {
      localStorage.setItem("cadence-theme", next ? "dark" : "light");
    } catch {
    }
  };
  return /* @__PURE__ */ jsx8(
    "button",
    {
      type: "button",
      onClick: toggle,
      "aria-label": "Toggle color theme",
      "aria-pressed": dark,
      className: "inline-flex size-8 items-center justify-center rounded-md border border-border text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
      children: mounted && dark ? /* @__PURE__ */ jsx8(Sun, { "aria-hidden": "true", className: "size-4" }) : /* @__PURE__ */ jsx8(Moon, { "aria-hidden": "true", className: "size-4" })
    }
  );
}

// components/site/header.tsx
import { jsx as jsx9, jsxs as jsxs3 } from "react/jsx-runtime";
function SiteHeader() {
  return /* @__PURE__ */ jsx9("header", { className: "sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur", children: /* @__PURE__ */ jsxs3("div", { className: "flex h-14 w-full items-center justify-between px-6", children: [
    /* @__PURE__ */ jsx9(
      link_default,
      {
        href: "/",
        className: "bg-linear-to-r from-brand-from to-brand-to bg-clip-text text-lg font-semibold tracking-tight text-transparent",
        children: "Cadence UI"
      }
    ),
    /* @__PURE__ */ jsxs3("nav", { "aria-label": "Main", className: "flex items-center gap-5 text-sm text-muted-foreground", children: [
      /* @__PURE__ */ jsx9(link_default, { className: "transition-colors hover:text-foreground", href: "/components", children: "Components" }),
      /* @__PURE__ */ jsx9(link_default, { className: "transition-colors hover:text-foreground", href: "/docs", children: "Docs" }),
      /* @__PURE__ */ jsx9("a", { className: "hidden transition-colors hover:text-foreground sm:inline", href: "/r/registry.json", children: "Registry" }),
      /* @__PURE__ */ jsx9("span", { "aria-hidden": "true", className: "hidden h-4 w-px bg-border sm:block" }),
      /* @__PURE__ */ jsx9(MotionModeSwitch, {}),
      /* @__PURE__ */ jsx9("span", { className: "hidden sm:contents", children: /* @__PURE__ */ jsx9(MotionSpeedSelect, {}) }),
      /* @__PURE__ */ jsx9(ThemeToggle, {})
    ] })
  ] }) });
}

// components/site/package-manager-preference.tsx
import { createContext as createContext4, useCallback as useCallback3, useContext as useContext4, useEffect as useEffect6, useState as useState5 } from "react";

// components/site/package-manager.ts
var INSTALL_FENCE = "install";
var PACKAGE_MANAGER_FENCE = "package-manager";
var PACKAGE_MANAGERS = [
  { value: "pnpm", label: "pnpm" },
  { value: "npm", label: "npm" },
  { value: "yarn", label: "yarn" }
];
var DEFAULT_PACKAGE_MANAGER = "pnpm";
var PACKAGE_MANAGER_KEY = "cadence-package-manager";
function isPackageManager(value) {
  return value === "pnpm" || value === "npm" || value === "yarn";
}
var ADD = /shadcn(?:@[\w.-]+)?\s+add\s+(\S+)/;
function installTarget(source) {
  return source.match(ADD)?.[1] ?? null;
}
var RUNNER = /^\s*(?:npx|pnpm\s+dlx|yarn\s+dlx|pnpx|bunx)\s+(\S+)((?:\s.*)?)$/;
var PACKAGES = /^\s*(?:pnpm\s+(?:add|install)|npm\s+(?:add|install|i)|yarn\s+add)\s+(\S.*)$/;
function commandLines(source) {
  return source.replace(/\n$/, "").split("\n");
}
function isPackageManagerLine(line) {
  return RUNNER.test(line) || PACKAGES.test(line);
}
function hasPackageManagerCommand(source) {
  return commandLines(source).some(isPackageManagerLine);
}
function restate(line, manager) {
  const runner = line.match(RUNNER);
  if (runner) {
    const [, binary, rest = ""] = runner;
    if (manager === "pnpm") return `pnpm dlx ${binary}${rest}`;
    if (manager === "npm") return `npx ${binary}${rest}`;
    return `yarn dlx ${binary}${rest}`;
  }
  const packages = line.match(PACKAGES);
  if (packages) {
    if (manager === "pnpm") return `pnpm add ${packages[1]}`;
    if (manager === "npm") return `npm install ${packages[1]}`;
    return `yarn add ${packages[1]}`;
  }
  return line;
}
function packageManagerCommands(source) {
  const lines = commandLines(source);
  if (!lines.some(isPackageManagerLine)) return [];
  return PACKAGE_MANAGERS.map(({ value, label: label2 }) => ({
    value,
    label: label2,
    command: lines.map((line) => restate(line, value)).join("\n")
  }));
}

// components/site/package-manager-preference.tsx
import { jsx as jsx10 } from "react/jsx-runtime";
var PackageManagerContext = createContext4(null);
function readStored2() {
  try {
    const stored = localStorage.getItem(PACKAGE_MANAGER_KEY);
    return isPackageManager(stored) ? stored : DEFAULT_PACKAGE_MANAGER;
  } catch {
    return DEFAULT_PACKAGE_MANAGER;
  }
}
function PackageManagerProvider({ children }) {
  const [manager, setManagerState] = useState5(DEFAULT_PACKAGE_MANAGER);
  useEffect6(() => {
    setManagerState(readStored2());
    const onStorage = (event) => {
      if (event.key !== PACKAGE_MANAGER_KEY) return;
      if (event.newValue === null) setManagerState(DEFAULT_PACKAGE_MANAGER);
      else if (isPackageManager(event.newValue)) setManagerState(event.newValue);
    };
    window.addEventListener("storage", onStorage);
    return () => window.removeEventListener("storage", onStorage);
  }, []);
  const setManager = useCallback3((next) => {
    setManagerState(next);
    try {
      localStorage.setItem(PACKAGE_MANAGER_KEY, next);
    } catch {
    }
  }, []);
  return /* @__PURE__ */ jsx10(PackageManagerContext.Provider, { value: { manager, setManager }, children });
}
function usePackageManager() {
  return useContext4(PackageManagerContext) ?? { manager: DEFAULT_PACKAGE_MANAGER, setManager: () => {
  } };
}

// app/layout.tsx
import { jsx as jsx11, jsxs as jsxs4 } from "react/jsx-runtime";
var metadata = {
  metadataBase: new URL("https://cadence.dev"),
  title: {
    default: "Cadence UI \u2014 animation-first components for shadcn",
    template: "%s \xB7 Cadence UI"
  },
  description: "Open source React components with motion built in. Base UI, Tailwind CSS v4, and Motion. Every component ships a motion contract and a reduced-motion branch.",
  openGraph: {
    title: "Cadence UI",
    description: "Animation-first React components for shadcn.",
    type: "website"
  }
};
var themeScript = `
(function () {
  try {
    var stored = localStorage.getItem("cadence-theme");
    var dark = stored ? stored === "dark" : window.matchMedia("(prefers-color-scheme: dark)").matches;
    document.documentElement.classList.toggle("dark", dark);
  } catch (e) {}
})();
`;
var noJavaScriptFallback = `
[data-document-entrance] {
  clip-path: none !important;
  filter: none !important;
  opacity: 1 !important;
  transform: none !important;
}
`;
function RootLayout({ children }) {
  return /* @__PURE__ */ jsxs4("html", { lang: "en", suppressHydrationWarning: true, children: [
    /* @__PURE__ */ jsxs4("head", { children: [
      /* @__PURE__ */ jsx11("script", { dangerouslySetInnerHTML: { __html: themeScript } }),
      /* @__PURE__ */ jsx11("noscript", { children: /* @__PURE__ */ jsx11("style", { children: noJavaScriptFallback }) })
    ] }),
    /* @__PURE__ */ jsxs4("body", { className: "min-h-dvh bg-background text-foreground antialiased", children: [
      /* @__PURE__ */ jsx11(
        "a",
        {
          href: "#content",
          className: "sr-only focus:not-sr-only focus:fixed focus:top-3 focus:left-3 focus:z-50 focus:rounded-md focus:border focus:border-border focus:bg-background focus:px-3 focus:py-2 focus:text-sm focus:font-medium",
          children: "Skip to content"
        }
      ),
      /* @__PURE__ */ jsx11(MotionModeProvider, { children: /* @__PURE__ */ jsxs4(PackageManagerProvider, { children: [
        /* @__PURE__ */ jsx11(SiteHeader, {}),
        /* @__PURE__ */ jsx11("main", { id: "content", children }),
        /* @__PURE__ */ jsx11("footer", { className: "mt-24 border-t border-border", children: /* @__PURE__ */ jsxs4("div", { className: "mx-auto flex max-w-6xl flex-col gap-2 px-6 py-10 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between", children: [
          /* @__PURE__ */ jsx11("p", { children: "Cadence UI \xB7 MIT licensed \xB7 Built with Base UI, Tailwind CSS v4, and Motion." }),
          /* @__PURE__ */ jsxs4("p", { children: [
            /* @__PURE__ */ jsx11("a", { className: "underline underline-offset-4 hover:text-foreground", href: "/llms.txt", children: "llms.txt" }),
            /* @__PURE__ */ jsx11("span", { className: "px-2", children: "\xB7" }),
            /* @__PURE__ */ jsx11("a", { className: "underline underline-offset-4 hover:text-foreground", href: "/r/registry.json", children: "registry" })
          ] })
        ] }) })
      ] }) })
    ] })
  ] });
}

// components/site/sidebar.tsx
import { ChevronDown } from "lucide-react";

// .cache/button-route-prototype/navigation.js
import { useSyncExternalStore as useSyncExternalStore2 } from "react";
function usePathname() {
  return useSyncExternalStore2((fn) => {
    window.addEventListener("prototype-navigation", fn);
    return () => window.removeEventListener("prototype-navigation", fn);
  }, () => location.pathname, () => globalThis.__prototypePath || "/components/button");
}
function notFound() {
  throw Error("Not found");
}

// components/site/sidebar.tsx
import { useId, useLayoutEffect as useLayoutEffect4, useRef as useRef4, useState as useState7 } from "react";

// components/site/reveal.tsx
import { useEffect as useEffect7, useRef as useRef3, useState as useState6 } from "react";
import { jsx as jsx12 } from "react/jsx-runtime";
function Reveal({ children, className }) {
  const cm = useCadenceMotion();
  const ref = useRef3(null);
  const [visible, setVisible] = useState6(true);
  useEffect7(() => {
    const node = ref.current;
    if (!node) return;
    const box = node.getBoundingClientRect();
    if (box.bottom > 0 && box.top < window.innerHeight) return;
    setVisible(false);
    const observer = new IntersectionObserver(([entry]) => {
      if (entry?.isIntersecting) {
        setVisible(true);
        observer.disconnect();
      }
    });
    observer.observe(node);
    return () => observer.disconnect();
  }, []);
  const show = cm.disabled || visible;
  const tween = cm.transition("reveal");
  const seconds = "duration" in tween ? Number(tween.duration ?? duration.base) : duration.base;
  return /* @__PURE__ */ jsx12(
    "div",
    {
      ref,
      onFocusCapture: () => setVisible(true),
      className,
      "data-motion": cm.mode,
      "data-site-reveal": true,
      style: {
        opacity: show ? 1 : 0,
        transform: cm.reduced || show ? "none" : `translateX(${distance.md}px) scale(${scale.in})`,
        filter: cm.reduced || show ? "none" : "blur(2px)",
        transition: cm.disabled || !show ? "none" : `${cm.reduced ? "opacity" : "opacity, transform, filter"}`.split(", ").map((property) => `${property} ${seconds}s cubic-bezier(${ease.out.join(",")})`).join(", ")
      },
      children
    }
  );
}

// components/site/sidebar.tsx
import { Fragment as Fragment2, jsx as jsx13, jsxs as jsxs5 } from "react/jsx-runtime";
var NOTHING_CLOSED = /* @__PURE__ */ new Set();
function isActive(pathname, href) {
  return pathname === href;
}
function NavLink({ href, title, active }) {
  return /* @__PURE__ */ jsx13(Reveal, { className: "origin-left", children: /* @__PURE__ */ jsx13(
    link_default,
    {
      href,
      "aria-current": active ? "page" : void 0,
      className: cn(
        "block rounded-md px-2 py-1.5 text-[13px] leading-5 transition-colors",
        active ? "bg-muted font-medium text-foreground" : "text-muted-foreground hover:bg-muted/60 hover:text-foreground"
      ),
      children: title
    }
  ) });
}
function DisclosureChevron({ open }) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx13(
    "span",
    {
      "aria-hidden": "true",
      className: "inline-flex shrink-0 text-muted-foreground/70 transition-colors group-hover/row:text-foreground",
      "data-motion": cm.mode,
      style: {
        transform: open ? "rotate(180deg)" : "rotate(0deg)",
        transition: cm.reduced ? "none" : `transform ${duration.base * cm.timeScale}s cubic-bezier(${ease.out.join(",")})`
      },
      children: /* @__PURE__ */ jsx13(ChevronDown, { className: "size-3.5", strokeWidth: 2.25 })
    }
  );
}
function DisclosureHeader({
  open,
  controls,
  onClick,
  label: label2,
  meta
}) {
  return /* @__PURE__ */ jsxs5(
    "button",
    {
      type: "button",
      onClick,
      "aria-expanded": open,
      "aria-controls": controls,
      className: "group/row flex w-full cursor-pointer items-center justify-between gap-2 rounded-md px-2 py-1.5 text-left transition-colors hover:bg-muted/60",
      children: [
        label2,
        /* @__PURE__ */ jsxs5("span", { className: "flex items-center gap-1", children: [
          meta,
          /* @__PURE__ */ jsx13(DisclosureChevron, { open })
        ] })
      ]
    }
  );
}
function Disclosure({ id, open, children }) {
  const cm = useCadenceMotion();
  const panel = useRef4(null);
  const inner = useRef4(null);
  useLayoutEffect4(() => {
    const node = panel.current;
    const content = inner.current;
    if (!node || !content) return;
    const measure = () => {
      const height = Math.max(0, content.getBoundingClientRect().height);
      if (height > 0) node.style.setProperty("--site-panel-height", `${height}px`);
    };
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(content);
    window.addEventListener("resize", measure);
    return () => {
      observer.disconnect();
      window.removeEventListener("resize", measure);
    };
  }, []);
  const fade = cm.transition("reveal");
  const opacityTime = "duration" in fade ? Number(fade.duration ?? 0) : 0;
  return /* @__PURE__ */ jsx13(
    "div",
    {
      ref: panel,
      id,
      "data-site-panel": true,
      "data-motion": cm.mode,
      "data-open": open,
      inert: !open,
      "aria-hidden": !open,
      style: {
        height: open ? "var(--site-panel-height, auto)" : 0,
        opacity: open ? 1 : 0,
        transition: cm.disabled ? "none" : `${cm.reduced ? "" : `height ${duration.slow * cm.timeScale}s cubic-bezier(${ease.out.join(",")}), `}opacity ${opacityTime}s cubic-bezier(${ease.out.join(",")})`
      },
      className: "overflow-hidden",
      children: /* @__PURE__ */ jsx13("div", { ref: inner, className: "flow-root", children })
    }
  );
}
function SectionLabel({ children, active }) {
  return /* @__PURE__ */ jsx13(
    "span",
    {
      className: cn(
        "text-[11px] leading-5 font-medium uppercase tracking-[0.14em] transition-colors group-hover/row:text-foreground",
        active ? "text-foreground" : "text-muted-foreground"
      ),
      children
    }
  );
}
function Groups({ groups, guides, pathname, isOpen, onToggle }) {
  const total = groups.reduce((count, group) => count + group.components.length, 0);
  const onIndex = pathname === "/components";
  const uid = useId();
  const panelId = (key) => `${uid}-${key}`;
  return /* @__PURE__ */ jsxs5("nav", { "aria-label": "Documentation", className: "flex flex-col gap-2", children: [
    /* @__PURE__ */ jsxs5("div", { children: [
      /* @__PURE__ */ jsx13(
        DisclosureHeader,
        {
          open: isOpen("docs"),
          controls: panelId("docs"),
          onClick: () => onToggle("docs"),
          label: /* @__PURE__ */ jsx13(SectionLabel, { children: "Docs" })
        }
      ),
      /* @__PURE__ */ jsx13(Disclosure, { id: panelId("docs"), open: isOpen("docs"), children: /* @__PURE__ */ jsx13("nav", { className: "flex flex-col gap-0.5 pt-1", "aria-label": "Docs", children: guides.map((guide) => /* @__PURE__ */ jsx13(
        NavLink,
        {
          href: `/docs/${guide.slug}`,
          title: guide.title,
          active: isActive(pathname, `/docs/${guide.slug}`)
        },
        guide.slug
      )) }) })
    ] }),
    /* @__PURE__ */ jsxs5("div", { children: [
      /* @__PURE__ */ jsx13(
        DisclosureHeader,
        {
          open: isOpen("components"),
          controls: panelId("components"),
          onClick: () => onToggle("components"),
          label: /* @__PURE__ */ jsx13(SectionLabel, { active: onIndex, children: "Components" }),
          meta: /* @__PURE__ */ jsx13(
            "span",
            {
              className: cn(
                "text-[11px] tabular-nums transition-colors group-hover/row:text-foreground",
                onIndex ? "text-foreground" : "text-muted-foreground"
              ),
              children: total
            }
          )
        }
      ),
      /* @__PURE__ */ jsx13(Disclosure, { id: panelId("components"), open: isOpen("components"), children: /* @__PURE__ */ jsx13("div", { className: "flex flex-col gap-5 pt-2", children: groups.map((group) => {
        const id = `group:${group.id}`;
        const open = isOpen(id);
        return /* @__PURE__ */ jsxs5("nav", { "aria-label": group.title, children: [
          /* @__PURE__ */ jsx13(
            DisclosureHeader,
            {
              open,
              controls: panelId(id),
              onClick: () => onToggle(id),
              label: /* @__PURE__ */ jsx13("span", { className: "text-[13px] leading-5 font-medium text-muted-foreground transition-colors group-hover/row:text-foreground", children: group.title }),
              meta: /* @__PURE__ */ jsx13("span", { className: "text-[11px] tabular-nums text-muted-foreground transition-colors group-hover/row:text-foreground", children: group.components.length })
            }
          ),
          /* @__PURE__ */ jsx13(Disclosure, { id: panelId(id), open, children: /* @__PURE__ */ jsx13("div", { className: "mt-1 ml-3 flex flex-col gap-0.5 border-l border-border pl-1", children: group.components.map((component) => /* @__PURE__ */ jsx13(
            NavLink,
            {
              href: `/components/${component.slug}`,
              title: component.title,
              active: isActive(pathname, `/components/${component.slug}`)
            },
            component.slug
          )) }) })
        ] }, group.id);
      }) }) })
    ] })
  ] });
}
function Sidebar({ groups, guides }) {
  const pathname = usePathname();
  const cm = useCadenceMotion();
  const [closed, setClosed] = useState7(NOTHING_CLOSED);
  const isOpen = (id) => !closed.has(id);
  const onToggle = (id) => {
    setClosed((previous) => {
      const next = new Set(previous);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };
  return /* @__PURE__ */ jsxs5(Fragment2, { children: [
    /* @__PURE__ */ jsxs5("details", { className: "group mb-6 rounded-xl border border-border px-3 py-2 md:hidden", children: [
      /* @__PURE__ */ jsxs5("summary", { className: "flex cursor-pointer list-none items-center justify-between py-1 text-sm font-medium", children: [
        "Browse",
        /* @__PURE__ */ jsx13(
          "span",
          {
            "aria-hidden": "true",
            "data-motion": cm.mode,
            className: "text-muted-foreground group-open:rotate-180",
            style: {
              transition: cm.reduced ? "none" : `rotate ${duration.base * cm.timeScale}s cubic-bezier(${ease.out.join(",")})`
            },
            children: "\u25BE"
          }
        )
      ] }),
      /* @__PURE__ */ jsx13("div", { className: "border-t border-border pt-4 pb-2", children: /* @__PURE__ */ jsx13(Groups, { groups, guides, pathname, isOpen, onToggle }) })
    ] }),
    /* @__PURE__ */ jsx13("aside", { className: "hidden w-56 shrink-0 md:block", children: /* @__PURE__ */ jsx13("div", { className: "no-scrollbar sticky top-14 max-h-[calc(100dvh-3.5rem)] overflow-y-auto py-10 pr-2", children: /* @__PURE__ */ jsx13(Groups, { groups, guides, pathname, isOpen, onToggle }) }) })
  ] });
}

// lib/content.ts
import { readdir, readFile } from "node:fs/promises";
import path from "node:path";
import matter from "gray-matter";
var BATCHES = [
  { id: "B1", title: "Atoms" },
  { id: "B2", title: "Structure and feedback" },
  { id: "B3", title: "Form controls" },
  { id: "B4", title: "Overlays" },
  { id: "B5", title: "Menus and selection" },
  { id: "B6", title: "Disclosure and collections" },
  { id: "B7", title: "Heavy data and navigation" },
  { id: "B8", title: "Compositions" },
  { id: "B9", title: "AI first" }
];
var contentRoot = path.join(process.cwd(), "content");
async function readDoc(file) {
  const raw = await readFile(file, "utf8");
  const { data, content } = matter(raw);
  return {
    ...data,
    slug: path.basename(file).replace(/\.mdx?$/, ""),
    body: content.trim()
  };
}
async function listComponents() {
  const registry = JSON.parse(await readFile(path.join(process.cwd(), "registry.json"), "utf8"));
  const dir = path.join(contentRoot, "components");
  const files = await readdir(dir);
  const docs = /* @__PURE__ */ new Map();
  for (const file of files) {
    if (!file.endsWith(".mdx")) continue;
    const doc = await readDoc(path.join(dir, file));
    docs.set(doc.slug, doc);
  }
  const components = [];
  for (const item of registry.items) {
    if (item.type !== "registry:ui" && item.type !== "registry:block") continue;
    const doc = docs.get(item.name);
    if (doc) components.push({ ...doc, batch: item.meta?.batch, categories: item.categories ?? [] });
  }
  return components;
}
async function listComponentGroups() {
  const components = await listComponents();
  const grouped = /* @__PURE__ */ new Map();
  for (const component of components) {
    const id = component.batch ?? "";
    grouped.set(id, [...grouped.get(id) ?? [], component]);
  }
  const known = new Set(BATCHES.map((batch) => batch.id));
  const groups = BATCHES.filter((batch) => grouped.has(batch.id)).map((batch) => ({
    id: batch.id,
    title: batch.title,
    components: grouped.get(batch.id) ?? []
  }));
  for (const [id, items] of grouped) {
    if (known.has(id)) continue;
    groups.push({ id, title: id ? `Batch ${id}` : "Unscheduled", components: items });
  }
  return groups;
}
async function getComponent(slug) {
  try {
    return await readDoc(path.join(contentRoot, "components", `${slug}.mdx`));
  } catch {
    return null;
  }
}
var guideOrder = [
  "installation",
  "theming",
  "motion",
  "motion-modes",
  "accessibility",
  "registry",
  "ai",
  "changelog"
];
var guideRank = (slug) => {
  const index = guideOrder.indexOf(slug);
  return index === -1 ? guideOrder.length : index;
};
async function listGuides() {
  const dir = path.join(contentRoot, "docs");
  const files = await readdir(dir);
  const docs = [];
  for (const file of files) {
    if (!file.endsWith(".mdx")) continue;
    docs.push(await readDoc(path.join(dir, file)));
  }
  return docs.sort((a, b) => guideRank(a.slug) - guideRank(b.slug));
}
async function getGuide(slug) {
  try {
    return await readDoc(path.join(contentRoot, "docs", `${slug}.mdx`));
  } catch {
    return null;
  }
}
async function getComponentSource(slug) {
  const payload = JSON.parse(await readFile(path.join(process.cwd(), "public", "r", `${slug}.json`), "utf8"));
  return payload.files;
}

// app/(site)/layout.tsx
import { jsx as jsx14, jsxs as jsxs6 } from "react/jsx-runtime";
async function SiteLayout({ children }) {
  const [groups, guides] = await Promise.all([listComponentGroups(), listGuides()]);
  return /* @__PURE__ */ jsxs6("div", { className: "flex w-full flex-col gap-8 px-6 md:flex-row", children: [
    /* @__PURE__ */ jsx14(Sidebar, { groups, guides }),
    /* @__PURE__ */ jsx14("div", { className: "min-w-0 flex-1", children })
  ] });
}

// registry/cadence/code-block/index.tsx
import { cva as cva2 } from "class-variance-authority";
import { CheckIcon as CheckIcon2, ChevronDownIcon as ChevronDownIcon2, CopyIcon } from "lucide-react";
import { animate as animate2, motion as motion5, useMotionValue as useMotionValue2, useTransform as useTransform2 } from "motion/react";
import * as React2 from "react";

// registry/cadence/code-highlight/use-highlighted-code.tsx
import * as React from "react";
var EMPTY = { language: "", text: "", lines: [] };
function useHighlightedCode(code, language) {
  const source = code.endsWith("\n") ? code.slice(0, -1) : code;
  const [loaded, setLoaded] = React.useState(null);
  const highlighter = loaded && loaded.language === language ? loaded.highlighter : null;
  React.useEffect(() => {
    if (!language) return;
    let cancelled = false;
    Promise.resolve().then(() => (init_highlight(), highlight_exports)).then((module) => module.loadHighlighter(language)).then((value) => {
      if (!cancelled) setLoaded({ language, highlighter: value });
    }).catch(() => {
      if (!cancelled) setLoaded({ language, highlighter: null });
    });
    return () => {
      cancelled = true;
    };
  }, [language]);
  const [cache, setCache] = React.useState(EMPTY);
  if (!highlighter || !language) return null;
  let next = cache;
  if (next.language !== language || !source.startsWith(next.text)) {
    next = { ...EMPTY, language };
  }
  const end = source.lastIndexOf("\n") + 1;
  if (end > next.text.length) {
    const chunk = highlighter.highlight(source.slice(next.text.length, end - 1), next.state);
    next = {
      language,
      text: source.slice(0, end),
      lines: [...next.lines, ...chunk.lines],
      state: chunk.state
    };
  }
  if (next !== cache) setCache(next);
  const tail = highlighter.highlight(source.slice(end), next.state).lines[0] ?? [];
  return [...next.lines, tail];
}

// registry/cadence/code-block/index.tsx
import { Fragment as Fragment3, jsx as jsx16, jsxs as jsxs7 } from "react/jsx-runtime";
var COPIED_RESET_MS = 2e3;
var scrollBar = [
  "[scrollbar-width:thin]",
  "[scrollbar-color:color-mix(in_oklab,var(--muted-foreground)_30%,transparent)_transparent]",
  "[&::-webkit-scrollbar]:size-2.5",
  "[&::-webkit-scrollbar-thumb]:rounded-full",
  "[&::-webkit-scrollbar-thumb]:bg-muted-foreground/30"
].join(" ");
var scrollStrip = "[scrollbar-width:none] [&::-webkit-scrollbar]:hidden";
var HOVER_QUERY = "(hover: hover)";
function subscribeHover(onChange) {
  const query = window.matchMedia(HOVER_QUERY);
  query.addEventListener("change", onChange);
  return () => query.removeEventListener("change", onChange);
}
function useCanHover() {
  return React2.useSyncExternalStore(
    subscribeHover,
    () => window.matchMedia(HOVER_QUERY).matches,
    () => true
  );
}
var useIsomorphicLayoutEffect2 = typeof window === "undefined" ? React2.useEffect : React2.useLayoutEffect;
var CodeBlockContext = React2.createContext(null);
var CodeBlockHeaderContext = React2.createContext(false);
var CodeBlockContentContext = React2.createContext(false);
var CodeBlockRevealContext = React2.createContext(true);
function idPart(value) {
  return value.replace(/[^a-zA-Z0-9_-]+/g, "-");
}
function useCodeBlockPart(part) {
  const block = React2.useContext(CodeBlockContext);
  if (!block) throw new Error(`${part} has to be rendered inside <CodeBlock>.`);
  return block;
}
function partIds(contentId, value) {
  const base = `${contentId}-${idPart(value)}`;
  return { tab: `${base}-tab`, panel: `${base}-panel`, content: `${base}-content` };
}
function firstTabValue(children) {
  let found;
  const visit = (nodes) => {
    React2.Children.forEach(nodes, (child) => {
      if (found || !React2.isValidElement(child)) return;
      if (child.type === CodeBlockTab) {
        if (child.props.value) found = child.props.value;
        return;
      }
      if (child.type === CodeBlockPanel) return;
      visit(child.props.children);
    });
  };
  visit(children);
  return found;
}
var codeBlockVariants = cva2(
  "group/code-block relative flex w-full min-w-0 flex-col overflow-hidden rounded-lg text-sm has-[[data-slot=code-block-content]:focus-visible]:ring-3",
  {
    variants: {
      variant: {
        default: "border border-input text-foreground has-[[data-slot=code-block-content]:focus-visible]:border-ring has-[[data-slot=code-block-content]:focus-visible]:ring-ring/50 dark:bg-input/30",
        destructive: "border border-destructive/30 text-destructive has-[[data-slot=code-block-content]:focus-visible]:border-destructive/40 has-[[data-slot=code-block-content]:focus-visible]:ring-destructive/20 dark:border-destructive/40"
      },
      size: {
        default: "",
        sm: "text-xs"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
function CodeBlock({
  className,
  variant = "default",
  size = "default",
  maxLines,
  expanded,
  defaultExpanded = false,
  onExpandedChange,
  language,
  defaultTab,
  tab,
  onTabChange,
  onPointerEnter,
  onPointerLeave,
  onFocus,
  onBlur,
  children,
  ...props
}) {
  const cm = useCadenceMotion();
  const canHover = useCanHover();
  const contentId = React2.useId();
  const [uncontrolledExpanded, setUncontrolledExpanded] = React2.useState(defaultExpanded);
  const [uncontrolledTab, setUncontrolledTab] = React2.useState(defaultTab);
  const [overflowing, setOverflowing] = React2.useState(false);
  const [hovered, setHovered] = React2.useState(false);
  const [focused, setFocused] = React2.useState(false);
  const isExpanded = expanded ?? uncontrolledExpanded;
  const activeTab = tab ?? uncontrolledTab ?? firstTabValue(children);
  const toggle = React2.useCallback(() => {
    const next = !isExpanded;
    if (expanded === void 0) setUncontrolledExpanded(next);
    onExpandedChange?.(next);
  }, [expanded, isExpanded, onExpandedChange]);
  const setTab = React2.useCallback(
    (next) => {
      if (tab === void 0) setUncontrolledTab(next);
      onTabChange?.(next);
    },
    [onTabChange, tab]
  );
  const value = React2.useMemo(
    () => ({
      contentId,
      maxLines,
      language,
      expanded: isExpanded,
      toggle,
      overflowing,
      setOverflowing,
      tab: activeTab,
      setTab
    }),
    [activeTab, contentId, isExpanded, language, maxLines, overflowing, setTab, toggle]
  );
  const revealed = !canHover || hovered || focused;
  return /* @__PURE__ */ jsx16(CodeBlockContext.Provider, { value, children: /* @__PURE__ */ jsx16(CodeBlockRevealContext.Provider, { value: revealed, children: /* @__PURE__ */ jsx16(
    "div",
    {
      "data-slot": "code-block",
      "data-variant": variant,
      "data-size": size,
      "data-motion": cm.mode,
      className: cn(codeBlockVariants({ variant, size }), className),
      onPointerEnter: (event) => {
        setHovered(true);
        onPointerEnter?.(event);
      },
      onPointerLeave: (event) => {
        setHovered(false);
        onPointerLeave?.(event);
      },
      onFocus: (event) => {
        setFocused(true);
        onFocus?.(event);
      },
      onBlur: (event) => {
        if (!event.currentTarget.contains(event.relatedTarget)) setFocused(false);
        onBlur?.(event);
      },
      ...props,
      children
    }
  ) }) });
}
function CodeBlockHeader({ className, ...props }) {
  return /* @__PURE__ */ jsx16(CodeBlockHeaderContext.Provider, { value: true, children: /* @__PURE__ */ jsx16(
    "div",
    {
      "data-slot": "code-block-header",
      className: cn(
        "flex min-w-0 shrink-0 items-center gap-2 border-b border-border px-4 py-3 text-muted-foreground group-data-[variant=destructive]/code-block:border-destructive/20 group-data-[variant=destructive]/code-block:text-destructive group-data-[size=sm]/code-block:px-3 group-data-[size=sm]/code-block:py-2",
        className
      ),
      ...props
    }
  ) });
}
function CodeBlockTitle({ className, ...props }) {
  return /* @__PURE__ */ jsx16(
    "div",
    {
      "data-slot": "code-block-title",
      className: cn(
        "min-w-0 truncate font-sans text-xs font-medium leading-6 text-foreground group-data-[variant=destructive]/code-block:text-destructive",
        "[&_svg]:pointer-events-none [&_svg]:me-1.5 [&_svg]:inline-block [&_svg]:align-middle [&_svg:not([class*='size-'])]:size-3.5",
        className
      ),
      ...props
    }
  );
}
function CodeBlockTabs({ ref, className, label: label2 = "Language", children, onKeyDown, ...props }) {
  const block = useCodeBlockPart("CodeBlockTabs");
  const listRef = React2.useRef(null);
  React2.useImperativeHandle(ref, () => listRef.current, []);
  const move = (step) => {
    const tabs = [...listRef.current?.querySelectorAll('[role="tab"]') ?? []];
    if (!tabs.length) return;
    const current = tabs.findIndex((tab) => tab.dataset.active !== void 0);
    const index = step === "first" ? 0 : step === "last" ? tabs.length - 1 : (current + step + tabs.length) % tabs.length;
    const next = tabs[index];
    if (!next?.dataset.value) return;
    block.setTab(next.dataset.value);
    next.focus();
  };
  return /* @__PURE__ */ jsx16(
    "div",
    {
      ref: listRef,
      role: "tablist",
      "aria-label": label2,
      "data-slot": "code-block-tabs",
      className: cn("flex min-w-0 items-center gap-0.5 overflow-x-auto", scrollStrip, className),
      onKeyDown: (event) => {
        onKeyDown?.(event);
        if (event.defaultPrevented) return;
        const forward = event.key === "ArrowRight" || event.key === "ArrowDown";
        const backward = event.key === "ArrowLeft" || event.key === "ArrowUp";
        const edge = event.key === "Home" || event.key === "End";
        if (!forward && !backward && !edge) return;
        event.preventDefault();
        if (event.key === "Home") move("first");
        else if (event.key === "End") move("last");
        else move(forward ? 1 : -1);
      },
      ...props,
      children
    }
  );
}
function CodeBlockTab({ value, className, children, onClick, ...props }) {
  const cm = useCadenceMotion();
  const block = useCodeBlockPart("CodeBlockTab");
  const active = block.tab === value;
  const ids2 = partIds(block.contentId, value);
  return /* @__PURE__ */ jsxs7(
    "button",
    {
      type: "button",
      role: "tab",
      id: ids2.tab,
      "aria-selected": active,
      "aria-controls": ids2.panel,
      tabIndex: active ? 0 : -1,
      "data-slot": "code-block-tab",
      "data-value": value,
      "data-active": active || void 0,
      "data-motion": cm.mode,
      className: cn(
        "relative inline-flex h-6 shrink-0 cursor-pointer items-center rounded-sm px-2 text-xs font-medium leading-6 text-muted-foreground outline-none transition-colors hover:text-foreground focus-visible:ring-[3px] focus-visible:ring-ring/50 data-[active]:text-foreground",
        className
      ),
      ...props,
      onClick: (event) => {
        onClick?.(event);
        block.setTab(value);
      },
      children: [
        active ? cm.reduced || cm.timeScale === 0 ? /* @__PURE__ */ jsx16(
          "span",
          {
            "aria-hidden": "true",
            "data-slot": "code-block-tab-indicator",
            "data-motion": cm.mode,
            className: "absolute inset-0 rounded-sm bg-muted"
          }
        ) : /* @__PURE__ */ jsx16(
          motion5.span,
          {
            "aria-hidden": "true",
            "data-slot": "code-block-tab-indicator",
            "data-motion": cm.mode,
            layoutId: cm.reduced ? void 0 : `${block.contentId}-tab-indicator`,
            transition: cm.reduced ? { duration: 0 } : cm.transition("layout.shared"),
            className: "absolute inset-0 rounded-sm bg-muted"
          }
        ) : null,
        /* @__PURE__ */ jsx16("span", { className: "relative z-10", children })
      ]
    }
  );
}
function CodeBlockActions({ className, children, ...props }) {
  const cm = useCadenceMotion();
  const inHeader = React2.useContext(CodeBlockHeaderContext);
  const revealed = React2.useContext(CodeBlockRevealContext);
  if (inHeader) {
    return /* @__PURE__ */ jsx16(
      "div",
      {
        "data-slot": "code-block-actions",
        className: cn("ms-auto flex shrink-0 items-center gap-1 -my-1 -me-1.5", className),
        ...props,
        children
      }
    );
  }
  return /* @__PURE__ */ jsx16(
    NativeControlDiv,
    {
      "data-slot": "code-block-actions",
      "data-motion": cm.mode,
      "data-revealed": revealed || void 0,
      target: { opacity: revealed ? 1 : 0 },
      transition: cm.transition("data.transition"),
      className: cn(
        "absolute end-3 top-3 z-10 flex shrink-0 items-center gap-1 group-data-[size=sm]/code-block:end-2 group-data-[size=sm]/code-block:top-2",
        // A floating control needs its own surface, or it reads as part of the code.
        "[&_button]:bg-background [&_button]:ring-1 [&_button]:ring-foreground/10",
        // Invisible but still tabbable: focusing it reveals the row again.
        !revealed && "pointer-events-none",
        className
      ),
      ...props,
      children
    }
  );
}
function CodeBlockCopyButton({
  value,
  values,
  className,
  variant = "ghost",
  size = "icon-xs",
  onClick,
  children,
  ...props
}) {
  const cm = useCadenceMotion();
  const block = React2.useContext(CodeBlockContext);
  const [copiedText, setCopiedText] = React2.useState(null);
  const text = values ? block?.tab ? values[block.tab] ?? "" : Object.values(values)[0] ?? "" : value ?? "";
  const copied = copiedText !== null && copiedText === text;
  React2.useEffect(() => {
    if (copiedText === null) return;
    const timeout = window.setTimeout(() => setCopiedText(null), COPIED_RESET_MS);
    return () => window.clearTimeout(timeout);
  }, [copiedText]);
  const swap = { ...cm.transition("state.morph"), ...cm.reduced ? { scale: { duration: 0 } } : {} };
  const tickOnly = cm.reduced;
  return /* @__PURE__ */ jsxs7(Fragment3, { children: [
    /* @__PURE__ */ jsx16(
      Button,
      {
        "data-slot": "code-block-copy-button",
        "data-copied": copied || void 0,
        "data-motion": cm.mode,
        variant,
        size,
        "aria-label": copied ? "Copied" : "Copy",
        className,
        ...props,
        onClick: (event) => {
          onClick?.(event);
          if (event.defaultPrevented) return;
          setCopiedText(null);
          if (!navigator.clipboard) {
            setCopiedText(false);
            return;
          }
          void navigator.clipboard.writeText(text).then(() => setCopiedText(text)).catch(() => setCopiedText(false));
        },
        children: children ?? /* @__PURE__ */ jsxs7("span", { "aria-hidden": "true", className: "grid place-items-center", children: [
          /* @__PURE__ */ jsx16(
            ControlSpan,
            {
              "data-motion": cm.mode,
              className: "col-start-1 row-start-1 flex",
              target: { opacity: copied ? 0 : 1, scale: copied && !tickOnly ? scale.in : 1 },
              transition: swap,
              children: /* @__PURE__ */ jsx16(CopyIcon, {})
            }
          ),
          /* @__PURE__ */ jsx16(
            ControlSpan,
            {
              "data-motion": cm.mode,
              className: "col-start-1 row-start-1 flex",
              target: { opacity: copied ? 1 : 0, scale: copied || tickOnly ? 1 : scale.in },
              transition: swap,
              children: /* @__PURE__ */ jsx16(CheckIcon2, {})
            }
          )
        ] })
      }
    ),
    /* @__PURE__ */ jsx16("span", { "aria-live": "polite", className: "sr-only", children: copiedText === false ? "Copy failed. Select and copy manually." : copied ? "Copied" : "" })
  ] });
}
function CodeBlockContent({
  ref,
  className,
  children,
  style,
  wrap = false,
  lineNumbers = false,
  startLine = 1,
  language: languageProp,
  id,
  ...props
}) {
  const cm = useCadenceMotion();
  const block = React2.useContext(CodeBlockContext);
  const preRef = React2.useRef(null);
  React2.useImperativeHandle(ref, () => preRef.current, []);
  const viewportRef = React2.useRef(null);
  const height = useMotionValue2(0);
  const floor = React2.useRef(0);
  const renderedHeight = useTransform2(height, (value) => clampMeasuredSize(value, floor.current));
  const [measured, setMeasured] = React2.useState(false);
  const maxLines = block?.maxLines;
  const language = languageProp ?? block?.language;
  const highlighted = useHighlightedCode(typeof children === "string" ? children : "", language);
  const expanded = block?.expanded ?? true;
  const folded = maxLines !== void 0 && !expanded;
  const setOverflowing = block?.setOverflowing;
  useIsomorphicLayoutEffect2(() => {
    const pre = preRef.current;
    if (!pre || maxLines === void 0) return;
    const measure = () => {
      const styles = window.getComputedStyle(pre);
      const lineHeight = Number.parseFloat(styles.lineHeight);
      const top = Number.parseFloat(styles.paddingTop);
      const full = pre.scrollHeight;
      const foldedHeight = Number.isFinite(lineHeight) ? top + Math.floor(lineHeight * maxLines) : full;
      const target = Math.min(folded ? foldedHeight : full, full);
      floor.current = Math.min(foldedHeight, full);
      setOverflowing?.(full - foldedHeight > 1);
      if (!measured || cm.transition("geometry.resize").duration === 0) {
        height.jump(target);
        if (viewportRef.current) viewportRef.current.style.height = `${target}px`;
        setMeasured(true);
        return;
      }
      animate2(height, target, cm.transition("geometry.resize"));
    };
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(pre);
    return () => observer.disconnect();
  }, [cm, folded, height, maxLines, measured, setOverflowing]);
  useIsomorphicLayoutEffect2(() => () => height.stop(), [height]);
  return /* @__PURE__ */ jsx16(
    motion5.div,
    {
      ref: viewportRef,
      "data-slot": "code-block-viewport",
      "data-motion": cm.mode,
      style: measured ? { height: renderedHeight } : void 0,
      className: "min-h-0 overflow-hidden",
      children: /* @__PURE__ */ jsx16(
        "pre",
        {
          ref: preRef,
          "data-slot": "code-block-content",
          "data-wrap": wrap || void 0,
          "data-numbered": lineNumbers || void 0,
          id: id ?? block?.contentId,
          dir: "ltr",
          tabIndex: 0,
          style: { counterReset: `line ${startLine - 1}`, ...style },
          className: cn(
            "min-h-0 min-w-0 overflow-auto px-4 py-3 font-mono leading-relaxed text-start outline-none",
            scrollBar,
            "group-data-[size=sm]/code-block:px-3 group-data-[size=sm]/code-block:py-2",
            wrap && "whitespace-pre-wrap break-words",
            className
          ),
          ...props,
          children: /* @__PURE__ */ jsx16(CodeBlockContentContext.Provider, { value: lineNumbers, children: /* @__PURE__ */ jsx16(
            "code",
            {
              "data-slot": "code-block-code",
              className: cn(
                "block content-start",
                // `min-w-max` is what makes a non-wrapping block scroll instead of
                // squeezing; it is also what would stop `wrap` from wrapping, because
                // the code box would still be as wide as its longest line.
                wrap ? "min-w-0" : "min-w-max",
                lineNumbers && "grid grid-cols-[auto_1fr] gap-x-3"
              ),
              children: typeof children === "string" && (highlighted || lineNumbers) ? (highlighted ?? children.replace(/\n$/, "").split("\n")).map((line, index) => (
                // biome-ignore lint/suspicious/noArrayIndexKey: a line's identity *is* its position; a stream appends, it never reorders
                /* @__PURE__ */ jsx16(CodeBlockLine, { children: line }, index)
              )) : children
            }
          ) })
        }
      )
    }
  );
}
function CodeBlockPanel({ value, className, ...props }) {
  const block = useCodeBlockPart("CodeBlockPanel");
  const ids2 = partIds(block.contentId, value);
  const selected = block.tab === void 0 || block.tab === value;
  return /* @__PURE__ */ jsx16(
    "div",
    {
      role: "tabpanel",
      id: ids2.panel,
      "aria-labelledby": ids2.tab,
      hidden: !selected,
      "data-slot": "code-block-panel",
      className: cn("min-w-0", className),
      children: /* @__PURE__ */ jsx16(CodeBlockContent, { id: ids2.content, ...props })
    }
  );
}
var codeBlockLineVariants = cva2(
  "relative block -mx-4 px-4 after:absolute after:start-1 after:top-0 after:select-none after:text-muted-foreground group-data-[size=sm]/code-block:-mx-3 group-data-[size=sm]/code-block:px-3",
  {
    variants: {
      variant: {
        default: "",
        added: "bg-muted after:content-['+']",
        removed: "bg-destructive/10 after:text-destructive after:content-['\u2212']",
        highlighted: "bg-muted"
      }
    },
    defaultVariants: {
      variant: "default"
    }
  }
);
function CodeBlockLine({ className, variant = "default", children, ...props }) {
  const numbered = React2.useContext(CodeBlockContentContext);
  const empty = children === void 0 || children === null || children === "" || Array.isArray(children) && !children.length;
  return /* @__PURE__ */ jsx16(
    "span",
    {
      "data-slot": "code-block-line",
      "data-variant": variant,
      className: cn(
        codeBlockLineVariants({ variant }),
        numbered && "col-span-2 grid grid-cols-subgrid [counter-increment:line] before:min-w-6 before:select-none before:text-end before:text-muted-foreground before:content-[counter(line)]",
        className
      ),
      ...props,
      children: /* @__PURE__ */ jsx16("span", { "data-slot": "code-block-line-content", className: "min-w-0", children: empty ? "\n" : children })
    }
  );
}
function CodeBlockFooter({ className, ...props }) {
  return /* @__PURE__ */ jsx16(
    "div",
    {
      "data-slot": "code-block-footer",
      className: cn(
        "flex min-w-0 shrink-0 items-center gap-2 border-t border-border px-4 py-3 text-muted-foreground group-data-[variant=destructive]/code-block:border-destructive/20 group-data-[size=sm]/code-block:px-3 group-data-[size=sm]/code-block:py-2",
        className
      ),
      ...props
    }
  );
}
function CodeBlockExpandButton({ className, children, onClick, ...props }) {
  const cm = useCadenceMotion();
  const block = React2.useContext(CodeBlockContext);
  if (!block || block.maxLines === void 0 || !block.overflowing) return null;
  const { expanded, toggle, contentId, tab } = block;
  const controls = tab ? partIds(contentId, tab).panel : contentId;
  return /* @__PURE__ */ jsxs7(
    Button,
    {
      type: "button",
      "data-slot": "code-block-expand-button",
      "data-motion": cm.mode,
      variant: "ghost",
      size: "xs",
      "aria-expanded": expanded,
      "aria-controls": controls,
      className: cn("gap-1 text-muted-foreground", className),
      ...props,
      onClick: (event) => {
        onClick?.(event);
        toggle();
      },
      children: [
        children ?? (expanded ? "Show less" : "Show all"),
        /* @__PURE__ */ jsx16(
          ControlSpan,
          {
            "data-motion": cm.mode,
            "aria-hidden": "true",
            className: "flex",
            target: { rotate: expanded ? 180 : 0 },
            transition: cm.reduced ? { duration: 0 } : cm.transition("state.morph"),
            children: /* @__PURE__ */ jsx16(ChevronDownIcon2, {})
          }
        )
      ]
    }
  );
}

// components/site/fence.ts
import { isValidElement as isValidElement3 } from "react";
var LANGUAGE_CLASS = /language-([\w+#.-]+)/;
var TITLES = {
  bash: "Terminal",
  css: "CSS",
  diff: "Diff",
  html: "HTML",
  javascript: "JavaScript",
  js: "JavaScript",
  json: "JSON",
  jsx: "JSX",
  markdown: "Markdown",
  md: "Markdown",
  python: "Python",
  py: "Python",
  sh: "Terminal",
  shell: "Terminal",
  sql: "SQL",
  ts: "TypeScript",
  tsx: "TSX",
  typescript: "TypeScript",
  yaml: "YAML",
  yml: "YAML",
  zsh: "Terminal"
};
function fenceTitle(language) {
  if (!language) return "Code";
  return TITLES[language.toLowerCase()] ?? language;
}
function isCode(element) {
  return element.type === "code" || LANGUAGE_CLASS.test(element.props.className ?? "");
}
function firstElement(node) {
  if (Array.isArray(node)) {
    for (const child of node) {
      const found = firstElement(child);
      if (found) return found;
    }
    return null;
  }
  return isValidElement3(node) ? node : null;
}
function readText(node) {
  if (node === null || node === void 0 || typeof node === "boolean") return "";
  if (typeof node === "string" || typeof node === "number") return String(node);
  if (Array.isArray(node)) return node.map(readText).join("");
  if (isValidElement3(node)) return readText(node.props.children);
  return "";
}
function readFence(children) {
  const element = firstElement(children);
  if (element && !isCode(element)) return null;
  const source = readText(element ? element.props.children : children);
  if (!element && source === "") return null;
  const className = element?.props.className;
  const language = typeof className === "string" ? className.match(LANGUAGE_CLASS)?.[1] : void 0;
  return { language: language?.toLowerCase(), source };
}

// components/site/highlight.ts
init_highlight();
var highlighters = /* @__PURE__ */ new Map();
function highlighterFor(language) {
  const cached = highlighters.get(language);
  if (cached) return cached;
  const pending = loadHighlighter(language).catch(() => null);
  highlighters.set(language, pending);
  return pending;
}
async function highlightSource(source, language) {
  if (!language || !source) return null;
  const highlighter = await highlighterFor(language);
  if (!highlighter) return null;
  const trimmed = source.endsWith("\n") ? source.slice(0, -1) : source;
  return highlighter.highlight(trimmed).lines;
}

// components/site/package-manager-block.tsx
import { jsx as jsx17, jsxs as jsxs8 } from "react/jsx-runtime";
function PackageManagerBlock({ panels, size = "default" }) {
  const { manager, setManager } = usePackageManager();
  const copyable = Object.fromEntries(panels.map((panel) => [panel.value, panel.command]));
  return /* @__PURE__ */ jsxs8(
    CodeBlock,
    {
      size,
      tab: manager,
      onTabChange: (value) => {
        if (isPackageManager(value)) setManager(value);
      },
      children: [
        /* @__PURE__ */ jsxs8(CodeBlockHeader, { children: [
          /* @__PURE__ */ jsx17(CodeBlockTabs, { label: "Package manager", children: panels.map((panel) => /* @__PURE__ */ jsx17(CodeBlockTab, { value: panel.value, children: panel.label }, panel.value)) }),
          /* @__PURE__ */ jsx17(CodeBlockActions, { children: /* @__PURE__ */ jsx17(CodeBlockCopyButton, { values: copyable }) })
        ] }),
        panels.map((panel) => /* @__PURE__ */ jsx17(CodeBlockPanel, { value: panel.value, children: panel.lines ? panel.lines.map((line, index) => (
          // biome-ignore lint/suspicious/noArrayIndexKey: a line's identity is its position in the command
          /* @__PURE__ */ jsx17(CodeBlockLine, { children: line }, index)
        )) : panel.command }, panel.value))
      ]
    }
  );
}

// components/site/package-manager-fence.tsx
import { jsx as jsx18 } from "react/jsx-runtime";
async function PackageManagerFence({ source, size = "default" }) {
  const commands = packageManagerCommands(source);
  if (!commands.length) return null;
  const highlighted = await Promise.all(commands.map((entry) => highlightSource(entry.command, "bash")));
  const panels = commands.map((entry, index) => ({
    ...entry,
    lines: highlighted[index] ?? null
  }));
  return /* @__PURE__ */ jsx18(PackageManagerBlock, { panels, size });
}

// components/site/code-fence.tsx
import { jsx as jsx19, jsxs as jsxs9 } from "react/jsx-runtime";
async function CodeFence({ source, language, title, size = "default", className }) {
  const lines = await highlightSource(source, language);
  return /* @__PURE__ */ jsxs9(CodeBlock, { size, className: cn(className), children: [
    /* @__PURE__ */ jsxs9(CodeBlockHeader, { children: [
      /* @__PURE__ */ jsx19(CodeBlockTitle, { children: title ?? fenceTitle(language) }),
      /* @__PURE__ */ jsx19(CodeBlockActions, { children: /* @__PURE__ */ jsx19(CodeBlockCopyButton, { value: source }) })
    ] }),
    /* @__PURE__ */ jsx19(CodeBlockContent, { children: lines ? lines.map((line, index) => (
      // biome-ignore lint/suspicious/noArrayIndexKey: a line's identity is its position in the file
      /* @__PURE__ */ jsx19(CodeBlockLine, { children: line }, index)
    )) : source })
  ] });
}
async function MdxCodeFence({ children }) {
  const fence = readFence(children);
  if (!fence) {
    return /* @__PURE__ */ jsx19("pre", { tabIndex: 0, children });
  }
  if (fence.language === INSTALL_FENCE && installTarget(fence.source)) {
    return /* @__PURE__ */ jsx19(PackageManagerFence, { source: fence.source });
  }
  if (fence.language === PACKAGE_MANAGER_FENCE && hasPackageManagerCommand(fence.source)) {
    return /* @__PURE__ */ jsx19(PackageManagerFence, { source: fence.source });
  }
  const language = fence.language === INSTALL_FENCE || fence.language === PACKAGE_MANAGER_FENCE ? "bash" : fence.language;
  return /* @__PURE__ */ jsx19(CodeFence, { source: fence.source, language });
}

// components/site/document-entrance.tsx
import { motion as motion6, useInView } from "motion/react";
import { useEffect as useEffect10, useLayoutEffect as useLayoutEffect6, useRef as useRef6, useState as useState10 } from "react";
import { jsx as jsx20 } from "react/jsx-runtime";
var ENTRANCE_TIME_SCALE = duration.page / duration.base;
var CLIP_TIME_SCALE = duration.slow / duration.base;
var CLIP_EASE = [...ease.inOut];
var BODY_BLUR_PX = 4;
var CLIP_HIDDEN = "inset(0% 0% 100% 0%)";
var CLIP_SHOWN = "inset(0% 0% 0% 0%)";
var RESTING = { opacity: 1, y: 0, filter: "none", clipPath: "none" };
function DocumentEntrance({ children, className, as = "div" }) {
  const cm = useCadenceMotion();
  const ref = useRef6(null);
  const [settled, setSettled] = useState10(false);
  const inView = useInView(ref, { once: true, amount: "some" });
  const hidden = cm.reduced ? { opacity: 0, y: 0, filter: "none", clipPath: "none" } : { opacity: 0, y: distance.lg, filter: `blur(${BODY_BLUR_PX}px)`, clipPath: CLIP_HIDDEN };
  const shown = cm.reduced ? RESTING : { opacity: 1, y: 0, filter: "blur(0px)", clipPath: CLIP_SHOWN };
  const scale2 = ENTRANCE_TIME_SCALE * cm.timeScale;
  const clipScale = CLIP_TIME_SCALE * cm.timeScale;
  const entrance = cm.transition("reveal", { timeScale: scale2 });
  const clip = { ...cm.transition("reveal", { timeScale: clipScale }), ease: CLIP_EASE };
  const transition = cm.reduced ? {
    ...entrance,
    // The full-mode server styles must disappear in the frame the mode
    // resolves, not over the fade. Opacity is the only property that animates.
    y: { duration: 0 },
    filter: { duration: 0 },
    clipPath: { duration: 0 }
  } : { ...entrance, clipPath: clip };
  const show = settled || cm.disabled || inView;
  const instant = cm.disabled || cm.timeScale === 0;
  const useCommittedEffect4 = typeof window === "undefined" ? useEffect10 : useLayoutEffect6;
  useCommittedEffect4(() => {
    if (show && instant) setSettled(true);
  }, [show, instant]);
  const target = show ? settled || instant ? RESTING : shown : hidden;
  const activeTransition = show ? settled ? { duration: 0 } : transition : { duration: 0 };
  const controls = useControlAnimation(target, activeTransition);
  const motionProps = {
    "data-document-entrance": true,
    "data-motion": cm.mode,
    className,
    initial: cm.disabled ? RESTING : hidden,
    animate: controls,
    transition: activeTransition,
    onAnimationComplete: show && !settled ? () => setSettled(true) : void 0
  };
  if (as === "article") {
    return /* @__PURE__ */ jsx20(motion6.article, { ref, ...motionProps, children });
  }
  if (as === "section") {
    return /* @__PURE__ */ jsx20(motion6.section, { ref, ...motionProps, children });
  }
  return /* @__PURE__ */ jsx20(motion6.div, { ref, ...motionProps, children });
}

// components/site/mdx.tsx
import { compileMDX } from "next-mdx-remote/rsc";
import remarkGfm from "remark-gfm";
import { Fragment as Fragment4, jsx as jsx21, jsxs as jsxs10 } from "react/jsx-runtime";
function headingPlugin(headings) {
  return () => (tree) => {
    const used = /* @__PURE__ */ new Set();
    const text = (node) => node.value ?? node.children?.map(text).join("") ?? "";
    const walk = (node) => {
      if (node.type === "element" && /^h[23]$/.test(node.tagName ?? "")) {
        const title = text(node);
        const base = title.toLowerCase().replace(/[^\p{L}\p{N}\s-]/gu, "").trim().replace(/\s+/g, "-") || "section";
        let id = base;
        let suffix = 1;
        while (used.has(id)) id = `${base}-${suffix++}`;
        used.add(id);
        node.properties = { ...node.properties, id, className: ["scroll-mt-24"] };
        headings.push({ id, title });
      }
      node.children?.forEach(walk);
    };
    walk(tree);
  };
}
async function Mdx({ source, toc = false }) {
  const headings = [];
  const { content } = await compileMDX({
    source,
    options: { mdxOptions: { remarkPlugins: [remarkGfm], rehypePlugins: [headingPlugin(headings)] } },
    components: {
      table: ({ children, ...props }) => /* @__PURE__ */ jsx21("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsx21("table", { className: "docs-table", tabIndex: 0, ...props, children }) }),
      pre: ({ children }) => /* @__PURE__ */ jsx21(MdxCodeFence, { children })
    }
  });
  return /* @__PURE__ */ jsxs10(Fragment4, { children: [
    toc && /* @__PURE__ */ jsxs10("nav", { "aria-label": "On this page", className: "my-8 rounded-lg border border-border p-4 text-sm", children: [
      /* @__PURE__ */ jsx21("p", { className: "font-medium", children: "On this page" }),
      /* @__PURE__ */ jsx21("ul", { className: "mt-2 flex flex-wrap gap-x-5 gap-y-2", children: headings.map(({ id, title }) => /* @__PURE__ */ jsx21("li", { children: /* @__PURE__ */ jsx21("a", { className: "text-muted-foreground underline underline-offset-4 hover:text-foreground", href: `#${id}`, children: title }) }, id)) })
    ] }),
    /* @__PURE__ */ jsx21("div", { className: "typeset typeset-docs", children: content })
  ] });
}

// components/site/measured-height.tsx
import { useEffect as useEffect11, useLayoutEffect as useLayoutEffect7, useRef as useRef7 } from "react";
import { jsx as jsx22 } from "react/jsx-runtime";
var useIsomorphicLayoutEffect3 = typeof window === "undefined" ? useEffect11 : useLayoutEffect7;
function MeasuredHeight({ children, className }) {
  const boxRef = useRef7(null);
  const contentRef = useRef7(null);
  useIsomorphicLayoutEffect3(() => {
    const box = boxRef.current;
    const content = contentRef.current;
    if (!box || !content) return;
    const sync = () => {
      const height = content.getBoundingClientRect().height;
      if (!height) {
        box.style.removeProperty("height");
        return;
      }
      box.style.height = `${height}px`;
    };
    sync();
    const observer = new ResizeObserver(sync);
    observer.observe(content);
    return () => {
      observer.disconnect();
      box.style.removeProperty("height");
    };
  }, []);
  return /* @__PURE__ */ jsx22("div", { ref: boxRef, "data-preview-body": "", className: "overflow-hidden", children: /* @__PURE__ */ jsx22("div", { ref: contentRef, className, children }) });
}

// components/site/previews/button.tsx
import { PlusIcon } from "lucide-react";
import { useState as useState12 } from "react";

// components/site/previews/shell.tsx
import { jsx as jsx23 } from "react/jsx-runtime";
function PreviewStack({ className, children }) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx23(
    "div",
    {
      "data-preview-stack": true,
      "data-motion": cm.mode,
      style: popupStyle(cm, void 0),
      className: cn(
        "flex w-full flex-col items-center gap-5 ease-cadence-out duration-(--motion-duration-base)",
        cm.disabled ? "transition-none" : cm.reduced ? "transition-opacity starting:opacity-0" : "transition-[translate,opacity] starting:opacity-0 starting:translate-y-1 motion-reduce:transition-opacity motion-reduce:starting:translate-none",
        className
      ),
      children
    }
  );
}
function PreviewRow({ className, children }) {
  return /* @__PURE__ */ jsx23("div", { className: cn("flex flex-wrap items-center justify-center gap-3", className), children });
}

// components/site/previews/use-preview-variant.tsx
import { useEffect as useEffect12, useRef as useRef8, useState as useState11 } from "react";
import { jsx as jsx24, jsxs as jsxs11 } from "react/jsx-runtime";
function usePreviewVariant(label2, options2) {
  const [variant, setVariant] = useState11("all");
  const [invalid, setInvalid] = useState11(false);
  const selector = useRef8(null);
  const previousFocus = useRef8(null);
  useEffect12(() => {
    if (variant !== "all" && previousFocus.current?.closest("[hidden]")) selector.current?.focus();
  }, [variant]);
  useEffect12(() => {
    const read = () => {
      previousFocus.current = document.activeElement;
      const value = new URLSearchParams(window.location.search).get("variant");
      const valid = options2.find((option) => option === value);
      setVariant(valid ?? "all");
      setInvalid(Boolean(value && value !== "all" && !valid));
    };
    read();
    window.addEventListener("popstate", read);
    return () => window.removeEventListener("popstate", read);
  }, [options2]);
  function select(value) {
    previousFocus.current = document.activeElement;
    setVariant(value);
    setInvalid(false);
    const url = new URL(window.location.href);
    if (value === "all") url.searchParams.delete("variant");
    else url.searchParams.set("variant", value);
    if (url.href !== window.location.href) window.history.pushState(window.history.state, "", url);
  }
  return {
    variant,
    select,
    choose: (authored) => variant === "all" ? authored : variant,
    control: /* @__PURE__ */ jsxs11("div", { className: "grid w-full gap-1 text-sm", children: [
      /* @__PURE__ */ jsxs11("label", { className: "flex flex-wrap items-center gap-2", children: [
        label2,
        " variant",
        /* @__PURE__ */ jsxs11(
          "select",
          {
            ref: selector,
            "aria-label": `${label2} variant`,
            className: "rounded border bg-background p-1",
            value: variant,
            onChange: (event) => select(event.target.value),
            children: [
              /* @__PURE__ */ jsx24("option", { value: "all", children: "All variants (original examples)" }),
              options2.map((value) => /* @__PURE__ */ jsx24("option", { children: value }, value))
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsx24("p", { role: "status", children: invalid ? "Unknown variant. Showing all original examples." : "" })
    ] })
  };
}

// components/site/previews/button.tsx
import { jsx as jsx25, jsxs as jsxs12 } from "react/jsx-runtime";
var variants = ["default", "secondary", "destructive", "outline", "ghost", "link"];
function ButtonPreview() {
  const { variant, control } = usePreviewVariant("Button", variants);
  const [mode, setMode] = useState12();
  return /* @__PURE__ */ jsxs12(PreviewStack, { children: [
    control,
    /* @__PURE__ */ jsxs12("label", { className: "flex items-center gap-2 text-sm", children: [
      "Button motion",
      /* @__PURE__ */ jsxs12(
        "select",
        {
          "aria-label": "Button motion",
          value: mode ?? "inherit",
          onChange: (e) => setMode(e.target.value === "inherit" ? void 0 : e.target.value),
          children: [
            /* @__PURE__ */ jsx25("option", { value: "inherit", children: "Inherit" }),
            /* @__PURE__ */ jsx25("option", { value: "full", children: "Full" }),
            /* @__PURE__ */ jsx25("option", { value: "reduced", children: "Reduced" }),
            /* @__PURE__ */ jsx25("option", { value: "none", children: "None" })
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsxs12(CadenceProvider, { mode, children: [
      /* @__PURE__ */ jsx25(PreviewRow, { children: variants.map((value) => /* @__PURE__ */ jsx25("span", { hidden: variant !== "all" && variant !== value, children: /* @__PURE__ */ jsxs12(Button, { variant: value, children: [
        value[0]?.toUpperCase(),
        value.slice(1)
      ] }) }, value)) }),
      /* @__PURE__ */ jsxs12(PreviewRow, { children: [
        /* @__PURE__ */ jsx25(Button, { size: "xs", children: "Xs" }),
        /* @__PURE__ */ jsx25(Button, { size: "sm", children: "Sm" }),
        /* @__PURE__ */ jsx25(Button, { children: "Default" }),
        /* @__PURE__ */ jsx25(Button, { size: "lg", children: "Lg" }),
        /* @__PURE__ */ jsx25(Button, { size: "icon-xs", "aria-label": "Add", children: /* @__PURE__ */ jsx25(PlusIcon, {}) }),
        /* @__PURE__ */ jsx25(Button, { size: "icon-sm", "aria-label": "Add", children: /* @__PURE__ */ jsx25(PlusIcon, {}) }),
        /* @__PURE__ */ jsx25(Button, { size: "icon", "aria-label": "Add", children: /* @__PURE__ */ jsx25(PlusIcon, {}) }),
        /* @__PURE__ */ jsx25(Button, { size: "icon-lg", "aria-label": "Add", children: /* @__PURE__ */ jsx25(PlusIcon, {}) })
      ] }),
      /* @__PURE__ */ jsxs12(PreviewRow, { children: [
        /* @__PURE__ */ jsxs12(Button, { children: [
          /* @__PURE__ */ jsx25(PlusIcon, {}),
          "New file"
        ] }),
        /* @__PURE__ */ jsx25(Button, { variant: "outline", disabled: true, children: "Disabled" })
      ] })
    ] })
  ] });
}

// components/site/previews/badge.tsx
import { CheckIcon as CheckIcon3, ClockIcon, GitBranchIcon } from "lucide-react";

// registry/cadence/badge/index.tsx
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
import { cva as cva3 } from "class-variance-authority";
var badgeVariants = cva3(
  "inline-flex w-fit shrink-0 items-center justify-center gap-1 overflow-hidden whitespace-nowrap rounded-full border border-transparent px-2 py-0.5 text-xs font-medium transition-[color,box-shadow] outline-none focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 aria-invalid:border-destructive aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40 [&>svg]:pointer-events-none [&>svg]:size-3",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground [a&]:hover:bg-primary/90",
        secondary: "bg-secondary text-secondary-foreground [a&]:hover:bg-secondary/90",
        destructive: "bg-destructive text-white focus-visible:ring-destructive/20 dark:bg-destructive/60 dark:focus-visible:ring-destructive/40 [a&]:hover:bg-destructive/90",
        outline: "border-border text-foreground [a&]:hover:bg-accent [a&]:hover:text-accent-foreground",
        ghost: "[a&]:hover:bg-accent [a&]:hover:text-accent-foreground",
        link: "text-primary underline-offset-4 [a&]:hover:underline"
      }
    },
    defaultVariants: {
      variant: "default"
    }
  }
);
function Badge({ className, variant = "default", render, ...props }) {
  return useRender({
    defaultTagName: "span",
    props: mergeProps({ className: cn(badgeVariants({ variant }), className) }, props),
    render,
    state: { slot: "badge", variant }
  });
}

// components/site/previews/badge.tsx
import { Fragment as Fragment5, jsx as jsx26, jsxs as jsxs13 } from "react/jsx-runtime";
var previewVariantOptions = ["default", "secondary", "destructive", "outline", "ghost", "link"];
function BadgePreview() {
  const { control, choose } = usePreviewVariant("Badge", previewVariantOptions);
  return /* @__PURE__ */ jsxs13(Fragment5, { children: [
    control,
    /* @__PURE__ */ jsxs13(PreviewStack, { children: [
      /* @__PURE__ */ jsxs13(PreviewRow, { children: [
        /* @__PURE__ */ jsx26(Badge, { variant: choose("default"), children: "Default" }),
        /* @__PURE__ */ jsx26(Badge, { variant: choose("secondary"), children: "Secondary" }),
        /* @__PURE__ */ jsx26(Badge, { variant: choose("destructive"), children: "Destructive" }),
        /* @__PURE__ */ jsx26(Badge, { variant: choose("outline"), children: "Outline" }),
        /* @__PURE__ */ jsx26(Badge, { variant: choose("ghost"), children: "Ghost" }),
        /* @__PURE__ */ jsx26(Badge, { variant: choose("link"), children: "Link" })
      ] }),
      /* @__PURE__ */ jsxs13(PreviewRow, { children: [
        /* @__PURE__ */ jsxs13(Badge, { variant: choose("default"), children: [
          /* @__PURE__ */ jsx26(CheckIcon3, {}),
          "Verified"
        ] }),
        /* @__PURE__ */ jsxs13(Badge, { variant: choose("secondary"), children: [
          /* @__PURE__ */ jsx26(ClockIcon, {}),
          "Pending"
        ] }),
        /* @__PURE__ */ jsxs13(Badge, { variant: choose("outline"), children: [
          /* @__PURE__ */ jsx26(GitBranchIcon, {}),
          "main"
        ] }),
        /* @__PURE__ */ jsx26(Badge, { variant: choose("outline"), render: /* @__PURE__ */ jsx26("a", { href: "#badge-releases" }), children: "3 releases" }),
        /* @__PURE__ */ jsx26(Badge, { variant: choose("ghost"), render: /* @__PURE__ */ jsx26("a", { href: "#badge-changelog" }), children: "Changelog" })
      ] })
    ] })
  ] });
}

// registry/cadence/kbd/index.tsx
import { jsx as jsx27 } from "react/jsx-runtime";
function Kbd({ className, ...props }) {
  return /* @__PURE__ */ jsx27(
    "kbd",
    {
      "data-slot": "kbd",
      className: cn(
        "pointer-events-none inline-flex h-5 w-fit min-w-5 items-center justify-center gap-1 rounded-sm bg-muted px-1 font-sans text-xs font-medium text-muted-foreground select-none",
        "[&_svg:not([class*='size-'])]:size-3",
        "[[data-slot=tooltip-content]_&]:bg-background/20 [[data-slot=tooltip-content]_&]:text-background dark:[[data-slot=tooltip-content]_&]:bg-background/10",
        className
      ),
      ...props
    }
  );
}
function KbdGroup({ className, ...props }) {
  return /* @__PURE__ */ jsx27("kbd", { "data-slot": "kbd-group", className: cn("inline-flex items-center gap-1", className), ...props });
}

// components/site/previews/kbd.tsx
import { jsx as jsx28, jsxs as jsxs14 } from "react/jsx-runtime";
function KbdPreview() {
  return /* @__PURE__ */ jsxs14(PreviewStack, { children: [
    /* @__PURE__ */ jsxs14(PreviewRow, { children: [
      /* @__PURE__ */ jsx28(Kbd, { children: "K" }),
      /* @__PURE__ */ jsx28(Kbd, { children: "Esc" }),
      /* @__PURE__ */ jsx28(Kbd, { children: "Enter" }),
      /* @__PURE__ */ jsx28(Kbd, { children: "Tab" }),
      /* @__PURE__ */ jsx28(Kbd, { children: "\u2318" }),
      /* @__PURE__ */ jsx28(Kbd, { children: "\u21E7" })
    ] }),
    /* @__PURE__ */ jsxs14(PreviewRow, { className: "gap-5", children: [
      /* @__PURE__ */ jsxs14(KbdGroup, { children: [
        /* @__PURE__ */ jsx28(Kbd, { children: "\u2318" }),
        /* @__PURE__ */ jsx28(Kbd, { children: "K" })
      ] }),
      /* @__PURE__ */ jsxs14(KbdGroup, { children: [
        /* @__PURE__ */ jsx28(Kbd, { children: "Ctrl" }),
        /* @__PURE__ */ jsx28(Kbd, { children: "Shift" }),
        /* @__PURE__ */ jsx28(Kbd, { children: "P" })
      ] }),
      /* @__PURE__ */ jsxs14(KbdGroup, { children: [
        /* @__PURE__ */ jsx28(Kbd, { children: "\u2191" }),
        /* @__PURE__ */ jsx28(Kbd, { children: "\u2193" })
      ] })
    ] })
  ] });
}

// registry/cadence/separator/index.tsx
import { Separator as SeparatorPrimitive } from "@base-ui/react/separator";
import { jsx as jsx29 } from "react/jsx-runtime";
function Separator({ className, orientation = "horizontal", decorative = false, ...props }) {
  const a11y = decorative ? { role: "none", "aria-hidden": true } : {};
  return /* @__PURE__ */ jsx29(
    SeparatorPrimitive,
    {
      "data-slot": "separator",
      "data-orientation": orientation,
      orientation,
      ...a11y,
      className: (state) => cn(
        "shrink-0 bg-border data-[orientation=horizontal]:h-px data-[orientation=horizontal]:w-full data-[orientation=vertical]:h-full data-[orientation=vertical]:w-px",
        typeof className === "function" ? className(state) : className
      ),
      ...props
    }
  );
}

// components/site/previews/separator.tsx
import { Fragment as Fragment6, jsx as jsx30, jsxs as jsxs15 } from "react/jsx-runtime";
var previewVariantOptions2 = ["horizontal", "vertical"];
function SeparatorPreview() {
  const { control, choose } = usePreviewVariant("Separator", previewVariantOptions2);
  return /* @__PURE__ */ jsxs15(Fragment6, { children: [
    control,
    /* @__PURE__ */ jsxs15(PreviewStack, { children: [
      /* @__PURE__ */ jsx30(PreviewRow, { children: /* @__PURE__ */ jsxs15("div", { className: "grid w-72 gap-3 text-sm", children: [
        /* @__PURE__ */ jsx30("span", { children: "Signed in as ada@example.com." }),
        /* @__PURE__ */ jsx30(Separator, { className: "data-[orientation=vertical]:h-6", orientation: choose("horizontal") }),
        /* @__PURE__ */ jsx30("span", { className: "text-muted-foreground", children: "Billing is handled by finance." }),
        /* @__PURE__ */ jsx30(Separator, { decorative: true, orientation: choose("horizontal") }),
        /* @__PURE__ */ jsx30("span", { className: "text-muted-foreground", children: "This second rule is decorative." })
      ] }) }),
      /* @__PURE__ */ jsx30(PreviewRow, { children: /* @__PURE__ */ jsxs15("div", { className: "flex min-h-6 flex-wrap items-center gap-3 text-sm", children: [
        /* @__PURE__ */ jsx30("span", { children: "Draft" }),
        /* @__PURE__ */ jsx30(Separator, { orientation: choose("vertical"), className: "data-[orientation=vertical]:h-6" }),
        /* @__PURE__ */ jsx30("span", { className: "text-muted-foreground", children: "Edited 2 minutes ago" }),
        /* @__PURE__ */ jsx30(Separator, { orientation: choose("vertical"), className: "data-[orientation=vertical]:h-6" }),
        /* @__PURE__ */ jsx30("span", { className: "text-muted-foreground", children: "ada@example.com" })
      ] }) })
    ] })
  ] });
}

// registry/cadence/checkbox/index.tsx
import { Checkbox as CheckboxPrimitive } from "@base-ui/react/checkbox";
import { Check, Minus } from "lucide-react";
import { jsx as jsx31 } from "react/jsx-runtime";
function Checkbox({ className, ...props }) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx31(
    CheckboxPrimitive.Root,
    {
      "data-slot": "checkbox",
      "data-motion": cm.mode,
      className: (state) => cn(
        "peer relative size-4 shrink-0 rounded-[4px] border border-input shadow-xs outline-none transition-shadow after:absolute after:-inset-x-3 after:-inset-y-2",
        "focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50",
        "data-disabled:cursor-not-allowed data-disabled:opacity-50",
        "aria-invalid:border-destructive aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40",
        "data-checked:border-primary data-checked:bg-primary data-checked:text-primary-foreground",
        "dark:bg-input/30",
        typeof className === "function" ? className(state) : className
      ),
      ...props,
      children: /* @__PURE__ */ jsx31(
        CheckboxPrimitive.Indicator,
        {
          "data-slot": "checkbox-indicator",
          "data-motion": cm.mode,
          keepMounted: true,
          render: (indicatorProps, state) => {
            const { className: indicatorClassName, ...rest } = indicatorProps;
            return /* @__PURE__ */ jsx31(
              ControlSpan,
              {
                ...rest,
                className: cn("grid size-full place-content-center text-current", indicatorClassName),
                target: state.checked || state.indeterminate ? { opacity: 1, scale: 1 } : { opacity: 0, scale: cm.reduced ? 1 : scale.in },
                transition: { ...cm.transition("state.morph"), ...cm.reduced ? { scale: { duration: 0 } } : {} },
                children: state.indeterminate ? /* @__PURE__ */ jsx31(Minus, { className: "size-3.5" }) : /* @__PURE__ */ jsx31(Check, { className: "size-3.5" })
              }
            );
          }
        }
      )
    }
  );
}

// registry/cadence/input/index.tsx
import { Input as InputPrimitive } from "@base-ui/react/input";
import { jsx as jsx32 } from "react/jsx-runtime";
function Input({ className, type, ...props }) {
  return /* @__PURE__ */ jsx32(
    InputPrimitive,
    {
      type,
      "data-slot": "input",
      className: (state) => cn(
        "h-9 w-full min-w-0 rounded-md border border-input bg-transparent px-3 py-1 text-base shadow-xs transition-[color,box-shadow] outline-none selection:bg-primary selection:text-primary-foreground file:inline-flex file:h-7 file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground placeholder:text-muted-foreground disabled:pointer-events-none disabled:cursor-not-allowed disabled:opacity-50 md:text-sm dark:bg-input/30",
        "focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50",
        "aria-invalid:border-destructive aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40",
        typeof className === "function" ? className(state) : className
      ),
      ...props
    }
  );
}

// registry/cadence/label/index.tsx
import { jsx as jsx33 } from "react/jsx-runtime";
function Label({ className, ...props }) {
  return (
    // biome-ignore lint/a11y/noLabelWithoutControl: this is the label primitive; the caller supplies `htmlFor` or wraps the control, and both are tested.
    /* @__PURE__ */ jsx33(
      "label",
      {
        "data-slot": "label",
        className: cn(
          "flex items-center gap-2 text-sm leading-none font-medium select-none group-data-[disabled=true]:pointer-events-none group-data-[disabled=true]:opacity-50 peer-disabled:cursor-not-allowed peer-disabled:opacity-50",
          className
        ),
        ...props
      }
    )
  );
}

// components/site/previews/label.tsx
import { jsx as jsx34, jsxs as jsxs16 } from "react/jsx-runtime";
function LabelPreview() {
  return /* @__PURE__ */ jsxs16(PreviewStack, { children: [
    /* @__PURE__ */ jsxs16(PreviewRow, { className: "items-start gap-4", children: [
      /* @__PURE__ */ jsxs16("div", { className: "grid w-56 gap-2", children: [
        /* @__PURE__ */ jsx34(Label, { htmlFor: "label-preview-email", children: "Email" }),
        /* @__PURE__ */ jsx34(Input, { id: "label-preview-email", type: "email", autoComplete: "email", placeholder: "ada@example.com" })
      ] }),
      /* @__PURE__ */ jsxs16("div", { className: "group grid w-56 gap-2", "data-disabled": "true", children: [
        /* @__PURE__ */ jsx34(Label, { htmlFor: "label-preview-slug", children: "Slug" }),
        /* @__PURE__ */ jsx34(Input, { id: "label-preview-slug", className: "peer", disabled: true, defaultValue: "cadence" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs16(PreviewRow, { children: [
      /* @__PURE__ */ jsxs16("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx34(Checkbox, { id: "label-preview-terms", defaultChecked: true }),
        /* @__PURE__ */ jsx34(Label, { htmlFor: "label-preview-terms", children: "Email me about releases" })
      ] }),
      /* @__PURE__ */ jsxs16("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx34(Checkbox, { id: "label-preview-muted", disabled: true }),
        /* @__PURE__ */ jsx34(Label, { htmlFor: "label-preview-muted", children: "Disabled preference" })
      ] })
    ] })
  ] });
}

// components/site/previews/input.tsx
import { jsx as jsx35, jsxs as jsxs17 } from "react/jsx-runtime";
function InputPreview() {
  return /* @__PURE__ */ jsx35(PreviewStack, { children: /* @__PURE__ */ jsxs17("div", { className: "grid w-full max-w-[30rem] grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-5", children: [
    /* @__PURE__ */ jsxs17("div", { className: "grid gap-2", children: [
      /* @__PURE__ */ jsx35(Label, { htmlFor: "input-preview-name", children: "Workspace" }),
      /* @__PURE__ */ jsx35(Input, { id: "input-preview-name", placeholder: "Acme", autoComplete: "organization" })
    ] }),
    /* @__PURE__ */ jsxs17("div", { className: "grid gap-2", children: [
      /* @__PURE__ */ jsx35(Label, { htmlFor: "input-preview-filled", children: "Filled" }),
      /* @__PURE__ */ jsx35(Input, { id: "input-preview-filled", type: "email", defaultValue: "ada@example.com", readOnly: true })
    ] }),
    /* @__PURE__ */ jsxs17("div", { className: "grid gap-2", children: [
      /* @__PURE__ */ jsx35(Label, { htmlFor: "input-preview-invalid", children: "Invalid" }),
      /* @__PURE__ */ jsx35(Input, { id: "input-preview-invalid", type: "email", defaultValue: "ada@", "aria-invalid": "true", readOnly: true })
    ] }),
    /* @__PURE__ */ jsxs17("div", { className: "grid gap-2", children: [
      /* @__PURE__ */ jsx35(Label, { htmlFor: "input-preview-disabled", children: "Disabled" }),
      /* @__PURE__ */ jsx35(Input, { id: "input-preview-disabled", disabled: true, defaultValue: "cadence" })
    ] }),
    /* @__PURE__ */ jsxs17("div", { className: "grid gap-2", children: [
      /* @__PURE__ */ jsx35(Label, { htmlFor: "input-preview-file", children: "File" }),
      /* @__PURE__ */ jsx35(Input, { id: "input-preview-file", type: "file", accept: "image/png,image/jpeg" })
    ] })
  ] }) });
}

// registry/cadence/textarea/index.tsx
import { jsx as jsx36 } from "react/jsx-runtime";
function Textarea({ className, ...props }) {
  return /* @__PURE__ */ jsx36(
    "textarea",
    {
      "data-slot": "textarea",
      className: cn(
        "flex field-sizing-content min-h-16 w-full rounded-md border border-input bg-transparent px-3 py-2 text-base shadow-xs transition-[color,box-shadow] outline-none placeholder:text-muted-foreground focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 disabled:cursor-not-allowed disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-destructive/20 md:text-sm dark:bg-input/30 dark:aria-invalid:ring-destructive/40",
        className
      ),
      ...props
    }
  );
}

// components/site/previews/textarea.tsx
import { jsx as jsx37, jsxs as jsxs18 } from "react/jsx-runtime";
function TextareaPreview() {
  return /* @__PURE__ */ jsxs18(PreviewStack, { children: [
    /* @__PURE__ */ jsxs18(PreviewRow, { className: "items-start gap-4", children: [
      /* @__PURE__ */ jsxs18("div", { className: "grid w-60 gap-2", children: [
        /* @__PURE__ */ jsx37(Label, { htmlFor: "textarea-preview-comment", children: "Comment" }),
        /* @__PURE__ */ jsx37(Textarea, { id: "textarea-preview-comment", rows: 2, placeholder: "Leave a note for the reviewer" })
      ] }),
      /* @__PURE__ */ jsxs18("div", { className: "grid w-60 gap-2", children: [
        /* @__PURE__ */ jsx37(Label, { htmlFor: "textarea-preview-grow", children: "Auto-growing" }),
        /* @__PURE__ */ jsx37(Textarea, { id: "textarea-preview-grow", rows: 2, className: "max-h-40", placeholder: "Type another line\u2026" })
      ] })
    ] }),
    /* @__PURE__ */ jsxs18(PreviewRow, { className: "items-start gap-4", children: [
      /* @__PURE__ */ jsxs18("div", { className: "grid w-60 gap-2", children: [
        /* @__PURE__ */ jsx37(Label, { htmlFor: "textarea-preview-invalid", children: "Invalid" }),
        /* @__PURE__ */ jsx37(
          Textarea,
          {
            id: "textarea-preview-invalid",
            rows: 2,
            "aria-invalid": "true",
            "aria-describedby": "textarea-preview-error",
            defaultValue: "I build design systems that\u2026"
          }
        ),
        /* @__PURE__ */ jsx37("p", { id: "textarea-preview-error", className: "text-xs text-destructive", children: "Keep it under 280 characters." })
      ] }),
      /* @__PURE__ */ jsxs18("div", { className: "grid w-60 gap-2", children: [
        /* @__PURE__ */ jsx37(Label, { htmlFor: "textarea-preview-disabled", children: "Disabled" }),
        /* @__PURE__ */ jsx37(Textarea, { id: "textarea-preview-disabled", rows: 2, disabled: true, defaultValue: "Read only" })
      ] })
    ] })
  ] });
}

// components/site/previews/card.tsx
import { useRef as useRef10, useState as useState13 } from "react";

// registry/cadence/card/index.tsx
import { useCallback as useCallback5, useEffect as useEffect13, useLayoutEffect as useLayoutEffect8, useRef as useRef9 } from "react";
import { jsx as jsx38 } from "react/jsx-runtime";
var useIsomorphicLayoutEffect4 = typeof window === "undefined" ? useEffect13 : useLayoutEffect8;
var shell = "group/card overflow-hidden rounded-xl border bg-card text-sm text-card-foreground shadow-sm [--card-spacing:1.5rem] data-[size=sm]:[--card-spacing:1rem]";
var flow = "flex flex-col gap-(--card-spacing) py-(--card-spacing) *:[img:first-child]:rounded-t-xl *:[img:last-child]:rounded-b-xl";
function Card({ className, size = "default", fit, children, ref, ...props }) {
  const rootRef = useRef9(null);
  const flowRef = useRef9(null);
  const fitContent = fit === "content";
  const mergedRef = useCallback5(
    (node) => {
      rootRef.current = node;
      const cleanup = typeof ref === "function" ? ref(node) : void 0;
      if (ref && typeof ref !== "function") ref.current = node;
      return () => {
        rootRef.current = null;
        if (typeof cleanup === "function") cleanup();
        else if (typeof ref === "function") ref(null);
        else if (ref) ref.current = null;
      };
    },
    [ref]
  );
  useIsomorphicLayoutEffect4(() => {
    if (!fitContent) return;
    const root = rootRef.current;
    const box = flowRef.current;
    if (!root || !box) return;
    const borders = () => {
      const styles = window.getComputedStyle(root);
      return Number.parseFloat(styles.borderTopWidth || "0") + Number.parseFloat(styles.borderBottomWidth || "0");
    };
    const measure = () => {
      const height = box.getBoundingClientRect().height;
      if (!height) {
        root.style.removeProperty("height");
        return;
      }
      root.style.height = `${height + borders()}px`;
    };
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(box);
    return () => {
      observer.disconnect();
      root.style.removeProperty("height");
    };
  }, [fitContent, ref]);
  if (!fitContent) {
    return /* @__PURE__ */ jsx38("div", { ref, "data-slot": "card", "data-size": size, className: cn(shell, flow, className), ...props, children });
  }
  return /* @__PURE__ */ jsx38(
    "div",
    {
      ref: mergedRef,
      "data-slot": "card",
      "data-size": size,
      "data-fit": "content",
      className: cn(shell, "w-fit", className),
      ...props,
      children: /* @__PURE__ */ jsx38("div", { ref: flowRef, "data-slot": "card-flow", className: flow, children })
    }
  );
}
function CardHeader({ className, ...props }) {
  return /* @__PURE__ */ jsx38(
    "div",
    {
      "data-slot": "card-header",
      className: cn(
        "@container/card-header grid auto-rows-min grid-rows-[auto_auto] items-start gap-2 px-(--card-spacing) has-data-[slot=card-action]:grid-cols-[1fr_auto] [.border-b]:pb-(--card-spacing)",
        className
      ),
      ...props
    }
  );
}
function CardTitle({ className, ...props }) {
  return /* @__PURE__ */ jsx38("div", { "data-slot": "card-title", className: cn("leading-none font-semibold", className), ...props });
}
function CardDescription({ className, ...props }) {
  return /* @__PURE__ */ jsx38("div", { "data-slot": "card-description", className: cn("text-sm text-muted-foreground", className), ...props });
}
function CardAction({ className, ...props }) {
  return /* @__PURE__ */ jsx38(
    "div",
    {
      "data-slot": "card-action",
      className: cn("col-start-2 row-span-2 row-start-1 self-start justify-self-end", className),
      ...props
    }
  );
}
function CardContent({ className, ...props }) {
  return /* @__PURE__ */ jsx38("div", { "data-slot": "card-content", className: cn("px-(--card-spacing)", className), ...props });
}
function CardFooter({ className, ...props }) {
  return /* @__PURE__ */ jsx38(
    "div",
    {
      "data-slot": "card-footer",
      className: cn("flex items-center px-(--card-spacing) [.border-t]:pt-(--card-spacing)", className),
      ...props
    }
  );
}

// components/site/previews/card.tsx
import { Fragment as Fragment7, jsx as jsx39, jsxs as jsxs19 } from "react/jsx-runtime";
var previewVariantOptions3 = ["default", "sm"];
function CardPreview() {
  const { control, choose } = usePreviewVariant("Card", previewVariantOptions3);
  const [expanded, setExpanded] = useState13(false);
  const fitRef = useRef10(null);
  return /* @__PURE__ */ jsxs19(Fragment7, { children: [
    control,
    /* @__PURE__ */ jsxs19(PreviewStack, { children: [
      /* @__PURE__ */ jsxs19("div", { className: "grid w-full max-w-lg grid-cols-1 sm:grid-cols-2 items-stretch gap-4", children: [
        /* @__PURE__ */ jsxs19(Card, { size: choose("default"), children: [
          /* @__PURE__ */ jsxs19(CardHeader, { children: [
            /* @__PURE__ */ jsx39(CardTitle, { children: "Parity plan" }),
            /* @__PURE__ */ jsx39(CardDescription, { children: "58 components, ten batches." }),
            /* @__PURE__ */ jsx39(CardAction, { children: /* @__PURE__ */ jsx39(Badge, { variant: "secondary", children: "0.2.0" }) })
          ] }),
          /* @__PURE__ */ jsx39(CardContent, { children: /* @__PURE__ */ jsx39("p", { className: "text-sm text-muted-foreground", children: "Batch B1 ships the eleven atoms." }) }),
          /* @__PURE__ */ jsx39(CardFooter, { children: /* @__PURE__ */ jsx39(Button, { variant: "outline", size: "sm", children: "Open plan" }) })
        ] }),
        /* @__PURE__ */ jsxs19(Card, { size: choose("sm"), children: [
          /* @__PURE__ */ jsxs19(CardHeader, { children: [
            /* @__PURE__ */ jsx39(CardTitle, { children: "Compact" }),
            /* @__PURE__ */ jsx39(CardDescription, { children: "1.5rem of padding becomes 1rem." })
          ] }),
          /* @__PURE__ */ jsx39(CardContent, { children: /* @__PURE__ */ jsx39("p", { className: "text-sm text-muted-foreground", children: "Every part follows one property." }) }),
          /* @__PURE__ */ jsx39(CardFooter, { children: /* @__PURE__ */ jsx39("span", { className: "text-xs text-muted-foreground", children: 'size="sm"' }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxs19(Card, { fit: "content", ref: fitRef, "data-testid": "fit-card", className: "max-w-sm", size: choose("default"), children: [
        /* @__PURE__ */ jsx39(CardHeader, { children: /* @__PURE__ */ jsx39(CardTitle, { children: "Content fit" }) }),
        /* @__PURE__ */ jsx39(CardContent, { children: expanded ? "The surface follows its own content immediately. A caller ref still reaches the same measured shell while the text wraps as the viewport narrows." : "Short content." }),
        /* @__PURE__ */ jsx39(CardFooter, { children: /* @__PURE__ */ jsx39(Button, { variant: "outline", onClick: () => setExpanded((value) => !value), children: "Toggle content" }) })
      ] })
    ] })
  ] });
}

// registry/cadence/aspect-ratio/index.tsx
import { jsx as jsx40 } from "react/jsx-runtime";
function AspectRatio({ ratio, className, style, ...props }) {
  return /* @__PURE__ */ jsx40(
    "div",
    {
      "data-slot": "aspect-ratio",
      style: { ...style, "--ratio": ratio },
      className: cn("relative aspect-(--ratio)", className),
      ...props
    }
  );
}

// components/site/previews/aspect-ratio.tsx
import { jsx as jsx41 } from "react/jsx-runtime";
function AspectRatioPreview() {
  return /* @__PURE__ */ jsx41(PreviewStack, { children: /* @__PURE__ */ jsx41(PreviewRow, { className: "items-center gap-4", children: [
    { ratio: 16 / 9, label: "16 : 9" },
    { ratio: 1, label: "1 : 1" },
    { ratio: 3 / 4, label: "3 : 4" }
  ].map(({ ratio, label: label2 }) => /* @__PURE__ */ jsx41(AspectRatio, { ratio, className: "w-36 overflow-hidden rounded-lg border bg-muted", children: /* @__PURE__ */ jsx41("div", { className: "flex size-full items-center justify-center text-xs text-muted-foreground", children: label2 }) }, label2)) }) });
}

// registry/cadence/avatar/index.tsx
import { Avatar as AvatarPrimitive } from "@base-ui/react/avatar";
import { jsx as jsx42 } from "react/jsx-runtime";
function Avatar({ className, size = "default", ...props }) {
  return /* @__PURE__ */ jsx42(
    AvatarPrimitive.Root,
    {
      "data-slot": "avatar",
      "data-size": size,
      className: (state) => cn(
        "group/avatar relative flex size-8 shrink-0 overflow-hidden rounded-full select-none data-[size=lg]:size-10 data-[size=sm]:size-6",
        typeof className === "function" ? className(state) : className
      ),
      ...props
    }
  );
}
function AvatarImage({ className, ...props }) {
  return /* @__PURE__ */ jsx42(
    AvatarPrimitive.Image,
    {
      "data-slot": "avatar-image",
      className: (state) => cn("aspect-square size-full object-cover", typeof className === "function" ? className(state) : className),
      ...props
    }
  );
}
function AvatarFallback({ className, ...props }) {
  return /* @__PURE__ */ jsx42(
    AvatarPrimitive.Fallback,
    {
      "data-slot": "avatar-fallback",
      className: (state) => cn(
        "flex size-full items-center justify-center rounded-full bg-muted text-sm text-muted-foreground group-data-[size=sm]/avatar:text-xs",
        typeof className === "function" ? className(state) : className
      ),
      ...props
    }
  );
}
function AvatarBadge({ className, ...props }) {
  return /* @__PURE__ */ jsx42(
    "span",
    {
      "data-slot": "avatar-badge",
      className: cn(
        "absolute right-0 bottom-0 z-10 inline-flex items-center justify-center rounded-full bg-primary text-primary-foreground ring-2 ring-background select-none",
        "group-data-[size=sm]/avatar:size-2 group-data-[size=sm]/avatar:[&>svg]:hidden",
        "group-data-[size=default]/avatar:size-2.5 group-data-[size=default]/avatar:[&>svg]:size-2",
        "group-data-[size=lg]/avatar:size-3 group-data-[size=lg]/avatar:[&>svg]:size-2",
        className
      ),
      ...props
    }
  );
}
function AvatarGroup({ className, ...props }) {
  return /* @__PURE__ */ jsx42(
    "div",
    {
      "data-slot": "avatar-group",
      className: cn(
        "group/avatar-group flex -space-x-2 *:data-[slot=avatar]:ring-2 *:data-[slot=avatar]:ring-background",
        className
      ),
      ...props
    }
  );
}
function AvatarGroupCount({ className, ...props }) {
  return /* @__PURE__ */ jsx42(
    "div",
    {
      "data-slot": "avatar-group-count",
      className: cn(
        "relative flex size-8 shrink-0 items-center justify-center rounded-full bg-muted text-sm text-muted-foreground ring-2 ring-background group-has-data-[size=lg]/avatar-group:size-10 group-has-data-[size=sm]/avatar-group:size-6 [&>svg]:size-4 group-has-data-[size=lg]/avatar-group:[&>svg]:size-5 group-has-data-[size=sm]/avatar-group:[&>svg]:size-3",
        className
      ),
      ...props
    }
  );
}

// components/site/previews/avatar.tsx
import { Fragment as Fragment8, jsx as jsx43, jsxs as jsxs20 } from "react/jsx-runtime";
var previewVariantOptions4 = ["default", "sm", "lg"];
function AvatarPreview() {
  const { control, choose } = usePreviewVariant("Avatar", previewVariantOptions4);
  return /* @__PURE__ */ jsxs20(Fragment8, { children: [
    control,
    /* @__PURE__ */ jsxs20(PreviewStack, { children: [
      /* @__PURE__ */ jsxs20(PreviewRow, { children: [
        /* @__PURE__ */ jsx43(Avatar, { size: choose("sm"), children: /* @__PURE__ */ jsx43(AvatarFallback, { children: "AL" }) }),
        /* @__PURE__ */ jsx43(Avatar, { size: choose("default"), children: /* @__PURE__ */ jsx43(AvatarFallback, { children: "AL" }) }),
        /* @__PURE__ */ jsx43(Avatar, { size: choose("lg"), children: /* @__PURE__ */ jsx43(AvatarFallback, { children: "AL" }) })
      ] }),
      /* @__PURE__ */ jsxs20(PreviewRow, { children: [
        /* @__PURE__ */ jsxs20(Avatar, { size: choose("default"), children: [
          /* @__PURE__ */ jsx43(AvatarImage, { src: "https://github.com/shadcn.png", alt: "shadcn" }),
          /* @__PURE__ */ jsx43(AvatarFallback, { children: "SC" }),
          /* @__PURE__ */ jsx43(AvatarBadge, { className: "bg-emerald-600" })
        ] }),
        /* @__PURE__ */ jsxs20(Avatar, { size: choose("default"), children: [
          /* @__PURE__ */ jsx43(AvatarImage, { src: "/missing-avatar.png", alt: "Broken image" }),
          /* @__PURE__ */ jsx43(AvatarFallback, { children: "GH" })
        ] }),
        /* @__PURE__ */ jsx43(Avatar, { size: choose("default"), children: /* @__PURE__ */ jsx43(AvatarFallback, { children: "AL" }) })
      ] }),
      /* @__PURE__ */ jsx43(PreviewRow, { children: /* @__PURE__ */ jsxs20(AvatarGroup, { children: [
        /* @__PURE__ */ jsx43(Avatar, { size: choose("default"), children: /* @__PURE__ */ jsx43(AvatarFallback, { children: "AL" }) }),
        /* @__PURE__ */ jsx43(Avatar, { size: choose("default"), children: /* @__PURE__ */ jsx43(AvatarFallback, { children: "GH" }) }),
        /* @__PURE__ */ jsx43(Avatar, { size: choose("default"), children: /* @__PURE__ */ jsx43(AvatarFallback, { children: "SC" }) }),
        /* @__PURE__ */ jsx43(AvatarGroupCount, { children: "+3" })
      ] }) })
    ] })
  ] });
}

// components/site/previews/skeleton.tsx
import { useState as useState14 } from "react";

// registry/cadence/skeleton/index.tsx
import { jsx as jsx44 } from "react/jsx-runtime";
function Skeleton({ className, ...props }) {
  const cm = useCadenceMotion();
  const pulse = cm.mode === "none" ? "animate-none" : "animate-pulse";
  return /* @__PURE__ */ jsx44(
    "div",
    {
      "data-slot": "skeleton",
      "data-motion": cm.mode,
      className: cn("rounded-md bg-accent", pulse, cm.reduced && "transform-none", className),
      ...props
    }
  );
}

// components/site/previews/skeleton.tsx
import { jsx as jsx45, jsxs as jsxs21 } from "react/jsx-runtime";
function SkeletonPreview() {
  const [mode, setMode] = useState14();
  return /* @__PURE__ */ jsxs21(PreviewStack, { children: [
    /* @__PURE__ */ jsxs21("label", { className: "flex items-center gap-2 text-sm", children: [
      "Skeleton motion",
      /* @__PURE__ */ jsxs21(
        "select",
        {
          "aria-label": "Skeleton motion",
          value: mode ?? "inherit",
          onChange: (e) => setMode(e.target.value === "inherit" ? void 0 : e.target.value),
          children: [
            /* @__PURE__ */ jsx45("option", { value: "inherit", children: "Inherit" }),
            /* @__PURE__ */ jsx45("option", { value: "full", children: "Full" }),
            /* @__PURE__ */ jsx45("option", { value: "reduced", children: "Reduced" }),
            /* @__PURE__ */ jsx45("option", { value: "none", children: "None" })
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsx45(CadenceProvider, { mode, children: /* @__PURE__ */ jsxs21(PreviewRow, { className: "items-start gap-8", children: [
      /* @__PURE__ */ jsxs21("div", { className: "w-56", "aria-busy": "true", children: [
        /* @__PURE__ */ jsx45(Skeleton, { className: "h-24 w-full rounded-lg" }),
        /* @__PURE__ */ jsx45(Skeleton, { className: "mt-3 h-4 w-2/3" }),
        /* @__PURE__ */ jsx45(Skeleton, { className: "mt-2 h-4 w-1/2" })
      ] }),
      /* @__PURE__ */ jsxs21("div", { className: "w-56", "aria-busy": "true", children: [
        /* @__PURE__ */ jsxs21("div", { className: "flex items-center gap-3", children: [
          /* @__PURE__ */ jsx45(Skeleton, { className: "size-10 shrink-0 rounded-full" }),
          /* @__PURE__ */ jsxs21("div", { className: "grid w-full gap-2", children: [
            /* @__PURE__ */ jsx45(Skeleton, { className: "h-3 w-32" }),
            /* @__PURE__ */ jsx45(Skeleton, { className: "h-3 w-20" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs21("div", { className: "mt-4 grid gap-2", children: [
          /* @__PURE__ */ jsx45(Skeleton, { className: "h-4 w-full" }),
          /* @__PURE__ */ jsx45(Skeleton, { className: "h-4 w-11/12" }),
          /* @__PURE__ */ jsx45(Skeleton, { className: "h-4 w-3/5" })
        ] })
      ] })
    ] }) })
  ] });
}

// registry/cadence/dialog/index.tsx
import { Dialog as DialogPrimitive } from "@base-ui/react/dialog";
import { X } from "lucide-react";
import { jsx as jsx46, jsxs as jsxs22 } from "react/jsx-runtime";
function Dialog({ ...props }) {
  return /* @__PURE__ */ jsx46(DialogPrimitive.Root, { "data-slot": "dialog", ...props });
}
function DialogTrigger({ ...props }) {
  return /* @__PURE__ */ jsx46(DialogPrimitive.Trigger, { "data-slot": "dialog-trigger", ...props });
}
function DialogPortal({ ...props }) {
  return /* @__PURE__ */ jsx46(DialogPrimitive.Portal, { "data-slot": "dialog-portal", ...props });
}
function DialogClose({ ...props }) {
  return /* @__PURE__ */ jsx46(DialogPrimitive.Close, { "data-slot": "dialog-close", ...props });
}
function DialogOverlay({ className, style, ...props }) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx46(
    DialogPrimitive.Backdrop,
    {
      "data-slot": "dialog-overlay",
      "data-motion": cm.mode,
      style: popupStyle(cm, style),
      className: popupClasses(
        cm,
        cn(
          "fixed inset-0 isolate z-50 bg-black/50 transition-opacity ease-cadence-out duration-(--motion-duration-fast) data-[ending-style]:opacity-0 data-[starting-style]:opacity-0"
        ),
        className
      ),
      ...props
    }
  );
}
function DialogContent({
  className,
  style,
  children,
  showCloseButton = true,
  ...props
}) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsxs22(DialogPortal, { children: [
    /* @__PURE__ */ jsx46(DialogOverlay, {}),
    /* @__PURE__ */ jsxs22(
      DialogPrimitive.Popup,
      {
        "data-slot": "dialog-content",
        "data-motion": cm.mode,
        style: popupStyle(cm, style),
        className: popupClasses(
          cm,
          cn(
            "fixed top-1/2 left-1/2 z-50 grid w-full max-w-[calc(100%-2rem)] -translate-x-1/2 -translate-y-1/2 gap-4 rounded-lg border bg-background p-6 shadow-lg outline-none transition-[opacity,scale] ease-cadence-out duration-(--motion-duration-base) data-[ending-style]:opacity-0 data-[starting-style]:opacity-0 sm:max-w-lg",
            !cm.reduced && "data-[ending-style]:scale-(--motion-scale-in) data-[starting-style]:scale-(--motion-scale-in)"
          ),
          className
        ),
        ...props,
        children: [
          children,
          showCloseButton && /* @__PURE__ */ jsxs22(
            DialogPrimitive.Close,
            {
              "data-slot": "dialog-close",
              className: "absolute top-4 right-4",
              render: /* @__PURE__ */ jsx46(Button, { variant: "ghost", size: "icon-sm" }),
              children: [
                /* @__PURE__ */ jsx46(X, {}),
                /* @__PURE__ */ jsx46("span", { className: "sr-only", children: "Close" })
              ]
            }
          )
        ]
      }
    )
  ] });
}
function DialogHeader({ className, ...props }) {
  return /* @__PURE__ */ jsx46(
    "div",
    {
      "data-slot": "dialog-header",
      className: cn("flex flex-col gap-2 text-center sm:text-left", className),
      ...props
    }
  );
}
function DialogFooter({
  className,
  showCloseButton = false,
  children,
  ...props
}) {
  return /* @__PURE__ */ jsxs22(
    "div",
    {
      "data-slot": "dialog-footer",
      className: cn("flex flex-col-reverse gap-2 sm:flex-row sm:justify-end", className),
      ...props,
      children: [
        children,
        showCloseButton && /* @__PURE__ */ jsx46(DialogPrimitive.Close, { "data-slot": "dialog-close", render: /* @__PURE__ */ jsx46(Button, { variant: "outline" }), children: "Close" })
      ]
    }
  );
}
function DialogTitle({ className, ...props }) {
  return /* @__PURE__ */ jsx46(
    DialogPrimitive.Title,
    {
      "data-slot": "dialog-title",
      className: stateClasses(cn("text-lg font-semibold"), className),
      ...props
    }
  );
}
function DialogDescription({ className, ...props }) {
  return /* @__PURE__ */ jsx46(
    DialogPrimitive.Description,
    {
      "data-slot": "dialog-description",
      className: stateClasses(cn("text-sm text-muted-foreground"), className),
      ...props
    }
  );
}

// registry/cadence/field/index.tsx
import { cva as cva4 } from "class-variance-authority";
import { jsx as jsx47, jsxs as jsxs23 } from "react/jsx-runtime";
function FieldSet({ className, ...props }) {
  return /* @__PURE__ */ jsx47(
    "fieldset",
    {
      "data-slot": "field-set",
      className: cn(
        "flex flex-col gap-6 has-[>[data-slot=checkbox-group]]:gap-3 has-[>[data-slot=radio-group]]:gap-3",
        className
      ),
      ...props
    }
  );
}
function FieldLegend({ className, variant = "legend", ...props }) {
  return /* @__PURE__ */ jsx47(
    "legend",
    {
      "data-slot": "field-legend",
      "data-variant": variant,
      className: cn("mb-3 font-medium data-[variant=legend]:text-base data-[variant=label]:text-sm", className),
      ...props
    }
  );
}
function FieldGroup({ className, ...props }) {
  return /* @__PURE__ */ jsx47(
    "div",
    {
      "data-slot": "field-group",
      className: cn(
        "group/field-group @container/field-group flex w-full flex-col gap-7 data-[slot=checkbox-group]:gap-3 [&>[data-slot=field-group]]:gap-4",
        className
      ),
      ...props
    }
  );
}
var fieldVariants = cva4("group/field flex w-full gap-3 data-[invalid=true]:text-destructive", {
  variants: {
    orientation: {
      vertical: "flex-col [&>*]:w-full [&>.sr-only]:w-auto",
      horizontal: "flex-row items-center [&>[data-slot=field-label]]:flex-auto has-[>[data-slot=field-content]]:items-start has-[>[data-slot=field-content]]:[&>[role=checkbox],[role=radio]]:mt-px",
      responsive: "flex-col @md/field-group:flex-row @md/field-group:items-center [&>*]:w-full @md/field-group:[&>*]:w-auto [&>.sr-only]:w-auto @md/field-group:[&>[data-slot=field-label]]:flex-auto @md/field-group:has-[>[data-slot=field-content]]:items-start @md/field-group:has-[>[data-slot=field-content]]:[&>[role=checkbox],[role=radio]]:mt-px"
    }
  },
  defaultVariants: {
    orientation: "vertical"
  }
});
function Field({ className, orientation = "vertical", ...props }) {
  return /* @__PURE__ */ jsx47(
    "div",
    {
      role: "group",
      "data-slot": "field",
      "data-orientation": orientation,
      className: cn(fieldVariants({ orientation }), className),
      ...props
    }
  );
}
function FieldContent({ className, ...props }) {
  return /* @__PURE__ */ jsx47(
    "div",
    {
      "data-slot": "field-content",
      className: cn("group/field-content flex flex-1 flex-col gap-1.5 leading-snug", className),
      ...props
    }
  );
}
function FieldLabel({ className, ...props }) {
  return /* @__PURE__ */ jsx47(
    Label,
    {
      "data-slot": "field-label",
      className: cn(
        "group/field-label peer/field-label flex w-fit gap-2 leading-snug group-data-[disabled=true]/field:opacity-50",
        "has-[>[data-slot=field]]:w-full has-[>[data-slot=field]]:flex-col has-[>[data-slot=field]]:rounded-md has-[>[data-slot=field]]:border [&>*]:data-[slot=field]:p-4",
        "has-data-[state=checked]:border-primary has-data-[state=checked]:bg-primary/5 dark:has-data-[state=checked]:bg-primary/10",
        className
      ),
      ...props
    }
  );
}
function FieldDescription({ className, ...props }) {
  return /* @__PURE__ */ jsx47(
    "p",
    {
      "data-slot": "field-description",
      className: cn(
        "text-sm leading-normal font-normal text-muted-foreground group-has-[[data-orientation=horizontal]]/field:text-balance",
        "last:mt-0 nth-last-2:-mt-1 [[data-variant=legend]+&]:-mt-1.5",
        "[&>a]:underline [&>a]:underline-offset-4 [&>a:hover]:text-primary",
        className
      ),
      ...props
    }
  );
}
function FieldSeparator({ children, className, ...props }) {
  return /* @__PURE__ */ jsxs23(
    "div",
    {
      "data-slot": "field-separator",
      "data-content": !!children,
      className: cn("relative -my-2 h-5 text-sm group-data-[variant=outline]/field-group:-mb-2", className),
      ...props,
      children: [
        /* @__PURE__ */ jsx47(Separator, { className: "absolute inset-0 top-1/2" }),
        children && /* @__PURE__ */ jsx47(
          "span",
          {
            className: "relative mx-auto block w-fit bg-background px-2 text-muted-foreground",
            "data-slot": "field-separator-content",
            children
          }
        )
      ]
    }
  );
}
function FieldError({ className, children, errors, ...props }) {
  let content = children;
  if (!content && errors?.length) {
    const uniqueErrors = [...new Map(errors.map((error) => [error?.message, error])).values()];
    content = uniqueErrors.length === 1 ? uniqueErrors[0]?.message : /* @__PURE__ */ jsx47("ul", { className: "ml-4 flex list-disc flex-col gap-1", children: uniqueErrors.map((error) => error?.message ? /* @__PURE__ */ jsx47("li", { children: error.message }, error.message) : null) });
  }
  if (!content) {
    return null;
  }
  return /* @__PURE__ */ jsx47(
    "div",
    {
      role: "alert",
      "data-slot": "field-error",
      className: cn("text-sm font-normal text-destructive", className),
      ...props,
      children: content
    }
  );
}

// components/site/previews/popup-motion-scope.tsx
import { useState as useState15 } from "react";
import { jsx as jsx48, jsxs as jsxs24 } from "react/jsx-runtime";
function PopupMotionScope({ children }) {
  const [mode, setMode] = useState15("inherit");
  return /* @__PURE__ */ jsxs24(PreviewStack, { children: [
    /* @__PURE__ */ jsxs24("label", { className: "flex items-center gap-2 text-sm", children: [
      "Popup motion",
      /* @__PURE__ */ jsx48(
        "select",
        {
          "aria-label": "Popup motion",
          className: "rounded border bg-background px-2",
          value: mode,
          onChange: (e) => setMode(e.target.value),
          children: ["inherit", "full", "reduced", "none"].map((value) => /* @__PURE__ */ jsx48("option", { children: value }, value))
        }
      )
    ] }),
    /* @__PURE__ */ jsx48(CadenceProvider, { mode: mode === "inherit" ? void 0 : mode, children })
  ] });
}

// components/site/previews/dialog.tsx
import { jsx as jsx49, jsxs as jsxs25 } from "react/jsx-runtime";
var CHANGELOG = [
  "Eleven atoms: button, badge, kbd, separator, label, input, textarea, card, aspect ratio, avatar, skeleton.",
  "Every component declares its motion recipes in the registry, so the docs and the source cannot drift.",
  "The previews load per page, so a component page never downloads the whole library.",
  "Reduced motion is a branch in the tree, not a media query bolted on afterwards.",
  "The docs site reads the same payload the CLI installs, which is what keeps the examples honest.",
  "Long bodies scroll inside the panel, so a dialog keeps its own height instead of growing with the copy."
];
function DialogPreview() {
  return /* @__PURE__ */ jsx49(PopupMotionScope, { children: /* @__PURE__ */ jsx49(PreviewStack, { children: /* @__PURE__ */ jsxs25(PreviewRow, { className: "gap-3", children: [
    /* @__PURE__ */ jsxs25(Dialog, { children: [
      /* @__PURE__ */ jsx49(DialogTrigger, { render: /* @__PURE__ */ jsx49(Button, { variant: "outline" }), children: "Rename project" }),
      /* @__PURE__ */ jsxs25(DialogContent, { children: [
        /* @__PURE__ */ jsxs25(DialogHeader, { children: [
          /* @__PURE__ */ jsx49(DialogTitle, { children: "Rename project" }),
          /* @__PURE__ */ jsx49(DialogDescription, { children: "The URL stays the same. Existing links keep working after the rename." })
        ] }),
        /* @__PURE__ */ jsxs25(Field, { children: [
          /* @__PURE__ */ jsx49(FieldLabel, { htmlFor: "preview-project-name", children: "Project name" }),
          /* @__PURE__ */ jsx49(Input, { id: "preview-project-name", defaultValue: "cadence-ui" })
        ] }),
        /* @__PURE__ */ jsxs25(DialogFooter, { children: [
          /* @__PURE__ */ jsx49(DialogClose, { render: /* @__PURE__ */ jsx49(Button, { variant: "outline" }), children: "Cancel" }),
          /* @__PURE__ */ jsx49(DialogClose, { render: /* @__PURE__ */ jsx49(Button, {}), children: "Save name" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxs25(Dialog, { children: [
      /* @__PURE__ */ jsx49(DialogTrigger, { render: /* @__PURE__ */ jsx49(Button, { variant: "ghost" }), children: "Read the changelog" }),
      /* @__PURE__ */ jsxs25(DialogContent, { className: "max-h-[70vh] overflow-y-auto", children: [
        /* @__PURE__ */ jsxs25(DialogHeader, { children: [
          /* @__PURE__ */ jsx49(DialogTitle, { children: "0.2.0" }),
          /* @__PURE__ */ jsx49(DialogDescription, { children: "Eleven atoms, nine batches, one release train." })
        ] }),
        /* @__PURE__ */ jsx49("div", { className: "grid gap-2 text-sm text-muted-foreground", children: CHANGELOG.map((entry) => /* @__PURE__ */ jsx49("p", { children: entry }, entry)) })
      ] })
    ] })
  ] }) }) });
}

// components/site/previews/alert.tsx
import { CircleAlertIcon, TriangleAlertIcon } from "lucide-react";

// registry/cadence/alert/index.tsx
import { cva as cva5 } from "class-variance-authority";
import { jsx as jsx50 } from "react/jsx-runtime";
var alertVariants = cva5(
  "relative grid w-full grid-cols-[0_1fr] items-start gap-y-0.5 rounded-lg border px-4 py-3 text-sm has-[>svg]:grid-cols-[calc(var(--spacing)*4)_1fr] has-[>svg]:gap-x-3 has-[>[data-slot=alert-action]]:grid-cols-[0_1fr_auto] has-[>[data-slot=alert-action]]:gap-x-3 has-[>svg]:has-[>[data-slot=alert-action]]:grid-cols-[calc(var(--spacing)*4)_1fr_auto] [&>svg]:size-4 [&>svg]:translate-y-0.5 [&>svg]:text-current",
  {
    variants: {
      variant: {
        default: "bg-card text-card-foreground",
        destructive: "bg-card text-destructive *:data-[slot=alert-description]:text-destructive [&>svg]:text-current"
      }
    },
    defaultVariants: {
      variant: "default"
    }
  }
);
function Alert({ className, variant = "default", ...props }) {
  return /* @__PURE__ */ jsx50("div", { "data-slot": "alert", role: "alert", className: cn(alertVariants({ variant }), className), ...props });
}
function AlertTitle({ className, ...props }) {
  return /* @__PURE__ */ jsx50(
    "div",
    {
      "data-slot": "alert-title",
      className: cn("col-start-2 line-clamp-1 min-h-4 font-medium tracking-tight", className),
      ...props
    }
  );
}
function AlertDescription({ className, ...props }) {
  return /* @__PURE__ */ jsx50(
    "div",
    {
      "data-slot": "alert-description",
      className: cn(
        "col-start-2 grid justify-items-start gap-1 text-sm text-muted-foreground [&_p]:leading-relaxed",
        className
      ),
      ...props
    }
  );
}
function AlertAction({ className, ...props }) {
  return /* @__PURE__ */ jsx50(
    "div",
    {
      "data-slot": "alert-action",
      className: cn("col-start-3 row-span-2 row-start-1 self-start justify-self-end", className),
      ...props
    }
  );
}

// components/site/previews/alert.tsx
import { Fragment as Fragment9, jsx as jsx51, jsxs as jsxs26 } from "react/jsx-runtime";
var previewVariantOptions5 = ["default", "destructive"];
function AlertPreview() {
  const { control, choose } = usePreviewVariant("Alert", previewVariantOptions5);
  return /* @__PURE__ */ jsxs26(Fragment9, { children: [
    control,
    /* @__PURE__ */ jsx51(PreviewStack, { children: /* @__PURE__ */ jsxs26("div", { className: "grid w-full max-w-lg gap-3", children: [
      /* @__PURE__ */ jsxs26(Alert, { variant: choose("default"), children: [
        /* @__PURE__ */ jsx51(CircleAlertIcon, {}),
        /* @__PURE__ */ jsx51(AlertTitle, { children: "Registry ready" }),
        /* @__PURE__ */ jsx51(AlertDescription, { children: "58 components are available to install." })
      ] }),
      /* @__PURE__ */ jsxs26(Alert, { variant: choose("destructive"), children: [
        /* @__PURE__ */ jsx51(TriangleAlertIcon, {}),
        /* @__PURE__ */ jsx51(AlertTitle, { children: "Deploy failed" }),
        /* @__PURE__ */ jsx51(AlertDescription, { children: "Build 42 exited with code 1. The previous release is still live." }),
        /* @__PURE__ */ jsx51(AlertAction, { children: /* @__PURE__ */ jsx51(Button, { variant: "outline", size: "sm", children: "Retry" }) })
      ] }),
      /* @__PURE__ */ jsxs26(Alert, { variant: choose("default"), children: [
        /* @__PURE__ */ jsx51(AlertTitle, { children: "No icon, no action" }),
        /* @__PURE__ */ jsx51(AlertDescription, { children: "The icon column collapses to zero and the text sits flush left." })
      ] })
    ] }) })
  ] });
}

// components/site/previews/empty.tsx
import { InboxIcon, PlusIcon as PlusIcon2 } from "lucide-react";

// registry/cadence/empty/index.tsx
import { cva as cva6 } from "class-variance-authority";
import { jsx as jsx52 } from "react/jsx-runtime";
function Empty({ className, ...props }) {
  return /* @__PURE__ */ jsx52(
    "div",
    {
      "data-slot": "empty",
      className: cn(
        "flex min-w-0 flex-1 flex-col items-center justify-center gap-6 rounded-lg p-6 text-center text-balance md:p-12",
        className
      ),
      ...props
    }
  );
}
function EmptyHeader({ className, ...props }) {
  return /* @__PURE__ */ jsx52(
    "div",
    {
      "data-slot": "empty-header",
      className: cn("flex max-w-sm flex-col items-center gap-2 text-center", className),
      ...props
    }
  );
}
var emptyMediaVariants = cva6(
  "mb-2 flex shrink-0 items-center justify-center [&_svg]:pointer-events-none [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "bg-transparent",
        icon: "flex size-10 shrink-0 items-center justify-center rounded-lg bg-muted text-foreground [&_svg:not([class*='size-'])]:size-6"
      }
    },
    defaultVariants: {
      variant: "default"
    }
  }
);
function EmptyMedia({ className, variant = "default", ...props }) {
  return /* @__PURE__ */ jsx52(
    "div",
    {
      "data-slot": "empty-icon",
      "data-variant": variant,
      className: cn(emptyMediaVariants({ variant }), className),
      ...props
    }
  );
}
function EmptyTitle({ className, ...props }) {
  return /* @__PURE__ */ jsx52("div", { "data-slot": "empty-title", className: cn("text-lg font-medium tracking-tight", className), ...props });
}
function EmptyDescription({ className, ...props }) {
  return /* @__PURE__ */ jsx52(
    "div",
    {
      "data-slot": "empty-description",
      className: cn(
        "text-sm/relaxed text-muted-foreground [&>a]:underline [&>a]:underline-offset-4 [&>a:hover]:text-primary",
        className
      ),
      ...props
    }
  );
}
function EmptyContent({ className, ...props }) {
  return /* @__PURE__ */ jsx52(
    "div",
    {
      "data-slot": "empty-content",
      className: cn("flex w-full max-w-sm min-w-0 flex-col items-center gap-4 text-sm text-balance", className),
      ...props
    }
  );
}

// components/site/previews/empty.tsx
import { Fragment as Fragment10, jsx as jsx53, jsxs as jsxs27 } from "react/jsx-runtime";
var previewVariantOptions6 = ["default", "icon"];
function EmptyPreview() {
  const { control, choose } = usePreviewVariant("Empty", previewVariantOptions6);
  return /* @__PURE__ */ jsxs27(Fragment10, { children: [
    control,
    /* @__PURE__ */ jsx53(PreviewStack, { children: /* @__PURE__ */ jsxs27("div", { className: "grid w-full max-w-xl grid-cols-1 items-start sm:grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsxs27(Empty, { children: [
        /* @__PURE__ */ jsxs27(EmptyHeader, { children: [
          /* @__PURE__ */ jsx53(EmptyMedia, { variant: choose("icon"), children: /* @__PURE__ */ jsx53(InboxIcon, {}) }),
          /* @__PURE__ */ jsx53(EmptyTitle, { children: "No invoices yet" }),
          /* @__PURE__ */ jsx53(EmptyDescription, { children: "Invoices you send will land here." })
        ] }),
        /* @__PURE__ */ jsx53(EmptyContent, { children: /* @__PURE__ */ jsxs27(Button, { size: "sm", children: [
          /* @__PURE__ */ jsx53(PlusIcon2, {}),
          "Create invoice"
        ] }) })
      ] }),
      /* @__PURE__ */ jsx53(Empty, { className: "border", children: /* @__PURE__ */ jsxs27(EmptyHeader, { children: [
        /* @__PURE__ */ jsx53(EmptyTitle, { children: "Nothing to review" }),
        /* @__PURE__ */ jsx53(EmptyDescription, { children: "Title and description only." })
      ] }) })
    ] }) })
  ] });
}

// components/site/previews/item.tsx
import { DownloadIcon, FileTextIcon, FolderIcon } from "lucide-react";

// registry/cadence/item/index.tsx
import { mergeProps as mergeProps2 } from "@base-ui/react/merge-props";
import { useRender as useRender2 } from "@base-ui/react/use-render";
import { cva as cva7 } from "class-variance-authority";
import { jsx as jsx54 } from "react/jsx-runtime";
function ItemGroup({ className, ...props }) {
  return /* @__PURE__ */ jsx54(
    "div",
    {
      role: "group",
      "data-slot": "item-group",
      className: cn("group/item-group flex w-full flex-col", className),
      ...props
    }
  );
}
var itemVariants = cva7(
  "group/item flex w-full flex-wrap items-center rounded-md border border-transparent text-sm transition-colors outline-none focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 [a]:transition-colors [a]:hover:bg-accent/50",
  {
    variants: {
      variant: {
        default: "bg-transparent",
        outline: "border-border",
        muted: "bg-muted/50"
      },
      size: {
        default: "gap-4 p-4",
        sm: "gap-2.5 px-4 py-3",
        xs: "gap-2 px-3 py-2"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
function Item({ className, variant = "default", size = "default", render, ...props }) {
  return useRender2({
    defaultTagName: "div",
    props: mergeProps2({ className: cn(itemVariants({ variant, size }), className) }, props),
    render,
    // `state` is what emits `data-slot` / `data-variant` / `data-size`.
    state: { slot: "item", variant, size }
  });
}
var itemMediaVariants = cva7(
  "flex shrink-0 items-center justify-center gap-2 group-has-[[data-slot=item-description]]/item:translate-y-0.5 group-has-[[data-slot=item-description]]/item:self-start [&_svg]:pointer-events-none",
  {
    variants: {
      variant: {
        default: "bg-transparent",
        icon: "size-8 rounded-sm border bg-muted [&_svg:not([class*='size-'])]:size-4",
        image: "size-10 overflow-hidden rounded-sm [&_img]:size-full [&_img]:object-cover"
      }
    },
    defaultVariants: {
      variant: "default"
    }
  }
);
function ItemMedia({ className, variant = "default", ...props }) {
  return /* @__PURE__ */ jsx54(
    "div",
    {
      "data-slot": "item-media",
      "data-variant": variant,
      className: cn(itemMediaVariants({ variant }), className),
      ...props
    }
  );
}
function ItemContent({ className, ...props }) {
  return /* @__PURE__ */ jsx54(
    "div",
    {
      "data-slot": "item-content",
      className: cn("flex flex-1 flex-col gap-1 [&+[data-slot=item-content]]:flex-none", className),
      ...props
    }
  );
}
function ItemTitle({ className, ...props }) {
  return /* @__PURE__ */ jsx54(
    "div",
    {
      "data-slot": "item-title",
      className: cn("flex w-fit items-center gap-2 text-sm leading-snug font-medium", className),
      ...props
    }
  );
}
function ItemDescription({ className, ...props }) {
  return /* @__PURE__ */ jsx54(
    "p",
    {
      "data-slot": "item-description",
      className: cn(
        "line-clamp-2 text-sm leading-normal font-normal text-balance text-muted-foreground [&>a]:underline [&>a]:underline-offset-4 [&>a:hover]:text-primary",
        className
      ),
      ...props
    }
  );
}
function ItemActions({ className, ...props }) {
  return /* @__PURE__ */ jsx54("div", { "data-slot": "item-actions", className: cn("flex items-center gap-2", className), ...props });
}
function ItemHeader({ className, ...props }) {
  return /* @__PURE__ */ jsx54(
    "div",
    {
      "data-slot": "item-header",
      className: cn("flex basis-full items-center justify-between gap-2", className),
      ...props
    }
  );
}
function ItemFooter({ className, ...props }) {
  return /* @__PURE__ */ jsx54(
    "div",
    {
      "data-slot": "item-footer",
      className: cn("flex basis-full items-center justify-between gap-2", className),
      ...props
    }
  );
}

// components/site/previews/item.tsx
import { Fragment as Fragment11, jsx as jsx55, jsxs as jsxs28 } from "react/jsx-runtime";
var previewVariantOptions7 = ["default", "muted", "outline"];
function ItemPreview() {
  const { control, choose } = usePreviewVariant("Item", previewVariantOptions7);
  return /* @__PURE__ */ jsxs28(Fragment11, { children: [
    control,
    /* @__PURE__ */ jsx55(PreviewStack, { children: /* @__PURE__ */ jsxs28("div", { className: "grid w-full max-w-2xl grid-cols-1 items-start sm:grid-cols-2 gap-4", children: [
      /* @__PURE__ */ jsxs28(ItemGroup, { children: [
        /* @__PURE__ */ jsxs28(Item, { variant: choose("default"), children: [
          /* @__PURE__ */ jsx55(ItemMedia, { variant: "icon", children: /* @__PURE__ */ jsx55(FileTextIcon, {}) }),
          /* @__PURE__ */ jsxs28(ItemContent, { children: [
            /* @__PURE__ */ jsx55(ItemTitle, { children: "parity-plan.md" }),
            /* @__PURE__ */ jsx55(ItemDescription, { children: "Edited 4 minutes ago" })
          ] }),
          /* @__PURE__ */ jsx55(ItemActions, { children: /* @__PURE__ */ jsx55(Button, { variant: "ghost", size: "icon-sm", "aria-label": "Download parity-plan.md", children: /* @__PURE__ */ jsx55(DownloadIcon, {}) }) })
        ] }),
        /* @__PURE__ */ jsxs28(Item, { variant: choose("muted"), children: [
          /* @__PURE__ */ jsx55(ItemMedia, { variant: "icon", children: /* @__PURE__ */ jsx55(FolderIcon, {}) }),
          /* @__PURE__ */ jsxs28(ItemContent, { children: [
            /* @__PURE__ */ jsx55(ItemTitle, { children: "registry" }),
            /* @__PURE__ */ jsx55(ItemDescription, { children: "65 items, 58 components" })
          ] }),
          /* @__PURE__ */ jsx55(ItemActions, { children: /* @__PURE__ */ jsx55(Badge, { variant: "secondary", children: "v0.2.0" }) })
        ] }),
        /* @__PURE__ */ jsx55(Item, { variant: choose("outline"), size: "sm", children: /* @__PURE__ */ jsxs28(ItemContent, { children: [
          /* @__PURE__ */ jsx55(ItemTitle, { children: "Dense row" }),
          /* @__PURE__ */ jsx55(ItemDescription, { children: 'size="sm" tightens the padding' })
        ] }) })
      ] }),
      /* @__PURE__ */ jsxs28(ItemGroup, { children: [
        /* @__PURE__ */ jsxs28(Item, { render: /* @__PURE__ */ jsx55("a", { href: "#item-link" }), variant: choose("outline"), children: [
          /* @__PURE__ */ jsx55(ItemMedia, { variant: "image", children: /* @__PURE__ */ jsx55("img", { src: "https://github.com/shadcn.png", alt: "" }) }),
          /* @__PURE__ */ jsxs28(ItemContent, { children: [
            /* @__PURE__ */ jsxs28(ItemHeader, { children: [
              /* @__PURE__ */ jsx55(ItemTitle, { children: "Whole-row link" }),
              /* @__PURE__ */ jsx55(Badge, { variant: "outline", children: "render" })
            ] }),
            /* @__PURE__ */ jsx55(ItemDescription, { children: "The row is one anchor, with no nested interactive elements." }),
            /* @__PURE__ */ jsx55(ItemFooter, { children: /* @__PURE__ */ jsx55("span", { className: "text-xs text-muted-foreground", children: "data-slot=item" }) })
          ] })
        ] }),
        /* @__PURE__ */ jsxs28(Item, { size: "xs", variant: choose("default"), children: [
          /* @__PURE__ */ jsx55(ItemMedia, { variant: "icon", children: /* @__PURE__ */ jsx55(FolderIcon, {}) }),
          /* @__PURE__ */ jsx55(ItemContent, { children: /* @__PURE__ */ jsx55(ItemTitle, { children: 'size="xs"' }) })
        ] })
      ] })
    ] }) })
  ] });
}

// components/site/previews/field.tsx
import { useState as useState16 } from "react";
import { Fragment as Fragment12, jsx as jsx56, jsxs as jsxs29 } from "react/jsx-runtime";
var previewVariantOptions8 = ["vertical", "horizontal", "responsive"];
function FieldPreview() {
  const { control, choose } = usePreviewVariant("Field", previewVariantOptions8);
  const [invalid, setInvalid] = useState16(true);
  return /* @__PURE__ */ jsxs29(Fragment12, { children: [
    control,
    /* @__PURE__ */ jsx56(PreviewStack, { children: /* @__PURE__ */ jsxs29(FieldSet, { className: "w-full max-w-lg gap-3", children: [
      /* @__PURE__ */ jsx56(FieldLegend, { children: "Billing details" }),
      /* @__PURE__ */ jsxs29(FieldGroup, { className: "gap-3", children: [
        /* @__PURE__ */ jsxs29(Field, { orientation: choose("responsive"), children: [
          /* @__PURE__ */ jsx56(FieldLabel, { htmlFor: "field-name", children: "Company" }),
          /* @__PURE__ */ jsxs29(FieldContent, { children: [
            /* @__PURE__ */ jsx56(Input, { id: "field-name", placeholder: "Cadence Labs" }),
            /* @__PURE__ */ jsx56(FieldDescription, { children: "Appears on the invoice header." })
          ] })
        ] }),
        /* @__PURE__ */ jsxs29(Field, { "data-invalid": invalid, orientation: choose("vertical"), children: [
          /* @__PURE__ */ jsx56(FieldLabel, { htmlFor: "field-vat", children: "VAT number" }),
          /* @__PURE__ */ jsxs29(FieldContent, { children: [
            /* @__PURE__ */ jsx56(
              Input,
              {
                id: "field-vat",
                "aria-invalid": invalid,
                defaultValue: "NL0000",
                "aria-describedby": invalid ? "field-vat-error" : void 0
              }
            ),
            /* @__PURE__ */ jsx56(FieldError, { id: "field-vat-error", children: invalid ? "That VAT number has the wrong number of digits." : null })
          ] })
        ] }),
        /* @__PURE__ */ jsxs29(Field, { orientation: choose("horizontal"), children: [
          /* @__PURE__ */ jsxs29(FieldContent, { children: [
            /* @__PURE__ */ jsx56(FieldLabel, { htmlFor: "field-currency", children: "Currency" }),
            /* @__PURE__ */ jsx56(FieldDescription, { children: "Invoices are issued in this currency." })
          ] }),
          /* @__PURE__ */ jsx56(Input, { id: "field-currency", className: "w-20", defaultValue: "EUR" })
        ] }),
        /* @__PURE__ */ jsx56(FieldSeparator, { children: "or" }),
        /* @__PURE__ */ jsxs29(Field, { orientation: choose("horizontal"), className: "flex-wrap", children: [
          /* @__PURE__ */ jsx56(Button, { size: "sm", variant: "outline", onClick: () => setInvalid((value) => !value), children: "Toggle supplied error" }),
          /* @__PURE__ */ jsx56(Button, { size: "sm", children: "Save" }),
          /* @__PURE__ */ jsx56(Button, { size: "sm", variant: "ghost", children: "Cancel" })
        ] })
      ] })
    ] }) })
  ] });
}

// components/site/previews/button-group.tsx
import { BoldIcon, ItalicIcon, UnderlineIcon } from "lucide-react";

// registry/cadence/button-group/index.tsx
import { mergeProps as mergeProps3 } from "@base-ui/react/merge-props";
import { useRender as useRender3 } from "@base-ui/react/use-render";
import { cva as cva8 } from "class-variance-authority";
import { jsx as jsx57 } from "react/jsx-runtime";
var buttonGroupVariants = cva8(
  "flex w-fit items-stretch has-[>[data-slot=button-group]]:gap-2 [&>*]:focus-visible:relative [&>*]:focus-visible:z-10 has-[select[aria-hidden=true]:last-child]:[&>[data-slot=select-trigger]:last-of-type]:rounded-r-md [&>[data-slot=select-trigger]:not([class*='w-'])]:w-fit [&>input]:flex-1",
  {
    variants: {
      orientation: {
        horizontal: "[&>*:not(:first-child)]:rounded-l-none [&>*:not(:first-child)]:border-l-0 [&>*:not(:last-child)]:rounded-r-none",
        vertical: "flex-col [&>*:not(:first-child)]:rounded-t-none [&>*:not(:first-child)]:border-t-0 [&>*:not(:last-child)]:rounded-b-none"
      }
    },
    defaultVariants: {
      orientation: "horizontal"
    }
  }
);
function ButtonGroup({ className, orientation = "horizontal", ...props }) {
  return /* @__PURE__ */ jsx57(
    "div",
    {
      role: "group",
      "data-slot": "button-group",
      "data-orientation": orientation,
      className: cn(buttonGroupVariants({ orientation }), className),
      ...props
    }
  );
}
function ButtonGroupText({ className, render, ...props }) {
  return useRender3({
    defaultTagName: "div",
    props: mergeProps3(
      {
        className: cn(
          "flex items-center gap-2 rounded-md border bg-muted px-4 text-sm font-medium shadow-xs [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4",
          className
        )
      },
      props
    ),
    render,
    // `state` is what emits `data-slot` — Base UI converts state keys to data-* attributes.
    state: { slot: "button-group-text" }
  });
}
function ButtonGroupSeparator({ className, orientation = "vertical", ...props }) {
  return /* @__PURE__ */ jsx57(
    Separator,
    {
      "data-slot": "button-group-separator",
      orientation,
      className: (state) => cn(
        "relative m-0! self-stretch bg-input data-[orientation=vertical]:h-auto",
        typeof className === "function" ? className(state) : className
      ),
      ...props
    }
  );
}

// components/site/previews/button-group.tsx
import { Fragment as Fragment13, jsx as jsx58, jsxs as jsxs30 } from "react/jsx-runtime";
var previewVariantOptions9 = ["horizontal", "vertical"];
function ButtonGroupPreview() {
  const { control, choose } = usePreviewVariant("ButtonGroup", previewVariantOptions9);
  return /* @__PURE__ */ jsxs30(Fragment13, { children: [
    control,
    /* @__PURE__ */ jsxs30(PreviewStack, { children: [
      /* @__PURE__ */ jsxs30(PreviewRow, { className: "gap-4", children: [
        /* @__PURE__ */ jsxs30(ButtonGroup, { "aria-label": "Text style", orientation: choose("horizontal"), children: [
          /* @__PURE__ */ jsx58(Button, { variant: "outline", size: "icon-sm", "aria-label": "Bold", children: /* @__PURE__ */ jsx58(BoldIcon, {}) }),
          /* @__PURE__ */ jsx58(Button, { variant: "outline", size: "icon-sm", "aria-label": "Italic", children: /* @__PURE__ */ jsx58(ItalicIcon, {}) }),
          /* @__PURE__ */ jsx58(Button, { variant: "outline", size: "icon-sm", "aria-label": "Underline", children: /* @__PURE__ */ jsx58(UnderlineIcon, {}) })
        ] }),
        /* @__PURE__ */ jsxs30(ButtonGroup, { "aria-label": "Zoom", orientation: choose("horizontal"), children: [
          /* @__PURE__ */ jsx58(ButtonGroupText, { children: "-" }),
          /* @__PURE__ */ jsx58(Button, { variant: "outline", size: "sm", children: "100%" }),
          /* @__PURE__ */ jsx58(ButtonGroupSeparator, {}),
          /* @__PURE__ */ jsx58(ButtonGroupText, { children: "+" })
        ] })
      ] }),
      /* @__PURE__ */ jsx58(PreviewRow, { children: /* @__PURE__ */ jsxs30(ButtonGroup, { orientation: choose("vertical"), "aria-label": "Order", children: [
        /* @__PURE__ */ jsx58(Button, { variant: "outline", size: "sm", children: "Move up" }),
        /* @__PURE__ */ jsx58(Button, { variant: "outline", size: "sm", children: "Move down" }),
        /* @__PURE__ */ jsx58(Button, { variant: "outline", size: "sm", children: "Duplicate" })
      ] }) })
    ] })
  ] });
}

// components/site/previews/input-group.tsx
import { MailIcon, SearchIcon, XIcon } from "lucide-react";

// registry/cadence/input-group/index.tsx
import { cva as cva9 } from "class-variance-authority";
import { jsx as jsx59 } from "react/jsx-runtime";
function InputGroup({ className, ...props }) {
  return /* @__PURE__ */ jsx59(
    "div",
    {
      "data-slot": "input-group",
      role: "group",
      className: cn(
        "group/input-group relative flex w-full min-w-0 items-center rounded-md border border-input shadow-xs transition-[color,box-shadow] outline-none dark:bg-input/30",
        "h-9 has-[>textarea]:h-auto",
        // Alignment decides which side the control gives up padding on.
        "has-[>[data-align=inline-start]]:[&>input]:pl-2",
        "has-[>[data-align=inline-end]]:[&>input]:pr-2",
        "has-[>[data-align=block-start]]:h-auto has-[>[data-align=block-start]]:flex-col has-[>[data-align=block-start]]:[&>input]:pb-3",
        "has-[>[data-align=block-end]]:h-auto has-[>[data-align=block-end]]:flex-col has-[>[data-align=block-end]]:[&>input]:pt-3",
        // Focus and invalid state are borrowed from the control, not owned here.
        "has-[[data-slot=input-group-control]:focus-visible]:border-ring has-[[data-slot=input-group-control]:focus-visible]:ring-[3px] has-[[data-slot=input-group-control]:focus-visible]:ring-ring/50",
        "has-[[data-slot][aria-invalid=true]]:border-destructive has-[[data-slot][aria-invalid=true]]:ring-destructive/20 dark:has-[[data-slot][aria-invalid=true]]:ring-destructive/40",
        className
      ),
      ...props
    }
  );
}
var inputGroupAddonVariants = cva9(
  "flex h-auto cursor-text items-center justify-center gap-2 py-1.5 text-sm font-medium text-muted-foreground select-none group-data-[disabled=true]/input-group:opacity-50 [&>kbd]:rounded-[calc(var(--radius)-5px)] [&>svg:not([class*='size-'])]:size-4",
  {
    variants: {
      align: {
        "inline-start": "order-first pl-3 has-[>button]:ml-[-0.45rem] has-[>kbd]:ml-[-0.35rem]",
        "inline-end": "order-last pr-3 has-[>button]:mr-[-0.45rem] has-[>kbd]:mr-[-0.35rem]",
        "block-start": "order-first w-full justify-start px-3 pt-3 group-has-[>input]/input-group:pt-2.5 [.border-b]:pb-3",
        "block-end": "order-last w-full justify-start px-3 pb-3 group-has-[>input]/input-group:pb-2.5 [.border-t]:pt-3"
      }
    },
    defaultVariants: {
      align: "inline-start"
    }
  }
);
function InputGroupAddon({ className, align = "inline-start", onClick, ...props }) {
  return /* @__PURE__ */ jsx59(
    "div",
    {
      role: "group",
      "data-slot": "input-group-addon",
      "data-align": align,
      className: cn(inputGroupAddonVariants({ align }), className),
      onClick: (event) => {
        onClick?.(event);
        if (event.defaultPrevented) return;
        if (event.target.closest("button")) {
          return;
        }
        event.currentTarget.parentElement?.querySelector("input")?.focus();
      },
      ...props
    }
  );
}
var inputGroupButtonVariants = cva9("flex items-center gap-2 text-sm shadow-none", {
  variants: {
    size: {
      xs: "h-6 gap-1 rounded-[calc(var(--radius)-5px)] px-2 has-[>svg]:px-2 [&>svg:not([class*='size-'])]:size-3.5",
      sm: "h-8 gap-1.5 rounded-md px-2.5 has-[>svg]:px-2.5",
      "icon-xs": "size-6 rounded-[calc(var(--radius)-5px)] p-0 has-[>svg]:p-0",
      "icon-sm": "size-8 p-0 has-[>svg]:p-0"
    }
  },
  defaultVariants: {
    size: "xs"
  }
});
function InputGroupButton({
  className,
  type = "button",
  variant = "ghost",
  size = "xs",
  ...props
}) {
  return /* @__PURE__ */ jsx59(
    Button,
    {
      type,
      variant,
      size,
      className: (state) => cn(inputGroupButtonVariants({ size }), typeof className === "function" ? className(state) : className),
      ...props
    }
  );
}
function InputGroupText({ className, ...props }) {
  return /* @__PURE__ */ jsx59(
    "span",
    {
      className: cn(
        "flex items-center gap-2 text-sm text-muted-foreground [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4",
        className
      ),
      ...props
    }
  );
}
function InputGroupInput({ className, ...props }) {
  return /* @__PURE__ */ jsx59(
    Input,
    {
      "data-slot": "input-group-control",
      className: cn(
        "flex-1 rounded-none border-0 bg-transparent shadow-none focus-visible:ring-0 dark:bg-transparent",
        className
      ),
      ...props
    }
  );
}
function InputGroupTextarea({ className, ...props }) {
  return /* @__PURE__ */ jsx59(
    Textarea,
    {
      "data-slot": "input-group-control",
      className: cn(
        "flex-1 resize-none rounded-none border-0 bg-transparent py-3 shadow-none focus-visible:ring-0 dark:bg-transparent",
        className
      ),
      ...props
    }
  );
}

// components/site/previews/input-group.tsx
import { Fragment as Fragment14, jsx as jsx60, jsxs as jsxs31 } from "react/jsx-runtime";
var previewVariantOptions10 = ["inline-start", "inline-end", "block-start", "block-end"];
function InputGroupPreview() {
  const { control, choose } = usePreviewVariant("InputGroup", previewVariantOptions10);
  return /* @__PURE__ */ jsxs31(Fragment14, { children: [
    control,
    /* @__PURE__ */ jsx60(PreviewStack, { children: /* @__PURE__ */ jsxs31("div", { className: "grid w-full max-w-sm gap-3", children: [
      /* @__PURE__ */ jsxs31(InputGroup, { children: [
        /* @__PURE__ */ jsx60(InputGroupAddon, { align: choose("inline-start"), children: /* @__PURE__ */ jsx60(SearchIcon, {}) }),
        /* @__PURE__ */ jsx60(InputGroupInput, { placeholder: "Search components", "aria-label": "Search components" }),
        /* @__PURE__ */ jsx60(InputGroupAddon, { align: choose("inline-end"), children: /* @__PURE__ */ jsx60(Kbd, { children: "\u2318K" }) })
      ] }),
      /* @__PURE__ */ jsxs31(InputGroup, { children: [
        /* @__PURE__ */ jsx60(InputGroupAddon, { align: choose("inline-start"), children: /* @__PURE__ */ jsx60(InputGroupText, { children: "https://" }) }),
        /* @__PURE__ */ jsx60(InputGroupInput, { placeholder: "cadence.dev", "aria-label": "Domain" }),
        /* @__PURE__ */ jsx60(InputGroupAddon, { align: choose("inline-end"), children: /* @__PURE__ */ jsx60(InputGroupButton, { size: "xs", "aria-label": "Clear domain", children: /* @__PURE__ */ jsx60(XIcon, {}) }) })
      ] }),
      /* @__PURE__ */ jsxs31(InputGroup, { children: [
        /* @__PURE__ */ jsx60(InputGroupAddon, { align: choose("inline-start"), children: /* @__PURE__ */ jsx60(InputGroupText, { children: /* @__PURE__ */ jsx60(MailIcon, {}) }) }),
        /* @__PURE__ */ jsx60(InputGroupInput, { type: "email", placeholder: "you@studio.com", "aria-label": "Email", "aria-invalid": true }),
        /* @__PURE__ */ jsx60(InputGroupAddon, { align: choose("inline-end"), children: /* @__PURE__ */ jsx60(Button, { size: "sm", variant: "secondary", children: "Invite" }) })
      ] }),
      /* @__PURE__ */ jsxs31(InputGroup, { children: [
        /* @__PURE__ */ jsx60(InputGroupTextarea, { rows: 2, placeholder: "Leave a note for the reviewer\u2026", "aria-label": "Note" }),
        /* @__PURE__ */ jsxs31(InputGroupAddon, { align: choose("block-end"), children: [
          /* @__PURE__ */ jsx60(InputGroupText, { className: "text-xs", children: "Markdown is fine." }),
          /* @__PURE__ */ jsx60(InputGroupButton, { size: "sm", variant: "default", className: "ml-auto", children: "Send" })
        ] })
      ] })
    ] }) })
  ] });
}

// registry/cadence/breadcrumb/index.tsx
import { mergeProps as mergeProps4 } from "@base-ui/react/merge-props";
import { useRender as useRender4 } from "@base-ui/react/use-render";
import { ChevronRight, MoreHorizontal } from "lucide-react";
import { jsx as jsx61, jsxs as jsxs32 } from "react/jsx-runtime";
function Breadcrumb({ className, ...props }) {
  return /* @__PURE__ */ jsx61("nav", { "aria-label": "breadcrumb", "data-slot": "breadcrumb", className: cn(className), ...props });
}
function BreadcrumbList({ className, ...props }) {
  return /* @__PURE__ */ jsx61(
    "ol",
    {
      "data-slot": "breadcrumb-list",
      className: cn(
        "flex flex-wrap items-center gap-1.5 text-sm break-words text-muted-foreground sm:gap-2.5",
        className
      ),
      ...props
    }
  );
}
function BreadcrumbItem({ className, ...props }) {
  return /* @__PURE__ */ jsx61("li", { "data-slot": "breadcrumb-item", className: cn("inline-flex items-center gap-1.5", className), ...props });
}
function BreadcrumbLink({ className, render, ...props }) {
  return useRender4({
    defaultTagName: "a",
    props: mergeProps4({ className: cn("transition-colors hover:text-foreground", className) }, props),
    render,
    // `state` is what emits `data-slot` — Base UI converts state keys to data-* attributes.
    state: { slot: "breadcrumb-link" }
  });
}
function BreadcrumbPage({ className, ...props }) {
  return /* @__PURE__ */ jsx61(
    "span",
    {
      "data-slot": "breadcrumb-page",
      role: "link",
      "aria-disabled": "true",
      "aria-current": "page",
      className: cn("font-normal text-foreground", className),
      ...props
    }
  );
}
function BreadcrumbSeparator({ children, className, ...props }) {
  return /* @__PURE__ */ jsx61(
    "li",
    {
      "data-slot": "breadcrumb-separator",
      role: "presentation",
      "aria-hidden": "true",
      className: cn("[&>svg]:size-3.5", className),
      ...props,
      children: children ?? /* @__PURE__ */ jsx61(ChevronRight, {})
    }
  );
}
function BreadcrumbEllipsis({ className, ...props }) {
  return /* @__PURE__ */ jsxs32(
    "span",
    {
      "data-slot": "breadcrumb-ellipsis",
      role: "presentation",
      "aria-hidden": "true",
      className: cn("flex size-9 items-center justify-center", className),
      ...props,
      children: [
        /* @__PURE__ */ jsx61(MoreHorizontal, { className: "size-4" }),
        /* @__PURE__ */ jsx61("span", { className: "sr-only", children: "More" })
      ]
    }
  );
}

// components/site/previews/breadcrumb.tsx
import { jsx as jsx62, jsxs as jsxs33 } from "react/jsx-runtime";
function BreadcrumbPreview() {
  return /* @__PURE__ */ jsx62(PreviewStack, { children: /* @__PURE__ */ jsxs33("div", { className: "grid gap-4", children: [
    /* @__PURE__ */ jsx62(Breadcrumb, { children: /* @__PURE__ */ jsxs33(BreadcrumbList, { children: [
      /* @__PURE__ */ jsx62(BreadcrumbItem, { children: /* @__PURE__ */ jsx62(BreadcrumbLink, { href: "#breadcrumb", children: "Workspace" }) }),
      /* @__PURE__ */ jsx62(BreadcrumbSeparator, {}),
      /* @__PURE__ */ jsx62(BreadcrumbItem, { children: /* @__PURE__ */ jsx62(BreadcrumbLink, { href: "#breadcrumb", children: "Projects" }) }),
      /* @__PURE__ */ jsx62(BreadcrumbSeparator, {}),
      /* @__PURE__ */ jsx62(BreadcrumbItem, { children: /* @__PURE__ */ jsx62(BreadcrumbPage, { children: "cadence-ui" }) })
    ] }) }),
    /* @__PURE__ */ jsx62(Breadcrumb, { children: /* @__PURE__ */ jsxs33(BreadcrumbList, { children: [
      /* @__PURE__ */ jsx62(BreadcrumbItem, { children: /* @__PURE__ */ jsx62(BreadcrumbLink, { href: "#breadcrumb", children: "Workspace" }) }),
      /* @__PURE__ */ jsx62(BreadcrumbSeparator, {}),
      /* @__PURE__ */ jsx62(BreadcrumbItem, { children: /* @__PURE__ */ jsx62(BreadcrumbEllipsis, {}) }),
      /* @__PURE__ */ jsx62(BreadcrumbSeparator, { children: /* @__PURE__ */ jsx62("span", { className: "text-muted-foreground/60", children: "/" }) }),
      /* @__PURE__ */ jsx62(BreadcrumbItem, { children: /* @__PURE__ */ jsx62(BreadcrumbLink, { href: "#breadcrumb", children: "registry" }) }),
      /* @__PURE__ */ jsx62(BreadcrumbSeparator, { children: /* @__PURE__ */ jsx62("span", { className: "text-muted-foreground/60", children: "/" }) }),
      /* @__PURE__ */ jsx62(BreadcrumbItem, { children: /* @__PURE__ */ jsx62(BreadcrumbPage, { children: "dialog.tsx" }) })
    ] }) })
  ] }) });
}

// registry/cadence/pagination/index.tsx
import { ChevronLeftIcon, ChevronRightIcon, MoreHorizontalIcon } from "lucide-react";
import { jsx as jsx63, jsxs as jsxs34 } from "react/jsx-runtime";
function Pagination({ className, ...props }) {
  return /* @__PURE__ */ jsx63(
    "nav",
    {
      "aria-label": "pagination",
      "data-slot": "pagination",
      className: cn("mx-auto flex w-full justify-center", className),
      ...props
    }
  );
}
function PaginationContent({ className, ...props }) {
  return /* @__PURE__ */ jsx63("ul", { "data-slot": "pagination-content", className: cn("flex flex-row items-center gap-1", className), ...props });
}
function PaginationItem({ ...props }) {
  return /* @__PURE__ */ jsx63("li", { "data-slot": "pagination-item", ...props });
}
function PaginationLink({ className, isActive: isActive2, size = "icon", ...props }) {
  return /* @__PURE__ */ jsx63(
    "a",
    {
      "aria-current": isActive2 ? "page" : void 0,
      "data-slot": "pagination-link",
      "data-active": isActive2,
      "data-variant": isActive2 ? "outline" : "ghost",
      "data-size": size,
      className: cn(
        buttonVariants({ variant: isActive2 ? "outline" : "ghost", size }),
        "aria-disabled:opacity-50",
        className
      ),
      ...props
    }
  );
}
function PaginationPrevious({ className, text = "Previous", ...props }) {
  return /* @__PURE__ */ jsxs34(
    PaginationLink,
    {
      "aria-label": "Go to previous page",
      size: "default",
      className: cn("gap-1 px-2.5 sm:pl-2.5", className),
      ...props,
      children: [
        /* @__PURE__ */ jsx63(ChevronLeftIcon, {}),
        /* @__PURE__ */ jsx63("span", { className: "hidden sm:block", children: text })
      ]
    }
  );
}
function PaginationNext({ className, text = "Next", ...props }) {
  return /* @__PURE__ */ jsxs34(
    PaginationLink,
    {
      "aria-label": "Go to next page",
      size: "default",
      className: cn("gap-1 px-2.5 sm:pr-2.5", className),
      ...props,
      children: [
        /* @__PURE__ */ jsx63("span", { className: "hidden sm:block", children: text }),
        /* @__PURE__ */ jsx63(ChevronRightIcon, {})
      ]
    }
  );
}
function PaginationEllipsis({ className, ...props }) {
  return /* @__PURE__ */ jsxs34(
    "span",
    {
      "aria-hidden": true,
      "data-slot": "pagination-ellipsis",
      className: cn("flex size-9 items-center justify-center", className),
      ...props,
      children: [
        /* @__PURE__ */ jsx63(MoreHorizontalIcon, { className: "size-4" }),
        /* @__PURE__ */ jsx63("span", { className: "sr-only", children: "More pages" })
      ]
    }
  );
}

// components/site/previews/pagination.tsx
import { jsx as jsx64, jsxs as jsxs35 } from "react/jsx-runtime";
var sizes = ["default", "xs", "sm", "lg", "icon", "icon-xs", "icon-sm", "icon-lg"];
function PaginationPreview() {
  const { control, choose } = usePreviewVariant("Pagination", sizes);
  return /* @__PURE__ */ jsxs35(PreviewStack, { children: [
    control,
    /* @__PURE__ */ jsx64(Pagination, { children: /* @__PURE__ */ jsxs35(PaginationContent, { children: [
      /* @__PURE__ */ jsx64(PaginationItem, { children: /* @__PURE__ */ jsx64(PaginationPrevious, { size: choose("default"), href: "#pagination" }) }),
      /* @__PURE__ */ jsx64(PaginationItem, { children: /* @__PURE__ */ jsx64(PaginationLink, { size: choose("icon"), href: "#pagination", children: "1" }) }),
      /* @__PURE__ */ jsx64(PaginationItem, { children: /* @__PURE__ */ jsx64(PaginationLink, { size: choose("icon"), href: "#pagination", isActive: true, children: "2" }) }),
      /* @__PURE__ */ jsx64(PaginationItem, { children: /* @__PURE__ */ jsx64(PaginationLink, { size: choose("icon"), href: "#pagination", children: "3" }) }),
      /* @__PURE__ */ jsx64(PaginationItem, { children: /* @__PURE__ */ jsx64(PaginationEllipsis, {}) }),
      /* @__PURE__ */ jsx64(PaginationItem, { children: /* @__PURE__ */ jsx64(PaginationLink, { size: choose("icon"), href: "#pagination", children: "12" }) }),
      /* @__PURE__ */ jsx64(PaginationItem, { children: /* @__PURE__ */ jsx64(PaginationNext, { size: choose("default"), href: "#pagination" }) })
    ] }) }),
    /* @__PURE__ */ jsx64(Pagination, { children: /* @__PURE__ */ jsxs35(PaginationContent, { children: [
      /* @__PURE__ */ jsx64(PaginationItem, { children: /* @__PURE__ */ jsx64(PaginationPrevious, { size: choose("default"), href: "#pagination", text: "Back" }) }),
      /* @__PURE__ */ jsx64(PaginationItem, { children: /* @__PURE__ */ jsx64(PaginationLink, { size: choose("icon"), href: "#pagination", isActive: true, children: "1" }) }),
      /* @__PURE__ */ jsx64(PaginationItem, { children: /* @__PURE__ */ jsx64(PaginationNext, { size: choose("default"), href: "#pagination", text: "Forward" }) })
    ] }) })
  ] });
}

// components/site/previews/spinner.tsx
import { useState as useState17 } from "react";

// registry/cadence/spinner/index.tsx
import { Loader2Icon } from "lucide-react";
import { jsx as jsx65 } from "react/jsx-runtime";
function Spinner({ className, ...props }) {
  const cm = useCadenceMotion();
  const spin = cm.mode === "none" ? "animate-none" : "animate-spin";
  return /* @__PURE__ */ jsx65(
    Loader2Icon,
    {
      "data-slot": "spinner",
      "data-motion": cm.mode,
      role: "status",
      "aria-label": "Loading",
      className: cn("size-4", spin, className),
      ...props
    }
  );
}

// components/site/previews/spinner.tsx
import { jsx as jsx66, jsxs as jsxs36 } from "react/jsx-runtime";
function SpinnerPreview() {
  const [mode, setMode] = useState17("inherit");
  return /* @__PURE__ */ jsxs36(PreviewStack, { children: [
    /* @__PURE__ */ jsxs36("label", { className: "flex gap-2 text-sm", children: [
      "Spinner motion",
      /* @__PURE__ */ jsx66(
        "select",
        {
          "aria-label": "Spinner motion",
          value: mode,
          onChange: (e) => setMode(e.target.value),
          className: "rounded border bg-background px-2",
          children: ["inherit", "full", "reduced", "none"].map((value) => /* @__PURE__ */ jsx66("option", { children: value }, value))
        }
      )
    ] }),
    /* @__PURE__ */ jsxs36(CadenceProvider, { mode: mode === "inherit" ? void 0 : mode, children: [
      /* @__PURE__ */ jsxs36(PreviewRow, { children: [
        /* @__PURE__ */ jsx66(Spinner, { className: "size-3" }),
        /* @__PURE__ */ jsx66(Spinner, {}),
        /* @__PURE__ */ jsx66(Spinner, { className: "size-6" }),
        /* @__PURE__ */ jsx66(Spinner, { className: "size-8" })
      ] }),
      /* @__PURE__ */ jsxs36(PreviewRow, { className: "gap-6", children: [
        /* @__PURE__ */ jsxs36("span", { className: "inline-flex items-center gap-2 text-sm text-muted-foreground", children: [
          /* @__PURE__ */ jsx66(Spinner, {}),
          "Loading the registry\u2026"
        ] }),
        /* @__PURE__ */ jsxs36(Button, { disabled: true, size: "sm", children: [
          /* @__PURE__ */ jsx66(Spinner, {}),
          "Saving"
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsx66(CadenceProvider, { mode: "none", children: /* @__PURE__ */ jsxs36("span", { className: "inline-flex items-center gap-2 text-sm text-muted-foreground", children: [
      /* @__PURE__ */ jsx66(Spinner, { "aria-label": "Static loading", "data-testid": "static-spinner" }),
      "Motion disabled from the first render"
    ] }) })
  ] });
}

// components/site/previews/control-motion-scope.tsx
import { useState as useState18 } from "react";
import { jsx as jsx67, jsxs as jsxs37 } from "react/jsx-runtime";
function ControlMotionScope({ children, staticControl }) {
  const [mode, setMode] = useState18("inherit");
  return /* @__PURE__ */ jsxs37(PreviewStack, { children: [
    /* @__PURE__ */ jsxs37("label", { className: "flex items-center gap-2 text-sm", children: [
      "Control motion",
      /* @__PURE__ */ jsx67(
        "select",
        {
          "aria-label": "Control motion",
          value: mode,
          onChange: (e) => setMode(e.target.value),
          className: "rounded border bg-background px-2",
          children: ["inherit", "full", "reduced", "none"].map((value) => /* @__PURE__ */ jsx67("option", { children: value }, value))
        }
      )
    ] }),
    /* @__PURE__ */ jsx67(CadenceProvider, { mode: mode === "inherit" ? void 0 : mode, children }),
    /* @__PURE__ */ jsx67(CadenceProvider, { mode: "none", children: /* @__PURE__ */ jsxs37("div", { "data-testid": "initial-none", className: "flex w-full max-w-sm items-center gap-3 text-sm", children: [
      staticControl,
      /* @__PURE__ */ jsx67("span", { children: "Motion disabled from the first render" })
    ] }) })
  ] });
}

// components/site/previews/checkbox.tsx
import { jsx as jsx68, jsxs as jsxs38 } from "react/jsx-runtime";
function CheckboxPreview() {
  return /* @__PURE__ */ jsx68(ControlMotionScope, { staticControl: /* @__PURE__ */ jsx68(Checkbox, { "aria-label": "Static checkbox", defaultChecked: true }), children: /* @__PURE__ */ jsxs38("div", { className: "grid w-full max-w-md grid-cols-2 gap-x-8 gap-y-4", children: [
    /* @__PURE__ */ jsxs38("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsx68(Checkbox, { id: "checkbox-unchecked" }),
      /* @__PURE__ */ jsx68(Label, { htmlFor: "checkbox-unchecked", children: "Unchecked" })
    ] }),
    /* @__PURE__ */ jsxs38("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsx68(Checkbox, { id: "checkbox-checked", defaultChecked: true }),
      /* @__PURE__ */ jsx68(Label, { htmlFor: "checkbox-checked", children: "Checked" })
    ] }),
    /* @__PURE__ */ jsxs38("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsx68(Checkbox, { id: "checkbox-indeterminate", indeterminate: true }),
      /* @__PURE__ */ jsx68(Label, { htmlFor: "checkbox-indeterminate", children: "Indeterminate" })
    ] }),
    /* @__PURE__ */ jsxs38("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsx68(Checkbox, { id: "checkbox-disabled", disabled: true, defaultChecked: true }),
      /* @__PURE__ */ jsx68(Label, { htmlFor: "checkbox-disabled", children: "Disabled" })
    ] }),
    /* @__PURE__ */ jsxs38("div", { className: "flex items-center gap-2", children: [
      /* @__PURE__ */ jsx68(Checkbox, { id: "checkbox-invalid", "aria-invalid": "true" }),
      /* @__PURE__ */ jsx68(Label, { htmlFor: "checkbox-invalid", children: "Invalid" })
    ] })
  ] }) });
}

// registry/cadence/radio-group/index.tsx
import { Radio as RadioPrimitive } from "@base-ui/react/radio";
import { RadioGroup as RadioGroupPrimitive } from "@base-ui/react/radio-group";
import { jsx as jsx69 } from "react/jsx-runtime";
function RadioGroup({ className, ...props }) {
  return /* @__PURE__ */ jsx69(
    RadioGroupPrimitive,
    {
      "data-slot": "radio-group",
      className: (state) => cn("grid gap-3", typeof className === "function" ? className(state) : className),
      ...props
    }
  );
}
function RadioGroupItem({ className, ...props }) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx69(
    RadioPrimitive.Root,
    {
      "data-slot": "radio-group-item",
      "data-motion": cm.mode,
      className: (state) => cn(
        "group/radio-group-item peer relative aspect-square size-4 shrink-0 rounded-full border border-input text-primary shadow-xs outline-none transition-[color,box-shadow]",
        "focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50",
        "data-disabled:cursor-not-allowed data-disabled:opacity-50",
        "aria-invalid:border-destructive aria-invalid:ring-destructive/20 dark:aria-invalid:ring-destructive/40",
        "dark:bg-input/30",
        typeof className === "function" ? className(state) : className
      ),
      ...props,
      children: /* @__PURE__ */ jsx69(
        RadioPrimitive.Indicator,
        {
          "data-slot": "radio-group-indicator",
          "data-motion": cm.mode,
          keepMounted: true,
          render: (indicatorProps, state) => {
            const { className: indicatorClassName, ...rest } = indicatorProps;
            return /* @__PURE__ */ jsx69(
              ControlSpan,
              {
                ...rest,
                className: cn("flex size-full items-center justify-center", indicatorClassName),
                target: state.checked ? { opacity: 1, scale: 1 } : { opacity: 0, scale: cm.reduced ? 1 : scale.in },
                transition: { ...cm.transition("state.morph"), ...cm.reduced ? { scale: { duration: 0 } } : {} },
                children: /* @__PURE__ */ jsx69("span", { className: "size-2 rounded-full bg-primary" })
              }
            );
          }
        }
      )
    }
  );
}

// components/site/previews/radio-group.tsx
import { jsx as jsx70, jsxs as jsxs39 } from "react/jsx-runtime";
function RadioGroupPreview() {
  return /* @__PURE__ */ jsx70(
    ControlMotionScope,
    {
      staticControl: /* @__PURE__ */ jsx70(RadioGroup, { value: "static", "aria-label": "Static choice", children: /* @__PURE__ */ jsx70(RadioGroupItem, { value: "static", "aria-label": "Static radio" }) }),
      children: /* @__PURE__ */ jsxs39(RadioGroup, { defaultValue: "team", "aria-label": "Plan", className: "w-full max-w-xs gap-3", children: [
        /* @__PURE__ */ jsxs39("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx70(RadioGroupItem, { id: "plan-starter", value: "starter" }),
          /* @__PURE__ */ jsx70(Label, { htmlFor: "plan-starter", children: "Starter" })
        ] }),
        /* @__PURE__ */ jsxs39("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx70(RadioGroupItem, { id: "plan-team", value: "team" }),
          /* @__PURE__ */ jsx70(Label, { htmlFor: "plan-team", children: "Team" })
        ] }),
        /* @__PURE__ */ jsxs39("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx70(RadioGroupItem, { id: "plan-scale", value: "scale" }),
          /* @__PURE__ */ jsx70(Label, { htmlFor: "plan-scale", children: "Scale" })
        ] }),
        /* @__PURE__ */ jsxs39("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx70(RadioGroupItem, { id: "plan-enterprise", value: "enterprise", disabled: true }),
          /* @__PURE__ */ jsx70(Label, { htmlFor: "plan-enterprise", children: "Enterprise" })
        ] })
      ] })
    }
  );
}

// registry/cadence/switch/index.tsx
import { Switch as SwitchPrimitive } from "@base-ui/react/switch";
import { useEffect as useEffect14, useLayoutEffect as useLayoutEffect9, useRef as useRef11, useState as useState19 } from "react";
import { jsx as jsx71 } from "react/jsx-runtime";
var useIsomorphicLayoutEffect5 = typeof window === "undefined" ? useEffect14 : useLayoutEffect9;
function Switch({ className, size = "default", ...props }) {
  const cm = useCadenceMotion();
  const thumbRef = useRef11(null);
  const [travel, setTravel] = useState19(null);
  const [settled, setSettled] = useState19(false);
  useIsomorphicLayoutEffect5(() => {
    const thumb = thumbRef.current;
    const track = thumb?.parentElement;
    if (!thumb || !track) return;
    const measure = () => setTravel(Math.max(0, track.clientWidth - thumb.offsetWidth));
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(track);
    observer.observe(thumb);
    return () => observer.disconnect();
  }, []);
  useEffect14(() => {
    if (travel !== null && !settled) setSettled(true);
  }, [travel, settled]);
  return /* @__PURE__ */ jsx71(
    SwitchPrimitive.Root,
    {
      "data-slot": "switch",
      "data-size": size,
      "data-motion": cm.mode,
      className: (state) => cn(
        "peer group/switch relative inline-flex shrink-0 items-center rounded-full border border-transparent shadow-xs outline-none transition-[color,box-shadow] after:absolute after:-inset-x-3 after:-inset-y-2",
        "focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50",
        "data-disabled:cursor-not-allowed data-disabled:opacity-50",
        "data-[size=default]:h-[1.15rem] data-[size=default]:w-8 data-[size=sm]:h-3.5 data-[size=sm]:w-6",
        "data-checked:bg-primary data-unchecked:bg-input dark:data-unchecked:bg-input/80",
        typeof className === "function" ? className(state) : className
      ),
      ...props,
      children: /* @__PURE__ */ jsx71(
        SwitchPrimitive.Thumb,
        {
          "data-slot": "switch-thumb",
          "data-motion": cm.mode,
          render: (thumbProps, state) => {
            const { className: thumbClassName, ref: forwardedRef, ...rest } = thumbProps;
            return /* @__PURE__ */ jsx71(
              ControlSpan,
              {
                ...rest,
                ref: (node) => {
                  thumbRef.current = node;
                  if (typeof forwardedRef === "function") return forwardedRef(node);
                  else if (forwardedRef) forwardedRef.current = node;
                },
                className: cn(
                  "pointer-events-none block rounded-full bg-background ring-0",
                  "group-data-[size=default]/switch:size-4 group-data-[size=sm]/switch:size-3",
                  "dark:data-checked:bg-primary-foreground dark:data-unchecked:bg-foreground",
                  thumbClassName
                ),
                target: { x: state.checked ? travel ?? 0 : 0 },
                transition: !settled || cm.reduced ? { duration: 0 } : cm.transition("state.morph")
              }
            );
          }
        }
      )
    }
  );
}

// components/site/previews/switch.tsx
import { Fragment as Fragment15, jsx as jsx72, jsxs as jsxs40 } from "react/jsx-runtime";
var previewVariantOptions11 = ["default", "sm"];
function SwitchPreview() {
  const { control, choose } = usePreviewVariant("Switch", previewVariantOptions11);
  return /* @__PURE__ */ jsxs40(Fragment15, { children: [
    control,
    /* @__PURE__ */ jsxs40(ControlMotionScope, { staticControl: /* @__PURE__ */ jsx72(Switch, { "aria-label": "Static switch", defaultChecked: true, size: choose("default") }), children: [
      /* @__PURE__ */ jsxs40(PreviewRow, { className: "gap-6", children: [
        /* @__PURE__ */ jsxs40("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx72(Switch, { id: "switch-off", size: choose("default") }),
          /* @__PURE__ */ jsx72(Label, { htmlFor: "switch-off", children: "Off" })
        ] }),
        /* @__PURE__ */ jsxs40("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx72(Switch, { id: "switch-on", defaultChecked: true, size: choose("default") }),
          /* @__PURE__ */ jsx72(Label, { htmlFor: "switch-on", children: "On" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs40(PreviewRow, { className: "gap-6", children: [
        /* @__PURE__ */ jsxs40("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx72(Switch, { id: "switch-small", size: choose("sm") }),
          /* @__PURE__ */ jsx72(Label, { htmlFor: "switch-small", children: "Small" })
        ] }),
        /* @__PURE__ */ jsxs40("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx72(Switch, { id: "switch-small-on", size: choose("sm"), defaultChecked: true }),
          /* @__PURE__ */ jsx72(Label, { htmlFor: "switch-small-on", children: "Small, on" })
        ] }),
        /* @__PURE__ */ jsxs40("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx72(Switch, { id: "switch-disabled", disabled: true, size: choose("default") }),
          /* @__PURE__ */ jsx72(Label, { htmlFor: "switch-disabled", children: "Disabled" })
        ] })
      ] })
    ] })
  ] });
}

// components/site/previews/slider.tsx
import { useState as useState20 } from "react";

// registry/cadence/slider/index.tsx
import { Slider as SliderPrimitive } from "@base-ui/react/slider";
import { jsx as jsx73, jsxs as jsxs41 } from "react/jsx-runtime";
function Slider({
  className,
  defaultValue,
  value,
  min = 0,
  max = 100,
  orientation = "horizontal",
  "aria-label": ariaLabel,
  "aria-labelledby": ariaLabelledBy,
  ...props
}) {
  const cm = useCadenceMotion();
  const resolvedValue = value ?? defaultValue;
  const _values = Array.isArray(resolvedValue) ? resolvedValue : typeof resolvedValue === "number" ? [resolvedValue] : [min, max];
  const thumbCount = _values.length;
  const vertical = orientation === "vertical";
  const labelFor = (index) => {
    if (!ariaLabel || thumbCount === 1) return ariaLabel;
    if (thumbCount === 2) return `${ariaLabel} (${index === 0 ? "minimum" : "maximum"})`;
    return `${ariaLabel} (${index + 1} of ${thumbCount})`;
  };
  return /* @__PURE__ */ jsx73(
    SliderPrimitive.Root,
    {
      "data-slot": "slider",
      "data-motion": cm.mode,
      defaultValue,
      value,
      min,
      max,
      thumbAlignment: "edge",
      orientation,
      className: (state) => cn(vertical ? "h-full" : "w-full", typeof className === "function" ? className(state) : className),
      ...props,
      children: /* @__PURE__ */ jsxs41(
        SliderPrimitive.Control,
        {
          className: cn(
            "relative flex touch-none select-none data-disabled:opacity-50",
            vertical ? "h-full w-auto flex-col" : "w-full items-center"
          ),
          children: [
            /* @__PURE__ */ jsx73(
              SliderPrimitive.Track,
              {
                "data-slot": "slider-track",
                className: cn(
                  "relative grow overflow-hidden rounded-full bg-muted select-none",
                  vertical ? "h-full w-1.5" : "h-1.5 w-full"
                ),
                children: /* @__PURE__ */ jsx73(
                  SliderPrimitive.Indicator,
                  {
                    "data-slot": "slider-range",
                    className: cn("bg-primary select-none", vertical ? "w-full" : "h-full")
                  }
                )
              }
            ),
            Array.from({ length: _values.length }, (_, index) => /* @__PURE__ */ jsx73(
              SliderPrimitive.Thumb,
              {
                "data-slot": "slider-thumb",
                "data-motion": cm.mode,
                index,
                "aria-label": labelFor(index),
                "aria-labelledby": ariaLabelledBy,
                render: (thumbProps, state) => {
                  const { className: thumbClassName, ...rest } = thumbProps;
                  return /* @__PURE__ */ jsx73(
                    ControlDiv,
                    {
                      ...rest,
                      className: cn(
                        "block size-4 shrink-0 rounded-full border border-primary bg-white shadow-sm ring-ring/50 outline-none transition-[color,box-shadow] hover:ring-4 focus-visible:ring-4",
                        "data-disabled:pointer-events-none data-disabled:opacity-50",
                        thumbClassName
                      ),
                      target: { scale: state.dragging && !state.disabled && !cm.reduced ? scale.press : 1 },
                      transition: state.disabled || cm.reduced ? { duration: 0 } : cm.transition("feedback.press")
                    }
                  );
                }
              },
              index
            ))
          ]
        }
      )
    }
  );
}

// components/site/previews/slider.tsx
import { Fragment as Fragment16, jsx as jsx74, jsxs as jsxs42 } from "react/jsx-runtime";
var previewVariantOptions12 = ["horizontal", "vertical"];
function SliderPreview() {
  const { control, choose } = usePreviewVariant("Slider", previewVariantOptions12);
  const [volume, setVolume] = useState20([68]);
  const [price, setPrice] = useState20([120, 480]);
  return /* @__PURE__ */ jsxs42(Fragment16, { children: [
    control,
    /* @__PURE__ */ jsx74(
      ControlMotionScope,
      {
        staticControl: /* @__PURE__ */ jsx74(
          Slider,
          {
            style: { height: choose("horizontal") === "vertical" ? 128 : void 0 },
            "aria-label": "Static slider",
            value: 50,
            className: "max-w-20",
            orientation: choose("horizontal")
          }
        ),
        children: /* @__PURE__ */ jsxs42("div", { className: "flex w-full flex-col items-start gap-6 sm:flex-row sm:gap-10", children: [
          /* @__PURE__ */ jsxs42("div", { className: "grid w-full max-w-72 gap-6", children: [
            /* @__PURE__ */ jsxs42("div", { className: "grid gap-2", children: [
              /* @__PURE__ */ jsxs42("div", { className: "flex items-center justify-between text-sm", children: [
                /* @__PURE__ */ jsx74("span", { children: "Volume" }),
                /* @__PURE__ */ jsxs42("span", { className: "text-muted-foreground tabular-nums", children: [
                  volume[0],
                  "%"
                ] })
              ] }),
              /* @__PURE__ */ jsx74(
                Slider,
                {
                  style: { height: choose("horizontal") === "vertical" ? 128 : void 0 },
                  "aria-label": "Volume",
                  value: volume,
                  onValueChange: (next) => setVolume([next[0] ?? 0]),
                  max: 100,
                  orientation: choose("horizontal")
                }
              )
            ] }),
            /* @__PURE__ */ jsxs42("div", { className: "grid gap-2", children: [
              /* @__PURE__ */ jsxs42("div", { className: "flex items-center justify-between text-sm", children: [
                /* @__PURE__ */ jsx74("span", { children: "Price range" }),
                /* @__PURE__ */ jsxs42("span", { className: "text-muted-foreground tabular-nums", children: [
                  "$",
                  price[0],
                  " \u2013 $",
                  price[1]
                ] })
              ] }),
              /* @__PURE__ */ jsx74(
                Slider,
                {
                  style: { height: choose("horizontal") === "vertical" ? 128 : void 0 },
                  "aria-label": "Price range",
                  value: price,
                  onValueChange: (next) => setPrice([next[0] ?? 0, next[1] ?? 0]),
                  min: 0,
                  max: 600,
                  step: 10,
                  orientation: choose("horizontal")
                }
              )
            ] }),
            /* @__PURE__ */ jsxs42("div", { className: "grid gap-2", children: [
              /* @__PURE__ */ jsxs42("div", { className: "flex items-center justify-between text-sm text-muted-foreground", children: [
                /* @__PURE__ */ jsx74("span", { children: "Disabled" }),
                /* @__PURE__ */ jsx74("span", { className: "tabular-nums", children: "40%" })
              ] }),
              /* @__PURE__ */ jsx74(
                Slider,
                {
                  style: { height: choose("horizontal") === "vertical" ? 128 : void 0 },
                  "aria-label": "Disabled",
                  defaultValue: [40],
                  disabled: true,
                  orientation: choose("horizontal")
                }
              )
            ] })
          ] }),
          /* @__PURE__ */ jsxs42("div", { className: "grid justify-items-center gap-2", children: [
            /* @__PURE__ */ jsx74(
              Slider,
              {
                style: { height: choose("horizontal") === "vertical" ? 128 : void 0 },
                "aria-label": "Vertical",
                orientation: choose("vertical"),
                defaultValue: [64],
                className: "h-32"
              }
            ),
            /* @__PURE__ */ jsx74("span", { className: "text-xs text-muted-foreground", children: "Vertical" })
          ] })
        ] })
      }
    )
  ] });
}

// components/site/previews/toggle.tsx
import { BoldIcon as BoldIcon2, ItalicIcon as ItalicIcon2 } from "lucide-react";

// registry/cadence/toggle/index.tsx
import { Toggle as TogglePrimitive } from "@base-ui/react/toggle";
import { cva as cva10 } from "class-variance-authority";
import { jsx as jsx75 } from "react/jsx-runtime";
var toggleVariants = cva10(
  "inline-flex items-center justify-center gap-2 rounded-md text-sm font-medium whitespace-nowrap outline-none transition-[color,background-color,box-shadow] hover:bg-muted hover:text-muted-foreground focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 data-disabled:pointer-events-none data-disabled:opacity-50 aria-invalid:border-destructive aria-invalid:ring-destructive/20 data-pressed:bg-accent data-pressed:text-accent-foreground dark:aria-invalid:ring-destructive/40 [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
  {
    variants: {
      variant: {
        default: "bg-transparent",
        outline: "border border-input bg-transparent shadow-xs hover:bg-accent hover:text-accent-foreground"
      },
      size: {
        default: "h-9 min-w-9 px-2",
        sm: "h-8 min-w-8 px-1.5",
        lg: "h-10 min-w-10 px-2.5"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
function Toggle({ className, variant = "default", size = "default", ...props }) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx75(
    TogglePrimitive,
    {
      "data-slot": "toggle",
      "data-motion": cm.mode,
      className: (state) => cn(toggleVariants({ variant, size }), typeof className === "function" ? className(state) : className),
      render: /* @__PURE__ */ jsx75(
        PressButton,
        {
          whileTap: cm.reduced ? void 0 : { scale: scale.press },
          transition: cm.transition("feedback.press")
        }
      ),
      ...props
    }
  );
}

// components/site/previews/toggle.tsx
import { Fragment as Fragment17, jsx as jsx76, jsxs as jsxs43 } from "react/jsx-runtime";
var previewVariantOptions13 = ["default", "outline"];
function TogglePreview() {
  const { control, choose } = usePreviewVariant("Toggle", previewVariantOptions13);
  return /* @__PURE__ */ jsxs43(Fragment17, { children: [
    control,
    /* @__PURE__ */ jsxs43(
      ControlMotionScope,
      {
        staticControl: /* @__PURE__ */ jsx76(Toggle, { "aria-label": "Static toggle", defaultPressed: true, variant: choose("default"), children: "On" }),
        children: [
          /* @__PURE__ */ jsxs43(PreviewRow, { children: [
            /* @__PURE__ */ jsx76(Toggle, { "aria-label": "Bold", variant: choose("default"), children: /* @__PURE__ */ jsx76(BoldIcon2, {}) }),
            /* @__PURE__ */ jsx76(Toggle, { "aria-label": "Bold (pressed)", defaultPressed: true, variant: choose("default"), children: /* @__PURE__ */ jsx76(BoldIcon2, {}) }),
            /* @__PURE__ */ jsx76(Toggle, { variant: choose("outline"), "aria-label": "Italic", children: /* @__PURE__ */ jsx76(ItalicIcon2, {}) }),
            /* @__PURE__ */ jsx76(Toggle, { variant: choose("outline"), "aria-label": "Italic (pressed)", defaultPressed: true, children: /* @__PURE__ */ jsx76(ItalicIcon2, {}) })
          ] }),
          /* @__PURE__ */ jsxs43(PreviewRow, { children: [
            /* @__PURE__ */ jsx76(Toggle, { size: "sm", variant: choose("outline"), children: "Small" }),
            /* @__PURE__ */ jsx76(Toggle, { variant: choose("outline"), children: "Default" }),
            /* @__PURE__ */ jsx76(Toggle, { size: "lg", variant: choose("outline"), children: "Large" }),
            /* @__PURE__ */ jsx76(Toggle, { variant: choose("outline"), disabled: true, children: "Disabled" })
          ] })
        ]
      }
    )
  ] });
}

// components/site/previews/toggle-group.tsx
import { AlignCenterIcon, AlignLeftIcon, AlignRightIcon, BoldIcon as BoldIcon3, ItalicIcon as ItalicIcon3, UnderlineIcon as UnderlineIcon2 } from "lucide-react";

// registry/cadence/toggle-group/index.tsx
import { Toggle as TogglePrimitive2 } from "@base-ui/react/toggle";
import { ToggleGroup as ToggleGroupPrimitive } from "@base-ui/react/toggle-group";
import { createContext as createContext6, useContext as useContext6 } from "react";
import { jsx as jsx77 } from "react/jsx-runtime";
var ToggleGroupContext = createContext6({
  size: "default",
  variant: "default",
  spacing: 0,
  orientation: "horizontal"
});
function ToggleGroup({
  className,
  variant,
  size,
  style,
  spacing = 0,
  orientation = "horizontal",
  children,
  ...props
}) {
  return /* @__PURE__ */ jsx77(
    ToggleGroupPrimitive,
    {
      "data-slot": "toggle-group",
      "data-variant": variant,
      "data-size": size,
      "data-spacing": spacing,
      orientation,
      "data-orientation": orientation,
      style: (state) => ({ "--gap": spacing, ...typeof style === "function" ? style(state) : style }),
      className: (state) => cn(
        // Orientation is a JS branch, not a `data-vertical:` variant: Base UI writes
        // `data-orientation="vertical"`, while the shorthand utility compiles to
        // `[data-vertical]`, which nothing ever sets — a vertical group would lay out
        // as a row.
        "group/toggle-group flex w-fit gap-[calc(var(--spacing)*var(--gap))] rounded-md",
        orientation === "vertical" ? "flex-col items-stretch" : "items-center",
        "data-[spacing=0]:data-[variant=outline]:shadow-xs",
        typeof className === "function" ? className(state) : className
      ),
      ...props,
      children: /* @__PURE__ */ jsx77(ToggleGroupContext.Provider, { value: { variant, size, spacing, orientation }, children })
    }
  );
}
function ToggleGroupItem({ className, children, variant, size, ...props }) {
  const cm = useCadenceMotion();
  const context = useContext6(ToggleGroupContext);
  const resolvedVariant = context.variant ?? variant;
  const resolvedSize = context.size ?? size;
  const vertical = context.orientation === "vertical";
  const joined = context.spacing === 0;
  return /* @__PURE__ */ jsx77(
    TogglePrimitive2,
    {
      "data-slot": "toggle-group-item",
      "data-variant": resolvedVariant,
      "data-size": resolvedSize,
      "data-spacing": context.spacing,
      "data-motion": cm.mode,
      className: (state) => cn(
        toggleVariants({ variant: resolvedVariant, size: resolvedSize }),
        "w-auto min-w-0 shrink-0 px-3 focus:z-10 focus-visible:z-10",
        joined && "rounded-none shadow-none",
        joined && (vertical ? "first:rounded-t-md last:rounded-b-md" : "first:rounded-l-md last:rounded-r-md"),
        joined && resolvedVariant === "outline" && (vertical ? "border-t-0 first:border-t" : "border-l-0 first:border-l"),
        typeof className === "function" ? className(state) : className
      ),
      render: /* @__PURE__ */ jsx77(
        PressButton,
        {
          whileTap: cm.reduced ? void 0 : { scale: scale.press },
          transition: cm.transition("feedback.press")
        }
      ),
      ...props,
      children
    }
  );
}

// components/site/previews/toggle-group.tsx
import { Fragment as Fragment18, jsx as jsx78, jsxs as jsxs44 } from "react/jsx-runtime";
var previewVariantOptions14 = ["default", "outline"];
function ToggleGroupPreview() {
  const { control, choose } = usePreviewVariant("ToggleGroup", previewVariantOptions14);
  return /* @__PURE__ */ jsxs44(Fragment18, { children: [
    control,
    /* @__PURE__ */ jsxs44(
      ControlMotionScope,
      {
        staticControl: /* @__PURE__ */ jsx78(ToggleGroup, { value: ["static"], "aria-label": "Static group", variant: choose("default"), children: /* @__PURE__ */ jsx78(ToggleGroupItem, { value: "static", children: "On" }) }),
        children: [
          /* @__PURE__ */ jsxs44(PreviewRow, { children: [
            /* @__PURE__ */ jsxs44(ToggleGroup, { variant: choose("outline"), defaultValue: ["left"], "aria-label": "Text alignment", children: [
              /* @__PURE__ */ jsx78(ToggleGroupItem, { value: "left", "aria-label": "Align left", children: /* @__PURE__ */ jsx78(AlignLeftIcon, {}) }),
              /* @__PURE__ */ jsx78(ToggleGroupItem, { value: "center", "aria-label": "Align center", children: /* @__PURE__ */ jsx78(AlignCenterIcon, {}) }),
              /* @__PURE__ */ jsx78(ToggleGroupItem, { value: "right", "aria-label": "Align right", children: /* @__PURE__ */ jsx78(AlignRightIcon, {}) })
            ] }),
            /* @__PURE__ */ jsxs44(ToggleGroup, { variant: choose("outline"), spacing: 1, defaultValue: ["day"], "aria-label": "Range", children: [
              /* @__PURE__ */ jsx78(ToggleGroupItem, { value: "day", children: "Day" }),
              /* @__PURE__ */ jsx78(ToggleGroupItem, { value: "week", children: "Week" }),
              /* @__PURE__ */ jsx78(ToggleGroupItem, { value: "month", children: "Month" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs44(PreviewRow, { children: [
            /* @__PURE__ */ jsxs44(ToggleGroup, { multiple: true, defaultValue: ["bold"], "aria-label": "Text style", variant: choose("default"), children: [
              /* @__PURE__ */ jsx78(ToggleGroupItem, { value: "bold", "aria-label": "Bold", children: /* @__PURE__ */ jsx78(BoldIcon3, {}) }),
              /* @__PURE__ */ jsx78(ToggleGroupItem, { value: "italic", "aria-label": "Italic", children: /* @__PURE__ */ jsx78(ItalicIcon3, {}) }),
              /* @__PURE__ */ jsx78(ToggleGroupItem, { value: "underline", "aria-label": "Underline", children: /* @__PURE__ */ jsx78(UnderlineIcon2, {}) })
            ] }),
            /* @__PURE__ */ jsxs44(ToggleGroup, { variant: choose("outline"), size: "sm", defaultValue: ["week"], "aria-label": "Range, small", children: [
              /* @__PURE__ */ jsx78(ToggleGroupItem, { value: "day", children: "Day" }),
              /* @__PURE__ */ jsx78(ToggleGroupItem, { value: "week", children: "Week" }),
              /* @__PURE__ */ jsx78(ToggleGroupItem, { value: "month", children: "Month" })
            ] })
          ] }),
          /* @__PURE__ */ jsxs44(PreviewRow, { className: "items-start gap-6", children: [
            /* @__PURE__ */ jsxs44(
              ToggleGroup,
              {
                orientation: "vertical",
                variant: choose("outline"),
                defaultValue: ["left"],
                "aria-label": "Vertical alignment",
                children: [
                  /* @__PURE__ */ jsx78(ToggleGroupItem, { value: "left", "aria-label": "Align left", children: /* @__PURE__ */ jsx78(AlignLeftIcon, {}) }),
                  /* @__PURE__ */ jsx78(ToggleGroupItem, { value: "center", "aria-label": "Align center", children: /* @__PURE__ */ jsx78(AlignCenterIcon, {}) }),
                  /* @__PURE__ */ jsx78(ToggleGroupItem, { value: "right", "aria-label": "Align right", children: /* @__PURE__ */ jsx78(AlignRightIcon, {}) })
                ]
              }
            ),
            /* @__PURE__ */ jsxs44(
              ToggleGroup,
              {
                orientation: "vertical",
                size: "sm",
                defaultValue: ["bold"],
                "aria-label": "Vertical text style",
                variant: choose("default"),
                children: [
                  /* @__PURE__ */ jsx78(ToggleGroupItem, { value: "bold", "aria-label": "Bold", children: /* @__PURE__ */ jsx78(BoldIcon3, {}) }),
                  /* @__PURE__ */ jsx78(ToggleGroupItem, { value: "italic", "aria-label": "Italic", children: /* @__PURE__ */ jsx78(ItalicIcon3, {}) }),
                  /* @__PURE__ */ jsx78(ToggleGroupItem, { value: "underline", "aria-label": "Underline", children: /* @__PURE__ */ jsx78(UnderlineIcon2, {}) })
                ]
              }
            )
          ] })
        ]
      }
    )
  ] });
}

// components/site/previews/input-otp.tsx
import { useState as useState21 } from "react";

// registry/cadence/input-otp/index.tsx
import { OTPInput, OTPInputContext } from "input-otp";
import { MinusIcon } from "lucide-react";
import { motion as motion7, useAnimationControls as useAnimationControls2 } from "motion/react";
import { useContext as useContext7, useEffect as useEffect15, useLayoutEffect as useLayoutEffect10, useRef as useRef12 } from "react";
import { jsx as jsx79, jsxs as jsxs45 } from "react/jsx-runtime";
var useCommittedEffect3 = typeof window === "undefined" ? useEffect15 : useLayoutEffect10;
function InputOTP({ className, containerClassName, ...props }) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx79(
    OTPInput,
    {
      spellCheck: false,
      "data-slot": "input-otp",
      "data-motion": cm.mode,
      containerClassName: cn("flex items-center gap-2 has-disabled:opacity-50", containerClassName),
      className: cn("disabled:cursor-not-allowed", className),
      ...props
    }
  );
}
function InputOTPGroup({ className, ...props }) {
  return /* @__PURE__ */ jsx79("div", { "data-slot": "input-otp-group", className: cn("flex items-center", className), ...props });
}
function InputOTPSlot({ index, className, ...props }) {
  const cm = useCadenceMotion();
  const inputOTPContext = useContext7(OTPInputContext);
  const { char, hasFakeCaret, isActive: isActive2 } = inputOTPContext?.slots[index] ?? {};
  const controls = useAnimationControls2();
  const previousCharacter = useRef12(char);
  useCommittedEffect3(() => {
    controls.stop();
    const changed = previousCharacter.current !== char;
    previousCharacter.current = char;
    if (changed && char && cm.mode !== "none") {
      controls.set(cm.reduced ? { opacity: 0, scale: 1 } : { opacity: 0, scale: scale.in });
      void controls.start({ opacity: 1, scale: 1 }, cm.transition("state.morph"));
    } else controls.set({ opacity: 1, scale: 1 });
    return () => controls.stop();
  }, [char, cm.mode, cm.timeScale, controls]);
  return /* @__PURE__ */ jsxs45(
    "div",
    {
      "data-slot": "input-otp-slot",
      "data-active": isActive2,
      className: cn(
        "relative flex h-9 w-9 items-center justify-center border-y border-r border-input text-sm shadow-xs outline-none transition-[color,box-shadow] first:rounded-l-md first:border-l last:rounded-r-md",
        "aria-invalid:border-destructive",
        "data-[active=true]:z-10 data-[active=true]:border-ring data-[active=true]:ring-[3px] data-[active=true]:ring-ring/50 data-[active=true]:aria-invalid:border-destructive data-[active=true]:aria-invalid:ring-destructive/20 dark:data-[active=true]:aria-invalid:ring-destructive/40",
        "dark:bg-input/30",
        className
      ),
      ...props,
      children: [
        /* @__PURE__ */ jsx79(motion7.span, { "data-motion": cm.mode, initial: false, animate: controls, transition: cm.transition("state.morph"), children: char }),
        hasFakeCaret && /* @__PURE__ */ jsx79("div", { className: "pointer-events-none absolute inset-0 flex items-center justify-center", children: /* @__PURE__ */ jsx79("div", { className: "h-4 w-px bg-foreground" }) })
      ]
    }
  );
}
function InputOTPSeparator(props) {
  return (
    // biome-ignore lint/a11y/useSemanticElements: `<hr>` is void and cannot hold the dash glyph upstream renders here; the separator is decorative between slot groups and carries no action.
    /* @__PURE__ */ jsx79("div", { "data-slot": "input-otp-separator", role: "separator", ...props, children: /* @__PURE__ */ jsx79(MinusIcon, {}) })
  );
}

// components/site/previews/input-otp.tsx
import { jsx as jsx80, jsxs as jsxs46 } from "react/jsx-runtime";
function InputOtpPreview() {
  const [code, setCode] = useState21("");
  const [invalid, setInvalid] = useState21("0000");
  return /* @__PURE__ */ jsxs46(
    ControlMotionScope,
    {
      staticControl: /* @__PURE__ */ jsx80(InputOTP, { maxLength: 1, value: "1", "aria-label": "Static code", children: /* @__PURE__ */ jsx80(InputOTPGroup, { children: /* @__PURE__ */ jsx80(InputOTPSlot, { index: 0 }) }) }),
      children: [
        /* @__PURE__ */ jsxs46("div", { className: "grid gap-3", children: [
          /* @__PURE__ */ jsx80(Label, { htmlFor: "otp", children: "Verification code" }),
          /* @__PURE__ */ jsxs46(InputOTP, { id: "otp", maxLength: 6, value: code, onChange: setCode, containerClassName: "justify-center", children: [
            /* @__PURE__ */ jsxs46(InputOTPGroup, { children: [
              /* @__PURE__ */ jsx80(InputOTPSlot, { index: 0 }),
              /* @__PURE__ */ jsx80(InputOTPSlot, { index: 1 }),
              /* @__PURE__ */ jsx80(InputOTPSlot, { index: 2 })
            ] }),
            /* @__PURE__ */ jsx80(InputOTPSeparator, {}),
            /* @__PURE__ */ jsxs46(InputOTPGroup, { children: [
              /* @__PURE__ */ jsx80(InputOTPSlot, { index: 3 }),
              /* @__PURE__ */ jsx80(InputOTPSlot, { index: 4 }),
              /* @__PURE__ */ jsx80(InputOTPSlot, { index: 5 })
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxs46("div", { className: "grid gap-3", children: [
          /* @__PURE__ */ jsx80(Label, { htmlFor: "otp-invalid", children: "Invalid code" }),
          /* @__PURE__ */ jsx80(
            InputOTP,
            {
              id: "otp-invalid",
              maxLength: 4,
              "aria-invalid": "true",
              value: invalid,
              onChange: setInvalid,
              containerClassName: "justify-center",
              children: /* @__PURE__ */ jsxs46(InputOTPGroup, { children: [
                /* @__PURE__ */ jsx80(InputOTPSlot, { index: 0, "aria-invalid": true }),
                /* @__PURE__ */ jsx80(InputOTPSlot, { index: 1, "aria-invalid": true }),
                /* @__PURE__ */ jsx80(InputOTPSlot, { index: 2, "aria-invalid": true }),
                /* @__PURE__ */ jsx80(InputOTPSlot, { index: 3, "aria-invalid": true })
              ] })
            }
          )
        ] })
      ]
    }
  );
}

// components/site/previews/progress.tsx
import { useState as useState22 } from "react";

// registry/cadence/progress/index.tsx
import { Progress as ProgressPrimitive } from "@base-ui/react/progress";
import { createContext as createContext7, useContext as useContext8 } from "react";
import { jsx as jsx81, jsxs as jsxs47 } from "react/jsx-runtime";
var ProgressContext = createContext7(null);
function Progress({ className, children, value, min = 0, max = 100, ...props }) {
  const cm = useCadenceMotion();
  const fraction = value === null || value === void 0 ? null : Math.min(1, Math.max(0, (value - min) / (max - min || 1)));
  return /* @__PURE__ */ jsx81(ProgressContext.Provider, { value: fraction, children: /* @__PURE__ */ jsxs47(
    ProgressPrimitive.Root,
    {
      "data-slot": "progress",
      "data-motion": cm.mode,
      value,
      min,
      max,
      className: (state) => cn("flex w-full flex-wrap gap-3", typeof className === "function" ? className(state) : className),
      ...props,
      children: [
        children,
        /* @__PURE__ */ jsx81(ProgressTrack, { children: /* @__PURE__ */ jsx81(ProgressIndicator, {}) })
      ]
    }
  ) });
}
function ProgressTrack({ className, ...props }) {
  return /* @__PURE__ */ jsx81(
    ProgressPrimitive.Track,
    {
      "data-slot": "progress-track",
      className: (state) => cn(
        "relative flex h-2 w-full items-center overflow-x-hidden rounded-full bg-primary/20",
        typeof className === "function" ? className(state) : className
      ),
      ...props
    }
  );
}
function ProgressIndicator({ className, style, ...props }) {
  const cm = useCadenceMotion();
  const fraction = useContext8(ProgressContext);
  const indeterminate = fraction === null;
  const pulse = indeterminate ? cm.mode === "none" ? "animate-none" : "animate-pulse" : void 0;
  return /* @__PURE__ */ jsx81(
    ProgressPrimitive.Indicator,
    {
      "data-slot": "progress-indicator",
      "data-motion": cm.mode,
      style: (state) => ({ width: "100%", ...typeof style === "function" ? style(state) : style }),
      className,
      render: (indicatorProps) => {
        const { className: indicatorClassName, ...rest } = indicatorProps;
        return /* @__PURE__ */ jsx81(
          NativeControlDiv,
          {
            ...rest,
            className: cn("h-full w-full origin-left bg-primary", pulse, indicatorClassName),
            target: { scaleX: fraction ?? 1 },
            transition: cm.reduced ? { duration: 0 } : cm.transition("data.transition")
          }
        );
      },
      ...props
    }
  );
}
function ProgressLabel({ className, ...props }) {
  return /* @__PURE__ */ jsx81(
    ProgressPrimitive.Label,
    {
      "data-slot": "progress-label",
      className: (state) => cn("text-sm font-medium", typeof className === "function" ? className(state) : className),
      ...props
    }
  );
}
function ProgressValue({ className, ...props }) {
  return /* @__PURE__ */ jsx81(
    ProgressPrimitive.Value,
    {
      "data-slot": "progress-value",
      className: (state) => cn("text-sm text-muted-foreground tabular-nums", typeof className === "function" ? className(state) : className),
      ...props
    }
  );
}

// components/site/previews/progress.tsx
import { jsx as jsx82, jsxs as jsxs48 } from "react/jsx-runtime";
function ProgressPreview() {
  const [value, setValue] = useState22(62);
  return /* @__PURE__ */ jsx82(ControlMotionScope, { staticControl: /* @__PURE__ */ jsx82(Progress, { value: null, "aria-label": "Static progress", className: "max-w-20" }), children: /* @__PURE__ */ jsxs48("div", { className: "grid w-full max-w-sm gap-5", children: [
    /* @__PURE__ */ jsxs48("label", { className: "grid gap-2 text-sm", children: [
      "Upload progress",
      /* @__PURE__ */ jsx82(
        "input",
        {
          "aria-label": "Upload progress",
          type: "range",
          min: 0,
          max: 100,
          value,
          onChange: (e) => setValue(Number(e.target.value))
        }
      )
    ] }),
    /* @__PURE__ */ jsx82(Progress, { value, "aria-label": "Uploading assets", children: /* @__PURE__ */ jsxs48("div", { className: "flex w-full items-center justify-between", children: [
      /* @__PURE__ */ jsx82(ProgressLabel, { children: "Uploading assets" }),
      /* @__PURE__ */ jsx82(ProgressValue, {})
    ] }) }),
    /* @__PURE__ */ jsxs48("div", { className: "grid gap-1", children: [
      /* @__PURE__ */ jsx82("span", { className: "text-sm", children: "Preparing preview" }),
      /* @__PURE__ */ jsx82(Progress, { value: null, "aria-label": "Preparing preview" })
    ] }),
    /* @__PURE__ */ jsxs48("div", { className: "grid gap-1", children: [
      /* @__PURE__ */ jsx82("span", { className: "text-sm", children: "Complete" }),
      /* @__PURE__ */ jsx82(Progress, { value: 100, "aria-label": "Complete" })
    ] })
  ] }) });
}

// components/site/previews/alert-dialog.tsx
import { Trash2Icon } from "lucide-react";

// registry/cadence/alert-dialog/index.tsx
import { AlertDialog as AlertDialogPrimitive } from "@base-ui/react/alert-dialog";
import { jsx as jsx83, jsxs as jsxs49 } from "react/jsx-runtime";
function AlertDialog({ ...props }) {
  return /* @__PURE__ */ jsx83(AlertDialogPrimitive.Root, { "data-slot": "alert-dialog", ...props });
}
function AlertDialogTrigger({ ...props }) {
  return /* @__PURE__ */ jsx83(AlertDialogPrimitive.Trigger, { "data-slot": "alert-dialog-trigger", ...props });
}
function AlertDialogPortal({ ...props }) {
  return /* @__PURE__ */ jsx83(AlertDialogPrimitive.Portal, { "data-slot": "alert-dialog-portal", ...props });
}
function AlertDialogOverlay({ className, style, ...props }) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx83(
    AlertDialogPrimitive.Backdrop,
    {
      "data-slot": "alert-dialog-overlay",
      "data-motion": cm.mode,
      style: popupStyle(cm, style),
      className: popupClasses(
        cm,
        cn(
          "fixed inset-0 isolate z-50 bg-black/50 transition-opacity ease-cadence-out duration-(--motion-duration-fast) data-[ending-style]:opacity-0 data-[starting-style]:opacity-0"
        ),
        className
      ),
      ...props
    }
  );
}
function AlertDialogContent({
  className,
  style,
  children,
  size = "default",
  ...props
}) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsxs49(AlertDialogPortal, { children: [
    /* @__PURE__ */ jsx83(AlertDialogOverlay, {}),
    /* @__PURE__ */ jsx83(
      AlertDialogPrimitive.Popup,
      {
        "data-slot": "alert-dialog-content",
        "data-size": size,
        "data-motion": cm.mode,
        style: popupStyle(cm, style),
        className: popupClasses(
          cm,
          cn(
            "group/alert-dialog-content fixed top-1/2 left-1/2 z-50 grid w-full max-w-[calc(100%-2rem)] -translate-x-1/2 -translate-y-1/2 gap-4 rounded-lg border bg-background p-6 shadow-lg outline-none transition-[opacity,scale] ease-cadence-out duration-(--motion-duration-base) data-[ending-style]:opacity-0 data-[size=sm]:max-w-xs data-[starting-style]:opacity-0 data-[size=default]:sm:max-w-lg",
            !cm.reduced && "data-[ending-style]:scale-(--motion-scale-in) data-[starting-style]:scale-(--motion-scale-in)"
          ),
          className
        ),
        ...props,
        children
      }
    )
  ] });
}
function AlertDialogHeader({ className, ...props }) {
  return /* @__PURE__ */ jsx83(
    "div",
    {
      "data-slot": "alert-dialog-header",
      className: cn(
        "grid grid-rows-[auto_1fr] place-items-center gap-1.5 text-center has-data-[slot=alert-dialog-media]:grid-rows-[auto_auto_1fr] has-data-[slot=alert-dialog-media]:gap-x-6 sm:group-data-[size=default]/alert-dialog-content:place-items-start sm:group-data-[size=default]/alert-dialog-content:text-left sm:group-data-[size=default]/alert-dialog-content:has-data-[slot=alert-dialog-media]:grid-rows-[auto_1fr]",
        className
      ),
      ...props
    }
  );
}
function AlertDialogFooter({ className, ...props }) {
  return /* @__PURE__ */ jsx83(
    "div",
    {
      "data-slot": "alert-dialog-footer",
      className: cn(
        "flex flex-col-reverse gap-2 group-data-[size=sm]/alert-dialog-content:grid group-data-[size=sm]/alert-dialog-content:grid-cols-2 sm:flex-row sm:justify-end",
        className
      ),
      ...props
    }
  );
}
function AlertDialogMedia({ className, ...props }) {
  return /* @__PURE__ */ jsx83(
    "div",
    {
      "data-slot": "alert-dialog-media",
      className: cn(
        "mb-2 inline-flex size-16 items-center justify-center rounded-md bg-muted *:[svg:not([class*='size-'])]:size-8 sm:group-data-[size=default]/alert-dialog-content:row-span-2",
        className
      ),
      ...props
    }
  );
}
function AlertDialogTitle({ className, ...props }) {
  return /* @__PURE__ */ jsx83(
    AlertDialogPrimitive.Title,
    {
      "data-slot": "alert-dialog-title",
      className: stateClasses(
        cn(
          "text-lg font-semibold sm:group-data-[size=default]/alert-dialog-content:group-has-data-[slot=alert-dialog-media]/alert-dialog-content:col-start-2"
        ),
        className
      ),
      ...props
    }
  );
}
function AlertDialogDescription({ className, ...props }) {
  return /* @__PURE__ */ jsx83(
    AlertDialogPrimitive.Description,
    {
      "data-slot": "alert-dialog-description",
      className: stateClasses(cn("text-sm text-muted-foreground"), className),
      ...props
    }
  );
}
function AlertDialogAction({ className, variant, ...props }) {
  return /* @__PURE__ */ jsx83(
    Button,
    {
      "data-slot": "alert-dialog-action",
      variant,
      className: stateClasses(
        cn(
          variant === "destructive" && "bg-destructive/10 text-foreground hover:bg-destructive/20 dark:bg-destructive/20"
        ),
        className
      ),
      ...props
    }
  );
}
function AlertDialogCancel({
  className,
  variant = "outline",
  size = "default",
  ...props
}) {
  return /* @__PURE__ */ jsx83(
    AlertDialogPrimitive.Close,
    {
      "data-slot": "alert-dialog-cancel",
      className,
      render: /* @__PURE__ */ jsx83(Button, { variant, size }),
      ...props
    }
  );
}

// components/site/previews/alert-dialog.tsx
import { Fragment as Fragment19, jsx as jsx84, jsxs as jsxs50 } from "react/jsx-runtime";
var previewVariantOptions15 = ["default", "sm"];
function AlertDialogPreview() {
  const { control, choose } = usePreviewVariant("AlertDialog", previewVariantOptions15);
  return /* @__PURE__ */ jsxs50(Fragment19, { children: [
    control,
    /* @__PURE__ */ jsx84(PopupMotionScope, { children: /* @__PURE__ */ jsx84(PreviewStack, { children: /* @__PURE__ */ jsxs50(PreviewRow, { className: "gap-3", children: [
      /* @__PURE__ */ jsxs50(AlertDialog, { children: [
        /* @__PURE__ */ jsx84(AlertDialogTrigger, { render: /* @__PURE__ */ jsx84(Button, { variant: "outline" }), children: "Delete project" }),
        /* @__PURE__ */ jsxs50(AlertDialogContent, { size: choose("default"), children: [
          /* @__PURE__ */ jsxs50(AlertDialogHeader, { children: [
            /* @__PURE__ */ jsx84(AlertDialogMedia, { children: /* @__PURE__ */ jsx84(Trash2Icon, { "aria-hidden": "true" }) }),
            /* @__PURE__ */ jsx84(AlertDialogTitle, { children: "Delete this project?" }),
            /* @__PURE__ */ jsx84(AlertDialogDescription, { children: "Every deployment and its logs go with it. This cannot be undone." })
          ] }),
          /* @__PURE__ */ jsxs50(AlertDialogFooter, { children: [
            /* @__PURE__ */ jsx84(AlertDialogCancel, { children: "Keep project" }),
            /* @__PURE__ */ jsx84(AlertDialogAction, { variant: "destructive", children: "Delete project" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs50(AlertDialog, { children: [
        /* @__PURE__ */ jsx84(AlertDialogTrigger, { render: /* @__PURE__ */ jsx84(Button, { variant: "ghost" }), children: "Archive" }),
        /* @__PURE__ */ jsxs50(AlertDialogContent, { size: choose("sm"), children: [
          /* @__PURE__ */ jsxs50(AlertDialogHeader, { children: [
            /* @__PURE__ */ jsx84(AlertDialogTitle, { children: "Archive this project?" }),
            /* @__PURE__ */ jsx84(AlertDialogDescription, { children: "It stops deploying, and you can unarchive it later." })
          ] }),
          /* @__PURE__ */ jsxs50(AlertDialogFooter, { children: [
            /* @__PURE__ */ jsx84(AlertDialogCancel, { children: "Cancel" }),
            /* @__PURE__ */ jsx84(AlertDialogAction, { children: "Archive" })
          ] })
        ] })
      ] })
    ] }) }) })
  ] });
}

// registry/cadence/popover/index.tsx
import { Popover as PopoverPrimitive } from "@base-ui/react/popover";
import { jsx as jsx85 } from "react/jsx-runtime";
function Popover({ ...props }) {
  return /* @__PURE__ */ jsx85(PopoverPrimitive.Root, { "data-slot": "popover", ...props });
}
function PopoverTrigger({ ...props }) {
  return /* @__PURE__ */ jsx85(PopoverPrimitive.Trigger, { "data-slot": "popover-trigger", ...props });
}
function PopoverContent({
  className,
  style,
  align = "center",
  alignOffset = 0,
  side = "bottom",
  sideOffset = 4,
  ...props
}) {
  const cm = useCadenceMotion();
  const clock2 = {
    "--motion-duration-fast": `${duration.fast * (cm.disabled ? 0 : cm.reduced ? reducedDurationScale : 1) * cm.timeScale}s`
  };
  const classes2 = cn(
    "z-50 w-72 origin-(--transform-origin) rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none",
    cm.disabled ? "transition-none duration-0" : "ease-cadence-out duration-(--motion-duration-fast) data-[ending-style]:opacity-0 data-[starting-style]:opacity-0",
    !cm.disabled && (cm.reduced ? "transition-opacity" : "transition-[opacity,scale]"),
    !cm.reduced && "data-[ending-style]:scale-(--motion-scale-in) data-[starting-style]:scale-(--motion-scale-in)"
  );
  return /* @__PURE__ */ jsx85(PopoverPrimitive.Portal, { children: /* @__PURE__ */ jsx85(
    PopoverPrimitive.Positioner,
    {
      align,
      alignOffset,
      side,
      sideOffset,
      className: "isolate z-50",
      children: /* @__PURE__ */ jsx85(
        PopoverPrimitive.Popup,
        {
          "data-slot": "popover-content",
          "data-motion": cm.mode,
          className: typeof className === "function" ? (state) => cn(classes2, className(state)) : cn(classes2, className),
          style: typeof style === "function" ? (state) => ({ ...clock2, ...style(state) }) : { ...clock2, ...style },
          ...props
        }
      )
    }
  ) });
}
function PopoverHeader({ className, ...props }) {
  return /* @__PURE__ */ jsx85("div", { "data-slot": "popover-header", className: cn("flex flex-col gap-1 text-sm", className), ...props });
}
function PopoverTitle({ className, ...props }) {
  return /* @__PURE__ */ jsx85(
    PopoverPrimitive.Title,
    {
      "data-slot": "popover-title",
      className: typeof className === "function" ? (state) => cn("font-medium", className(state)) : cn("font-medium", className),
      ...props
    }
  );
}
function PopoverDescription({ className, ...props }) {
  return /* @__PURE__ */ jsx85(
    PopoverPrimitive.Description,
    {
      "data-slot": "popover-description",
      className: typeof className === "function" ? (state) => cn("text-muted-foreground", className(state)) : cn("text-muted-foreground", className),
      ...props
    }
  );
}

// components/site/previews/popover.tsx
import { Fragment as Fragment20, jsx as jsx86, jsxs as jsxs51 } from "react/jsx-runtime";
var previewVariantOptions16 = ["start", "center", "end"];
var COLUMNS = [
  { id: "column-name", label: "Name", checked: true },
  { id: "column-status", label: "Status", checked: true },
  { id: "column-owner", label: "Owner", checked: true },
  { id: "column-updated", label: "Updated", checked: false }
];
function PopoverPreview() {
  const { control, choose } = usePreviewVariant("Popover", previewVariantOptions16);
  return /* @__PURE__ */ jsxs51(Fragment20, { children: [
    control,
    /* @__PURE__ */ jsx86(PopupMotionScope, { children: /* @__PURE__ */ jsx86(PreviewStack, { children: /* @__PURE__ */ jsxs51(PreviewRow, { className: "gap-3", children: [
      /* @__PURE__ */ jsxs51(Popover, { children: [
        /* @__PURE__ */ jsx86(PopoverTrigger, { render: /* @__PURE__ */ jsx86(Button, { variant: "outline" }), children: "Visible columns" }),
        /* @__PURE__ */ jsxs51(PopoverContent, { align: choose("start"), children: [
          /* @__PURE__ */ jsxs51(PopoverHeader, { children: [
            /* @__PURE__ */ jsx86(PopoverTitle, { children: "Visible columns" }),
            /* @__PURE__ */ jsx86(PopoverDescription, { children: "Three of four columns are shown." })
          ] }),
          /* @__PURE__ */ jsx86("div", { className: "flex flex-col gap-2", children: COLUMNS.map((column) => /* @__PURE__ */ jsxs51("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx86(Checkbox, { id: column.id, defaultChecked: column.checked }),
            /* @__PURE__ */ jsx86(Label, { htmlFor: column.id, className: "font-normal", children: column.label })
          ] }, column.id)) })
        ] })
      ] }),
      /* @__PURE__ */ jsxs51(Popover, { children: [
        /* @__PURE__ */ jsx86(PopoverTrigger, { render: /* @__PURE__ */ jsx86(Button, { variant: "ghost" }), children: "Plain content" }),
        /* @__PURE__ */ jsx86(PopoverContent, { align: choose("end"), className: "w-64 text-sm", children: "A popover is not a dialog: it does not trap focus and clicking outside closes it." })
      ] })
    ] }) }) })
  ] });
}

// components/site/previews/tooltip.tsx
import { BoldIcon as BoldIcon4, ItalicIcon as ItalicIcon4, Link2Icon, UnderlineIcon as UnderlineIcon3 } from "lucide-react";

// registry/cadence/tooltip/index.tsx
import { Tooltip as TooltipPrimitive } from "@base-ui/react/tooltip";
import { createContext as createContext8, useContext as useContext9, useId as useId3, useState as useState23 } from "react";
import { jsx as jsx87, jsxs as jsxs52 } from "react/jsx-runtime";
var TooltipContext = createContext8(null);
function TooltipProvider({ delay = 0, ...props }) {
  return /* @__PURE__ */ jsx87(TooltipPrimitive.Provider, { "data-slot": "tooltip-provider", delay, ...props });
}
function Tooltip({ children, open, defaultOpen = false, onOpenChange, ...props }) {
  const id = useId3();
  const [uncontrolledOpen, setUncontrolledOpen] = useState23(defaultOpen);
  const isOpen = open ?? uncontrolledOpen;
  return /* @__PURE__ */ jsx87(TooltipContext.Provider, { value: { id, open: isOpen }, children: /* @__PURE__ */ jsx87(
    TooltipPrimitive.Root,
    {
      "data-slot": "tooltip",
      open,
      defaultOpen,
      onOpenChange: (next, details) => {
        onOpenChange?.(next, details);
        if (!details.isCanceled) setUncontrolledOpen(next);
      },
      ...props,
      children
    }
  ) });
}
function TooltipTrigger({ ...props }) {
  const tooltip = useContext9(TooltipContext);
  return /* @__PURE__ */ jsx87(
    TooltipPrimitive.Trigger,
    {
      "data-slot": "tooltip-trigger",
      "aria-describedby": tooltip?.open ? tooltip.id : void 0,
      ...props
    }
  );
}
function TooltipContent({
  className,
  style,
  side = "top",
  sideOffset = 4,
  align = "center",
  alignOffset = 0,
  children,
  ...props
}) {
  const cm = useCadenceMotion();
  const tooltip = useContext9(TooltipContext);
  return /* @__PURE__ */ jsx87(TooltipPrimitive.Portal, { children: /* @__PURE__ */ jsx87(
    TooltipPrimitive.Positioner,
    {
      align,
      alignOffset,
      side,
      sideOffset,
      className: "isolate z-50",
      children: /* @__PURE__ */ jsxs52(
        TooltipPrimitive.Popup,
        {
          id: tooltip?.id,
          "data-slot": "tooltip-content",
          "data-motion": cm.mode,
          style: popupStyle(cm, style),
          role: "tooltip",
          className: popupClasses(
            cm,
            cn(
              "z-50 w-fit max-w-xs origin-(--transform-origin) rounded-md bg-foreground px-3 py-1.5 text-xs text-balance text-background outline-none transition-[opacity,scale] ease-cadence-out duration-(--motion-duration-fast) data-[ending-style]:opacity-0 data-[starting-style]:opacity-0",
              !cm.reduced && "data-[ending-style]:scale-(--motion-scale-in) data-[starting-style]:scale-(--motion-scale-in)"
            ),
            className
          ),
          ...props,
          children: [
            children,
            /* @__PURE__ */ jsx87(
              TooltipPrimitive.Arrow,
              {
                className: cn(
                  "z-50 size-2.5 rotate-45 rounded-[2px] bg-foreground fill-foreground",
                  "data-[side=bottom]:top-1 data-[side=left]:top-1/2! data-[side=left]:-right-1",
                  "data-[side=left]:-translate-y-1/2 data-[side=right]:top-1/2! data-[side=right]:-left-1",
                  "data-[side=right]:-translate-y-1/2 data-[side=top]:-bottom-2.5"
                )
              }
            )
          ]
        }
      )
    }
  ) });
}

// components/site/previews/tooltip.tsx
import { Fragment as Fragment21, jsx as jsx88, jsxs as jsxs53 } from "react/jsx-runtime";
var previewVariantOptions17 = ["top", "right", "bottom", "left"];
function TooltipPreview() {
  const { control, choose } = usePreviewVariant("Tooltip", previewVariantOptions17);
  return /* @__PURE__ */ jsxs53(Fragment21, { children: [
    control,
    /* @__PURE__ */ jsx88(PopupMotionScope, { children: /* @__PURE__ */ jsx88(PreviewStack, { children: /* @__PURE__ */ jsx88(TooltipProvider, { delay: 150, children: /* @__PURE__ */ jsxs53(PreviewRow, { className: "gap-2", children: [
      /* @__PURE__ */ jsxs53(Tooltip, { children: [
        /* @__PURE__ */ jsx88(TooltipTrigger, { render: /* @__PURE__ */ jsx88(Button, { variant: "ghost", size: "icon-sm" }), "aria-label": "Bold", children: /* @__PURE__ */ jsx88(BoldIcon4, {}) }),
        /* @__PURE__ */ jsxs53(TooltipContent, { side: choose("top"), children: [
          "Bold ",
          /* @__PURE__ */ jsx88("span", { className: "opacity-70", children: "(\u2318B)" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs53(Tooltip, { children: [
        /* @__PURE__ */ jsx88(TooltipTrigger, { render: /* @__PURE__ */ jsx88(Button, { variant: "ghost", size: "icon-sm" }), "aria-label": "Italic", children: /* @__PURE__ */ jsx88(ItalicIcon4, {}) }),
        /* @__PURE__ */ jsxs53(TooltipContent, { side: choose("right"), children: [
          "Italic ",
          /* @__PURE__ */ jsx88("span", { className: "opacity-70", children: "(\u2318I)" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs53(Tooltip, { children: [
        /* @__PURE__ */ jsx88(TooltipTrigger, { render: /* @__PURE__ */ jsx88(Button, { variant: "ghost", size: "icon-sm" }), "aria-label": "Underline", children: /* @__PURE__ */ jsx88(UnderlineIcon3, {}) }),
        /* @__PURE__ */ jsxs53(TooltipContent, { side: choose("bottom"), children: [
          "Underline ",
          /* @__PURE__ */ jsx88("span", { className: "opacity-70", children: "(\u2318U)" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs53(Tooltip, { children: [
        /* @__PURE__ */ jsx88(TooltipTrigger, { render: /* @__PURE__ */ jsx88(Button, { variant: "ghost", size: "icon-sm" }), "aria-label": "Insert link", children: /* @__PURE__ */ jsx88(Link2Icon, {}) }),
        /* @__PURE__ */ jsxs53(TooltipContent, { side: choose("left"), children: [
          "Insert link ",
          /* @__PURE__ */ jsx88("span", { className: "opacity-70", children: "(\u2318K)" })
        ] })
      ] })
    ] }) }) }) })
  ] });
}

// registry/cadence/hover-card/index.tsx
import { PreviewCard as PreviewCardPrimitive } from "@base-ui/react/preview-card";
import { jsx as jsx89 } from "react/jsx-runtime";
function HoverCard({ ...props }) {
  return /* @__PURE__ */ jsx89(PreviewCardPrimitive.Root, { "data-slot": "hover-card", ...props });
}
function HoverCardTrigger({ ...props }) {
  return /* @__PURE__ */ jsx89(PreviewCardPrimitive.Trigger, { "data-slot": "hover-card-trigger", ...props });
}
function HoverCardContent({
  className,
  style,
  side = "bottom",
  sideOffset = 4,
  align = "center",
  alignOffset = 4,
  ...props
}) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx89(PreviewCardPrimitive.Portal, { "data-slot": "hover-card-portal", children: /* @__PURE__ */ jsx89(
    PreviewCardPrimitive.Positioner,
    {
      align,
      alignOffset,
      side,
      sideOffset,
      className: "isolate z-50",
      children: /* @__PURE__ */ jsx89(
        PreviewCardPrimitive.Popup,
        {
          "data-slot": "hover-card-content",
          "data-motion": cm.mode,
          style: popupStyle(cm, style),
          className: popupClasses(
            cm,
            cn(
              "z-50 w-64 origin-(--transform-origin) rounded-md border bg-popover p-4 text-popover-foreground shadow-md outline-none transition-[opacity,scale] ease-cadence-out duration-(--motion-duration-fast) data-[ending-style]:opacity-0 data-[starting-style]:opacity-0",
              !cm.reduced && "data-[ending-style]:scale-(--motion-scale-in) data-[starting-style]:scale-(--motion-scale-in)"
            ),
            className
          ),
          ...props
        }
      )
    }
  ) });
}

// components/site/previews/hover-card.tsx
import { Fragment as Fragment22, jsx as jsx90, jsxs as jsxs54 } from "react/jsx-runtime";
var previewVariantOptions18 = ["top", "right", "bottom", "left"];
function HoverCardPreview() {
  const { control, choose } = usePreviewVariant("HoverCard", previewVariantOptions18);
  return /* @__PURE__ */ jsxs54(Fragment22, { children: [
    control,
    /* @__PURE__ */ jsx90(PopupMotionScope, { children: /* @__PURE__ */ jsx90(PreviewStack, { children: /* @__PURE__ */ jsxs54("div", { className: "flex flex-wrap items-center justify-center gap-2 text-sm", children: [
      /* @__PURE__ */ jsx90(Avatar, { size: "sm", children: /* @__PURE__ */ jsx90(AvatarFallback, { children: "AL" }) }),
      /* @__PURE__ */ jsx90("span", { children: "Reviewed by" }),
      /* @__PURE__ */ jsxs54(HoverCard, { children: [
        /* @__PURE__ */ jsx90(HoverCardTrigger, { render: /* @__PURE__ */ jsx90(Button, { variant: "link", size: "sm", className: "h-auto p-0" }), children: "@linruoxin" }),
        /* @__PURE__ */ jsx90(HoverCardContent, { side: choose("bottom"), children: /* @__PURE__ */ jsxs54("div", { className: "flex gap-3", children: [
          /* @__PURE__ */ jsx90(Avatar, { size: "sm", children: /* @__PURE__ */ jsx90(AvatarFallback, { children: "LR" }) }),
          /* @__PURE__ */ jsxs54("div", { className: "flex flex-col gap-1", children: [
            /* @__PURE__ */ jsx90("p", { className: "text-sm leading-none font-medium", children: "Lin Ruoxin" }),
            /* @__PURE__ */ jsx90("p", { className: "text-sm text-muted-foreground", children: "Maintains the motion layer and the registry." }),
            /* @__PURE__ */ jsx90(Button, { size: "xs", variant: "secondary", className: "mt-1 w-fit", children: "Follow" })
          ] })
        ] }) })
      ] }),
      /* @__PURE__ */ jsx90("span", { children: "on 28 October" })
    ] }) }) })
  ] });
}

// registry/cadence/sheet/index.tsx
import { Dialog as SheetPrimitive } from "@base-ui/react/dialog";
import { X as X2 } from "lucide-react";
import { jsx as jsx91, jsxs as jsxs55 } from "react/jsx-runtime";
function Sheet({ ...props }) {
  return /* @__PURE__ */ jsx91(SheetPrimitive.Root, { "data-slot": "sheet", ...props });
}
function SheetTrigger({ ...props }) {
  return /* @__PURE__ */ jsx91(SheetPrimitive.Trigger, { "data-slot": "sheet-trigger", ...props });
}
function SheetClose({ ...props }) {
  return /* @__PURE__ */ jsx91(SheetPrimitive.Close, { "data-slot": "sheet-close", ...props });
}
function SheetPortal({ ...props }) {
  return /* @__PURE__ */ jsx91(SheetPrimitive.Portal, { "data-slot": "sheet-portal", ...props });
}
function SheetOverlay({ className, style, ...props }) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx91(
    SheetPrimitive.Backdrop,
    {
      "data-slot": "sheet-overlay",
      "data-motion": cm.mode,
      style: popupStyle(cm, style),
      className: popupClasses(
        cm,
        cn(
          "fixed inset-0 z-50 bg-black/50 transition-opacity ease-cadence-out duration-(--motion-duration-fast)",
          !cm.disabled && "data-[ending-style]:opacity-0 data-[starting-style]:opacity-0"
        ),
        className
      ),
      ...props
    }
  );
}
function SheetContent({
  className,
  children,
  style,
  side = "right",
  showCloseButton = true,
  ...props
}) {
  const cm = useCadenceMotion();
  const placement = side === "right" ? "inset-y-0 right-0 h-full w-3/4 border-l sm:max-w-sm" : side === "left" ? "inset-y-0 left-0 h-full w-3/4 border-r sm:max-w-sm" : side === "top" ? "inset-x-0 top-0 h-auto border-b" : "inset-x-0 bottom-0 h-auto border-t";
  const slide = side === "right" ? "data-[starting-style]:translate-x-full data-[ending-style]:translate-x-full" : side === "left" ? "data-[starting-style]:-translate-x-full data-[ending-style]:-translate-x-full" : side === "top" ? "data-[starting-style]:-translate-y-full data-[ending-style]:-translate-y-full" : "data-[starting-style]:translate-y-full data-[ending-style]:translate-y-full";
  return /* @__PURE__ */ jsxs55(SheetPortal, { children: [
    /* @__PURE__ */ jsx91(SheetOverlay, {}),
    /* @__PURE__ */ jsxs55(
      SheetPrimitive.Popup,
      {
        "data-slot": "sheet-content",
        "data-side": side,
        "data-motion": cm.mode,
        style: popupStyle(cm, style),
        className: popupClasses(
          cm,
          cn(
            "fixed z-50 flex flex-col gap-4 bg-background shadow-lg outline-none transition-[opacity,translate] ease-cadence-out duration-(--motion-duration-base)",
            placement,
            !cm.disabled && "data-[ending-style]:opacity-0 data-[starting-style]:opacity-0",
            !cm.reduced && slide
          ),
          className
        ),
        ...props,
        children: [
          children,
          showCloseButton && /* @__PURE__ */ jsxs55(
            SheetPrimitive.Close,
            {
              "data-slot": "sheet-close",
              className: "absolute top-4 right-4",
              render: /* @__PURE__ */ jsx91(Button, { variant: "ghost", size: "icon-sm" }),
              children: [
                /* @__PURE__ */ jsx91(X2, {}),
                /* @__PURE__ */ jsx91("span", { className: "sr-only", children: "Close" })
              ]
            }
          )
        ]
      }
    )
  ] });
}
function SheetHeader({ className, ...props }) {
  return /* @__PURE__ */ jsx91("div", { "data-slot": "sheet-header", className: cn("flex flex-col gap-1.5 p-4", className), ...props });
}
function SheetFooter({ className, ...props }) {
  return /* @__PURE__ */ jsx91("div", { "data-slot": "sheet-footer", className: cn("mt-auto flex flex-col gap-2 p-4", className), ...props });
}
function SheetTitle({ className, ...props }) {
  return /* @__PURE__ */ jsx91(
    SheetPrimitive.Title,
    {
      "data-slot": "sheet-title",
      className: stateClasses(cn("text-lg font-semibold"), className),
      ...props
    }
  );
}
function SheetDescription({ className, ...props }) {
  return /* @__PURE__ */ jsx91(
    SheetPrimitive.Description,
    {
      "data-slot": "sheet-description",
      className: stateClasses(cn("text-sm text-muted-foreground"), className),
      ...props
    }
  );
}

// components/site/previews/sheet.tsx
import { Fragment as Fragment23, jsx as jsx92, jsxs as jsxs56 } from "react/jsx-runtime";
var previewVariantOptions19 = ["top", "right", "bottom", "left"];
var SIDES = [
  { side: "right", label: "Right" },
  { side: "left", label: "Left" },
  { side: "top", label: "Top" },
  { side: "bottom", label: "Bottom" }
];
function SheetPreview() {
  const { control, choose } = usePreviewVariant("Sheet", previewVariantOptions19);
  return /* @__PURE__ */ jsxs56(Fragment23, { children: [
    control,
    /* @__PURE__ */ jsx92(PopupMotionScope, { children: /* @__PURE__ */ jsx92(PreviewStack, { children: /* @__PURE__ */ jsx92(PreviewRow, { className: "gap-2", children: SIDES.map(({ side, label: label2 }) => /* @__PURE__ */ jsxs56(Sheet, { children: [
      /* @__PURE__ */ jsx92(SheetTrigger, { render: /* @__PURE__ */ jsx92(Button, { variant: side === "right" ? "outline" : "ghost" }), children: label2 }),
      /* @__PURE__ */ jsxs56(SheetContent, { side: choose(side), children: [
        /* @__PURE__ */ jsxs56(SheetHeader, { children: [
          /* @__PURE__ */ jsx92(SheetTitle, { children: "Filters" }),
          /* @__PURE__ */ jsx92(SheetDescription, { children: "Applied to this view only. Nothing is saved." })
        ] }),
        /* @__PURE__ */ jsxs56("div", { className: "flex flex-col gap-3 px-4", children: [
          /* @__PURE__ */ jsxs56("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx92(Checkbox, { id: `sheet-open-${side}`, defaultChecked: true }),
            /* @__PURE__ */ jsx92(Label, { htmlFor: `sheet-open-${side}`, className: "font-normal", children: "Open only" })
          ] }),
          /* @__PURE__ */ jsxs56("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsx92(Checkbox, { id: `sheet-mine-${side}` }),
            /* @__PURE__ */ jsx92(Label, { htmlFor: `sheet-mine-${side}`, className: "font-normal", children: "Assigned to me" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs56(SheetFooter, { children: [
          /* @__PURE__ */ jsx92(SheetClose, { render: /* @__PURE__ */ jsx92(Button, { variant: "outline" }), children: "Reset" }),
          /* @__PURE__ */ jsx92(SheetClose, { render: /* @__PURE__ */ jsx92(Button, {}), children: "Apply filters" })
        ] })
      ] })
    ] }, side)) }) }) })
  ] });
}

// registry/cadence/drawer/index.tsx
import { Drawer as DrawerPrimitive } from "@base-ui/react/drawer";
import { createContext as createContext9, useContext as useContext10 } from "react";
import { jsx as jsx93, jsxs as jsxs57 } from "react/jsx-runtime";
var DrawerContext = createContext9(null);
function useDrawer() {
  const context = useContext10(DrawerContext);
  if (!context) throw new Error("useDrawer must be used within a Drawer.");
  return context;
}
function Drawer({
  modal = true,
  showSwipeHandle = false,
  snapPoints,
  swipeDirection = "down",
  ...props
}) {
  const hasSnapPoints = snapPoints != null && snapPoints.length > 0;
  return /* @__PURE__ */ jsx93(DrawerContext.Provider, { value: { hasSnapPoints, modal, showSwipeHandle, swipeDirection }, children: /* @__PURE__ */ jsx93(
    DrawerPrimitive.Root,
    {
      "data-slot": "drawer",
      modal,
      snapPoints,
      swipeDirection,
      ...props
    }
  ) });
}
function DrawerTrigger({ ...props }) {
  return /* @__PURE__ */ jsx93(DrawerPrimitive.Trigger, { "data-slot": "drawer-trigger", ...props });
}
function DrawerPortal({ ...props }) {
  return /* @__PURE__ */ jsx93(DrawerPrimitive.Portal, { "data-slot": "drawer-portal", ...props });
}
function DrawerClose({ ...props }) {
  return /* @__PURE__ */ jsx93(DrawerPrimitive.Close, { "data-slot": "drawer-close", ...props });
}
function DrawerOverlay({ className, style, ...props }) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx93(
    DrawerPrimitive.Backdrop,
    {
      "data-slot": "drawer-overlay",
      "data-motion": cm.mode,
      style: popupStyle(cm, style),
      className: popupClasses(
        cm,
        cn(
          "fixed inset-0 z-50 min-h-dvh bg-black/50 transition-opacity ease-cadence-out duration-(--motion-duration-fast) opacity-[calc(1_-_var(--drawer-swipe-progress,0))] data-[ending-style]:opacity-0 data-[starting-style]:opacity-0 data-swiping:duration-0"
        ),
        className
      ),
      ...props
    }
  );
}
function DrawerSwipeHandle({ className, ...props }) {
  return /* @__PURE__ */ jsx93(
    "div",
    {
      "data-slot": "drawer-swipe-handle",
      "aria-hidden": "true",
      className: cn(
        "mx-auto mt-3 h-1.5 w-12 shrink-0 cursor-grab rounded-full bg-muted-foreground/30 active:cursor-grabbing",
        className
      ),
      ...props
    }
  );
}
function DrawerContent({ className, style, children, ...props }) {
  const cm = useCadenceMotion();
  const { hasSnapPoints, modal, showSwipeHandle, swipeDirection } = useDrawer();
  const swipeAxis = swipeDirection === "down" || swipeDirection === "up" ? "y" : "x";
  const placement = swipeDirection === "down" ? "inset-x-0 bottom-0 rounded-t-xl border-t" : swipeDirection === "up" ? "inset-x-0 top-0 rounded-b-xl border-b" : swipeDirection === "left" ? "inset-y-0 left-0 w-3/4 rounded-r-xl border-r sm:max-w-sm" : "inset-y-0 right-0 w-3/4 rounded-l-xl border-l sm:max-w-sm";
  const closedTransform = swipeDirection === "down" ? "[--closed-transform:translate3d(0,calc(100%_+_2px),0)]" : swipeDirection === "up" ? "[--closed-transform:translate3d(0,calc(-100%_-_2px),0)]" : swipeDirection === "left" ? "[--closed-transform:translate3d(calc(-100%_-_2px),0,0)]" : "[--closed-transform:translate3d(calc(100%_+_2px),0,0)]";
  return /* @__PURE__ */ jsxs57(DrawerPortal, { "data-slot": "drawer-portal", children: [
    modal === true && /* @__PURE__ */ jsx93(DrawerOverlay, { "data-snap-points": hasSnapPoints ? "" : void 0 }),
    /* @__PURE__ */ jsx93(
      DrawerPrimitive.Viewport,
      {
        "data-slot": "drawer-viewport",
        "data-modal": modal,
        className: "pointer-events-none fixed inset-0 z-50 select-none data-[modal=true]:pointer-events-auto",
        children: /* @__PURE__ */ jsxs57(
          DrawerPrimitive.Popup,
          {
            "data-slot": "drawer-popup",
            "data-swipe-axis": swipeAxis,
            "data-snap-points": hasSnapPoints ? "" : void 0,
            "data-motion": cm.mode,
            style: popupStyle(cm, style),
            className: popupClasses(
              cm,
              cn(
                "pointer-events-auto fixed z-50 flex flex-col overflow-hidden border bg-background text-foreground shadow-lg outline-none",
                "transition-[transform,opacity] ease-cadence-out duration-(--motion-duration-slow) data-[starting-style]:opacity-0 data-[ending-style]:opacity-0 data-swiping:duration-0",
                "transform-[translate3d(var(--translate-x,0px),var(--translate-y,0px),0)]",
                "data-[swipe-axis=y]:[--translate-y:calc(var(--drawer-snap-point-offset,0px)_+_var(--drawer-swipe-movement-y))]",
                "data-[swipe-axis=x]:[--translate-x:var(--drawer-swipe-movement-x)]",
                "data-[swipe-axis=y]:max-h-[calc(100dvh_-_3rem)] data-[swipe-axis=y]:data-snap-points:h-(--drawer-height)",
                placement,
                !cm.reduced && closedTransform,
                !cm.reduced && "data-[starting-style]:transform-(--closed-transform) data-[ending-style]:transform-(--closed-transform)"
              ),
              className
            ),
            ...props,
            children: [
              showSwipeHandle && /* @__PURE__ */ jsx93(DrawerSwipeHandle, {}),
              /* @__PURE__ */ jsx93(
                DrawerPrimitive.Content,
                {
                  "data-slot": "drawer-content",
                  className: "flex min-h-0 flex-1 flex-col overflow-y-auto overscroll-contain p-4",
                  children
                }
              )
            ]
          }
        )
      }
    )
  ] });
}
function DrawerHeader({ className, ...props }) {
  return /* @__PURE__ */ jsx93("div", { "data-slot": "drawer-header", className: cn("flex shrink-0 flex-col gap-1.5", className), ...props });
}
function DrawerFooter({ className, ...props }) {
  return /* @__PURE__ */ jsx93("div", { "data-slot": "drawer-footer", className: cn("mt-auto flex shrink-0 flex-col gap-2", className), ...props });
}
function DrawerTitle({ className, ...props }) {
  return /* @__PURE__ */ jsx93(
    DrawerPrimitive.Title,
    {
      "data-slot": "drawer-title",
      className: stateClasses(cn("text-lg font-semibold"), className),
      ...props
    }
  );
}
function DrawerDescription({ className, ...props }) {
  return /* @__PURE__ */ jsx93(
    DrawerPrimitive.Description,
    {
      "data-slot": "drawer-description",
      className: stateClasses(cn("text-sm text-balance text-muted-foreground"), className),
      ...props
    }
  );
}

// components/site/previews/drawer.tsx
import { Fragment as Fragment24, jsx as jsx94, jsxs as jsxs58 } from "react/jsx-runtime";
var previewVariantOptions20 = ["down", "up", "left", "right"];
var DESTINATIONS = ["Inbox", "Archive", "Read later"];
function DrawerPreview() {
  const { control, choose } = usePreviewVariant("Drawer", previewVariantOptions20);
  const content = /* @__PURE__ */ jsxs58(Fragment24, { children: [
    /* @__PURE__ */ jsxs58(DrawerHeader, { children: [
      /* @__PURE__ */ jsx94(DrawerTitle, { children: "Move conversation" }),
      /* @__PURE__ */ jsx94(DrawerDescription, { children: "Drag the sheet back to dismiss, or pick a destination." })
    ] }),
    /* @__PURE__ */ jsx94("div", { className: "flex flex-col gap-1 pt-2", children: DESTINATIONS.map((destination) => /* @__PURE__ */ jsx94(DrawerClose, { render: /* @__PURE__ */ jsx94(Button, { variant: "ghost", className: "justify-start" }), children: destination }, destination)) }),
    /* @__PURE__ */ jsx94(DrawerFooter, { children: /* @__PURE__ */ jsx94(DrawerClose, { render: /* @__PURE__ */ jsx94(Button, { variant: "outline" }), children: "Cancel" }) })
  ] });
  return /* @__PURE__ */ jsxs58(Fragment24, { children: [
    control,
    /* @__PURE__ */ jsx94(PopupMotionScope, { children: /* @__PURE__ */ jsx94(PreviewStack, { children: /* @__PURE__ */ jsxs58(PreviewRow, { className: "gap-2", children: [
      /* @__PURE__ */ jsxs58(Drawer, { showSwipeHandle: true, swipeDirection: choose("down"), children: [
        /* @__PURE__ */ jsx94(DrawerTrigger, { render: /* @__PURE__ */ jsx94(Button, { variant: "outline" }), children: "Down" }),
        /* @__PURE__ */ jsx94(DrawerContent, { children: content })
      ] }),
      /* @__PURE__ */ jsxs58(Drawer, { swipeDirection: choose("up"), children: [
        /* @__PURE__ */ jsx94(DrawerTrigger, { render: /* @__PURE__ */ jsx94(Button, { variant: "ghost" }), children: "Up" }),
        /* @__PURE__ */ jsx94(DrawerContent, { children: content })
      ] }),
      /* @__PURE__ */ jsxs58(Drawer, { swipeDirection: choose("right"), children: [
        /* @__PURE__ */ jsx94(DrawerTrigger, { render: /* @__PURE__ */ jsx94(Button, { variant: "ghost" }), children: "From the right" }),
        /* @__PURE__ */ jsx94(DrawerContent, { children: content })
      ] })
    ] }) }) })
  ] });
}

// components/site/previews/select.tsx
import { Fragment as Fragment25, jsx as jsx95, jsxs as jsxs59 } from "react/jsx-runtime";
var previewVariantOptions21 = ["default", "sm"];
var FRAMEWORKS = [
  { value: "next", label: "Next.js" },
  { value: "remix", label: "Remix" },
  { value: "astro", label: "Astro" }
];
function SelectPreview() {
  const { control, choose } = usePreviewVariant("Select", previewVariantOptions21);
  const items = FRAMEWORKS.map((framework) => /* @__PURE__ */ jsx95(SelectItem, { value: framework.value, children: framework.label }, framework.value));
  return /* @__PURE__ */ jsxs59(Fragment25, { children: [
    control,
    /* @__PURE__ */ jsxs59(PopupMotionScope, { children: [
      /* @__PURE__ */ jsxs59(PreviewRow, { className: "gap-3", children: [
        /* @__PURE__ */ jsxs59(Select, { defaultValue: "next", children: [
          /* @__PURE__ */ jsx95(SelectTrigger, { "aria-label": "Framework", size: choose("default"), children: /* @__PURE__ */ jsx95(SelectValue, { placeholder: "Choose a framework" }) }),
          /* @__PURE__ */ jsx95(SelectContent, { children: items })
        ] }),
        /* @__PURE__ */ jsxs59(Select, { children: [
          /* @__PURE__ */ jsx95(SelectTrigger, { "aria-label": "Framework, empty", size: choose("default"), children: /* @__PURE__ */ jsx95(SelectValue, { placeholder: "Choose a framework" }) }),
          /* @__PURE__ */ jsx95(SelectContent, { children: items })
        ] }),
        /* @__PURE__ */ jsxs59(Select, { defaultValue: "remix", children: [
          /* @__PURE__ */ jsx95(SelectTrigger, { size: choose("sm"), "aria-label": "Framework, small", children: /* @__PURE__ */ jsx95(SelectValue, {}) }),
          /* @__PURE__ */ jsx95(SelectContent, { children: items })
        ] })
      ] }),
      /* @__PURE__ */ jsxs59(PreviewRow, { className: "gap-3", children: [
        /* @__PURE__ */ jsxs59(Select, { disabled: true, defaultValue: "next", children: [
          /* @__PURE__ */ jsx95(SelectTrigger, { "aria-label": "Framework, disabled", size: choose("default"), children: /* @__PURE__ */ jsx95(SelectValue, {}) }),
          /* @__PURE__ */ jsx95(SelectContent, { children: items })
        ] }),
        /* @__PURE__ */ jsxs59(Select, { defaultValue: "astro", children: [
          /* @__PURE__ */ jsx95(SelectTrigger, { "aria-label": "Framework, invalid", "aria-invalid": "true", size: choose("default"), children: /* @__PURE__ */ jsx95(SelectValue, {}) }),
          /* @__PURE__ */ jsx95(SelectContent, { children: items })
        ] })
      ] })
    ] })
  ] });
}

// components/site/previews/combobox.tsx
import * as React4 from "react";

// registry/cadence/combobox/index.tsx
import { Combobox as ComboboxPrimitive } from "@base-ui/react/combobox";
import { CheckIcon as CheckIcon4, ChevronDownIcon as ChevronDownIcon3, XIcon as XIcon2 } from "lucide-react";
import * as React3 from "react";
import { jsx as jsx96, jsxs as jsxs60 } from "react/jsx-runtime";
var Combobox = ComboboxPrimitive.Root;
function ComboboxFocusSafety() {
  React3.useLayoutEffect(() => {
    const existing = new Set(document.querySelectorAll('[aria-hidden="true"]'));
    const owned = /* @__PURE__ */ new Set();
    const stops = /* @__PURE__ */ new Map();
    const selector = 'a[href],area[href],button,input,select,textarea,iframe,summary,[tabindex],[contenteditable="true"],audio[controls],video[controls]';
    let released = false;
    const restoreStop = (node, previous) => {
      if (node.getAttribute("tabindex") !== "-1") return;
      if (previous === null) node.removeAttribute("tabindex");
      else node.setAttribute("tabindex", previous);
    };
    const restore = () => {
      for (const [node, previous] of stops) restoreStop(node, previous);
      stops.clear();
      owned.clear();
    };
    const sync = () => {
      for (const node of owned) {
        if (node.getAttribute("aria-hidden") !== "true") {
          owned.delete(node);
        }
      }
      if (released) return;
      for (const node of document.querySelectorAll('[aria-hidden="true"]')) {
        if (!existing.has(node) && !node.closest("[inert]")) {
          owned.add(node);
        }
      }
      for (const [node, previous] of stops) {
        if (![...owned].some((root) => root.contains(node))) {
          restoreStop(node, previous);
          stops.delete(node);
        }
      }
      for (const root of owned) {
        for (const node of [root, ...root.querySelectorAll(selector)]) {
          if (!node.matches(selector) || node.closest("[inert]") || node.tabIndex < 0 || stops.has(node)) continue;
          stops.set(node, node.getAttribute("tabindex"));
          node.tabIndex = -1;
        }
      }
    };
    const observer = new MutationObserver(sync);
    observer.observe(document.body, {
      subtree: true,
      childList: true,
      attributes: true,
      attributeFilter: ["aria-hidden", "data-base-ui-inert"]
    });
    const tab = (event) => {
      if (event.key === "Tab") {
        released = true;
        restore();
      }
    };
    document.addEventListener("keydown", tab, true);
    return () => {
      observer.disconnect();
      document.removeEventListener("keydown", tab, true);
      restore();
    };
  }, []);
  return null;
}
function ComboboxValue({ ...props }) {
  return /* @__PURE__ */ jsx96(ComboboxPrimitive.Value, { "data-slot": "combobox-value", ...props });
}
function ComboboxTrigger({ className, children, ...props }) {
  return /* @__PURE__ */ jsxs60(
    ComboboxPrimitive.Trigger,
    {
      "data-slot": "combobox-trigger",
      "aria-label": "Show options",
      className: stateClasses(
        cn(
          inputGroupButtonVariants({ size: "icon-xs" }),
          "text-muted-foreground hover:bg-accent hover:text-accent-foreground",
          // A hand-placed trigger has no Button behind it, so the glyph size is declared here
          // too; composed into `ComboboxInput` it is the same value, deduped by tailwind-merge.
          "[&_svg:not([class*='size-'])]:size-3"
        ),
        className
      ),
      ...props,
      children: [
        children,
        /* @__PURE__ */ jsx96(ChevronDownIcon3, { className: "pointer-events-none" })
      ]
    }
  );
}
function ComboboxClear({ className, ...props }) {
  return /* @__PURE__ */ jsx96(
    ComboboxPrimitive.Clear,
    {
      "data-slot": "combobox-clear",
      "aria-label": "Clear",
      className: stateClasses(
        cn(
          inputGroupButtonVariants({ size: "icon-xs" }),
          "text-muted-foreground hover:bg-accent hover:text-accent-foreground",
          // `icon-xs` sizes the box but not the glyph, so without this the 24px Lucide default
          // fills it. 12px matches the chevron, whose size Button's own `icon-xs` variant sets.
          "[&_svg:not([class*='size-'])]:size-3"
        ),
        className
      ),
      ...props,
      children: /* @__PURE__ */ jsx96(XIcon2, { className: "pointer-events-none" })
    }
  );
}
function ComboboxInput({
  className,
  children,
  disabled = false,
  showTrigger = true,
  showClear = false,
  ...props
}) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsxs60(InputGroup, { "data-motion": cm.mode, className: cn("w-auto", typeof className === "string" ? className : void 0), children: [
    /* @__PURE__ */ jsx96(
      ComboboxPrimitive.Input,
      {
        className: typeof className === "function" ? className : void 0,
        disabled,
        render: /* @__PURE__ */ jsx96(InputGroupInput, { disabled }),
        ...props
      }
    ),
    /* @__PURE__ */ jsxs60(InputGroupAddon, { align: "inline-end", children: [
      showTrigger && // The trigger is the addon's button, composed the way upstream composes it: the
      // input-group frame supplies the chrome, the trigger supplies the behaviour. The
      // element that lands in the DOM is the trigger's, so `combobox-trigger` is the slot
      // a consumer styles; `input-group-button` is the frame's name for the same control.
      /* @__PURE__ */ jsx96(
        InputGroupButton,
        {
          size: "icon-xs",
          variant: "ghost",
          render: /* @__PURE__ */ jsx96(ComboboxTrigger, {}),
          "data-slot": "input-group-button",
          className: "group-has-data-[slot=combobox-clear]/input-group:hidden data-pressed:bg-transparent",
          disabled
        }
      ),
      showClear && /* @__PURE__ */ jsx96(ComboboxClear, { disabled })
    ] }),
    children
  ] });
}
function ComboboxContent({
  className,
  style,
  side = "bottom",
  sideOffset = 6,
  align = "start",
  alignOffset = 0,
  anchor,
  ...props
}) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsxs60(ComboboxPrimitive.Portal, { children: [
    /* @__PURE__ */ jsx96(ComboboxFocusSafety, {}),
    /* @__PURE__ */ jsx96(
      ComboboxPrimitive.Positioner,
      {
        side,
        sideOffset,
        align,
        alignOffset,
        anchor,
        className: "isolate z-50",
        children: /* @__PURE__ */ jsx96(
          ComboboxPrimitive.Popup,
          {
            "data-slot": "combobox-content",
            "data-motion": cm.mode,
            "data-chips": !!anchor,
            style: popupStyle(cm, style),
            className: popupClasses(
              cm,
              cn(
                "group/combobox-content relative flex max-h-(--available-height) w-(--anchor-width) max-w-(--available-width) min-w-[calc(var(--anchor-width)+--spacing(7))] flex-col overflow-hidden rounded-md border bg-popover text-popover-foreground shadow-md outline-hidden",
                "origin-(--transform-origin) transition-[opacity,scale] ease-cadence-out duration-(--motion-duration-fast) data-[ending-style]:opacity-0 data-[starting-style]:opacity-0",
                !cm.reduced && "data-[ending-style]:scale-(--motion-scale-in) data-[starting-style]:scale-(--motion-scale-in)",
                "data-[chips=true]:min-w-(--anchor-width)"
              ),
              className
            ),
            ...props
          }
        )
      }
    )
  ] });
}
function ComboboxList({ className, ...props }) {
  return /* @__PURE__ */ jsx96(
    ComboboxPrimitive.List,
    {
      "data-slot": "combobox-list",
      className: stateClasses(cn("min-h-0 flex-1 overflow-y-auto overscroll-contain p-1 data-empty:p-0"), className),
      ...props
    }
  );
}
function ComboboxItem({ className, children, ...props }) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsxs60(
    ComboboxPrimitive.Item,
    {
      "data-slot": "combobox-item",
      className: stateClasses(
        cn(
          "relative flex w-full cursor-default items-center gap-2 rounded-sm py-1.5 pr-8 pl-2 text-sm outline-hidden select-none",
          "data-highlighted:bg-accent data-highlighted:text-accent-foreground",
          "data-disabled:pointer-events-none data-disabled:opacity-50",
          "[&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4"
        ),
        className
      ),
      ...props,
      children: [
        children,
        /* @__PURE__ */ jsx96(
          ComboboxPrimitive.ItemIndicator,
          {
            keepMounted: true,
            render: (indicatorProps, state) => {
              const { className: indicatorClassName, ...rest } = indicatorProps;
              return /* @__PURE__ */ jsx96(
                ControlSpan,
                {
                  ...rest,
                  "data-slot": "combobox-item-indicator",
                  "data-motion": cm.mode,
                  className: cn(
                    "pointer-events-none absolute right-2 flex size-4 items-center justify-center",
                    indicatorClassName
                  ),
                  target: state.selected ? { opacity: 1, scale: 1 } : { opacity: 0, scale: cm.reduced ? 1 : scale.in },
                  transition: { ...cm.transition("state.morph"), ...cm.reduced ? { scale: { duration: 0 } } : {} },
                  children: /* @__PURE__ */ jsx96(CheckIcon4, { className: "size-4" })
                }
              );
            }
          }
        )
      ]
    }
  );
}
function ComboboxGroup({ className, ...props }) {
  return /* @__PURE__ */ jsx96(ComboboxPrimitive.Group, { "data-slot": "combobox-group", className: stateClasses("", className), ...props });
}
function ComboboxLabel({ className, ...props }) {
  return /* @__PURE__ */ jsx96(
    ComboboxPrimitive.GroupLabel,
    {
      "data-slot": "combobox-label",
      className: stateClasses(cn("px-2 py-1.5 text-xs text-muted-foreground"), className),
      ...props
    }
  );
}
function ComboboxEmpty({ className, ...props }) {
  return /* @__PURE__ */ jsx96(
    ComboboxPrimitive.Empty,
    {
      "data-slot": "combobox-empty",
      className: stateClasses(
        cn(
          "hidden w-full justify-center py-2 text-center text-sm text-muted-foreground",
          "group-data-empty/combobox-content:flex"
        ),
        className
      ),
      ...props
    }
  );
}
function ComboboxChips({ className, ...props }) {
  return /* @__PURE__ */ jsx96(
    ComboboxPrimitive.Chips,
    {
      "data-slot": "combobox-chips",
      className: stateClasses(
        cn(
          "flex min-h-9 flex-wrap items-center gap-1.5 rounded-md border border-input bg-transparent bg-clip-padding px-2.5 py-1.5 text-sm shadow-xs transition-[color,box-shadow]",
          "focus-within:border-ring focus-within:ring-[3px] focus-within:ring-ring/50",
          "has-aria-invalid:border-destructive has-aria-invalid:ring-[3px] has-aria-invalid:ring-destructive/20",
          "has-data-[slot=combobox-chip]:px-1.5 dark:bg-input/30 dark:has-aria-invalid:border-destructive/50 dark:has-aria-invalid:ring-destructive/40"
        ),
        className
      ),
      ...props
    }
  );
}
function ComboboxChip({
  className,
  children,
  showRemove = true,
  ...props
}) {
  return /* @__PURE__ */ jsxs60(
    ComboboxPrimitive.Chip,
    {
      "data-slot": "combobox-chip",
      className: stateClasses(
        cn(
          "flex h-5.5 w-fit items-center justify-center gap-1 rounded-sm bg-muted px-1.5 text-xs font-medium whitespace-nowrap text-foreground",
          "has-disabled:pointer-events-none has-disabled:cursor-not-allowed has-disabled:opacity-50",
          "has-data-[slot=combobox-chip-remove]:pr-0"
        ),
        className
      ),
      ...props,
      children: [
        children,
        showRemove && /* @__PURE__ */ jsx96(
          ComboboxPrimitive.ChipRemove,
          {
            "data-slot": "combobox-chip-remove",
            "aria-label": typeof children === "string" ? `Remove ${children}` : "Remove",
            className: "-ml-0.5 flex size-5 items-center justify-center rounded-sm opacity-50 transition-opacity hover:bg-accent hover:opacity-100",
            children: /* @__PURE__ */ jsx96(XIcon2, { className: "pointer-events-none size-3" })
          }
        )
      ]
    }
  );
}
function ComboboxChipsInput({ className, ...props }) {
  return /* @__PURE__ */ jsx96(
    ComboboxPrimitive.Input,
    {
      "data-slot": "combobox-chip-input",
      className: stateClasses(cn("min-w-16 flex-1 outline-none"), className),
      ...props
    }
  );
}
function useComboboxAnchor() {
  return React3.useRef(null);
}

// components/site/previews/combobox.tsx
import { jsx as jsx97, jsxs as jsxs61 } from "react/jsx-runtime";
var frameworks = ["Next.js", "SvelteKit", "Nuxt.js", "Remix", "Astro"];
var stacks = [
  { value: "Frontend", items: ["React", "Vue", "Svelte"] },
  { value: "Backend", items: ["Go", "Rust", "Elixir"] }
];
var topics = ["Design", "Docs", "Testing", "Release"];
function ComboboxPreview() {
  const anchor = useComboboxAnchor();
  return /* @__PURE__ */ jsxs61(PopupMotionScope, { children: [
    /* @__PURE__ */ jsxs61(PreviewRow, { className: "items-start", children: [
      /* @__PURE__ */ jsxs61(Combobox, { items: frameworks, children: [
        /* @__PURE__ */ jsx97(ComboboxInput, { className: "w-56", placeholder: "Select a framework", "aria-label": "Framework" }),
        /* @__PURE__ */ jsxs61(ComboboxContent, { children: [
          /* @__PURE__ */ jsx97(ComboboxEmpty, { children: "No framework found." }),
          /* @__PURE__ */ jsx97(ComboboxList, { children: (item) => /* @__PURE__ */ jsx97(ComboboxItem, { value: item, children: item }, item) })
        ] })
      ] }),
      /* @__PURE__ */ jsxs61(Combobox, { items: ["React", "Vue", "Svelte", "Go"], defaultValue: "Vue", children: [
        /* @__PURE__ */ jsx97(ComboboxInput, { className: "w-48", showClear: true, placeholder: "Select a stack", "aria-label": "Stack" }),
        /* @__PURE__ */ jsxs61(ComboboxContent, { children: [
          /* @__PURE__ */ jsx97(ComboboxEmpty, { children: "No stack found." }),
          /* @__PURE__ */ jsx97(ComboboxList, { children: (item) => /* @__PURE__ */ jsx97(ComboboxItem, { value: item, children: item }, item) })
        ] })
      ] }),
      /* @__PURE__ */ jsxs61(Combobox, { items: ["Remix"], disabled: true, defaultValue: "Remix", children: [
        /* @__PURE__ */ jsx97(ComboboxInput, { className: "w-44", placeholder: "Disabled", "aria-label": "Disabled picker" }),
        /* @__PURE__ */ jsx97(ComboboxContent, { children: /* @__PURE__ */ jsx97(ComboboxList, { children: (item) => /* @__PURE__ */ jsx97(ComboboxItem, { value: item, children: item }, item) }) })
      ] })
    ] }),
    /* @__PURE__ */ jsxs61(PreviewRow, { className: "items-start", children: [
      /* @__PURE__ */ jsxs61(Combobox, { items: stacks, children: [
        /* @__PURE__ */ jsx97(ComboboxInput, { className: "w-56", placeholder: "Assign a reviewer", "aria-label": "Reviewer" }),
        /* @__PURE__ */ jsxs61(ComboboxContent, { children: [
          /* @__PURE__ */ jsx97(ComboboxEmpty, { children: "No reviewer found." }),
          /* @__PURE__ */ jsx97(ComboboxList, { children: (group) => /* @__PURE__ */ jsxs61(ComboboxGroup, { items: group.items, children: [
            /* @__PURE__ */ jsx97(ComboboxLabel, { children: group.value }),
            group.items.map((item) => /* @__PURE__ */ jsx97(ComboboxItem, { value: item, children: item }, item))
          ] }, group.value) })
        ] })
      ] }),
      /* @__PURE__ */ jsxs61(Combobox, { multiple: true, items: topics, defaultValue: ["Design"], children: [
        /* @__PURE__ */ jsx97(ComboboxChips, { ref: anchor, className: "w-64", children: /* @__PURE__ */ jsx97(ComboboxValue, { children: (value) => /* @__PURE__ */ jsxs61(React4.Fragment, { children: [
          value.map((topic) => /* @__PURE__ */ jsx97(ComboboxChip, { children: topic }, topic)),
          /* @__PURE__ */ jsx97(ComboboxChipsInput, { placeholder: "Add topic", "aria-label": "Topics" })
        ] }) }) }),
        /* @__PURE__ */ jsxs61(ComboboxContent, { anchor, children: [
          /* @__PURE__ */ jsx97(ComboboxEmpty, { children: "No topic found." }),
          /* @__PURE__ */ jsx97(ComboboxList, { children: (item) => /* @__PURE__ */ jsx97(ComboboxItem, { value: item, children: item }, item) })
        ] })
      ] })
    ] })
  ] });
}

// registry/cadence/dropdown-menu/index.tsx
import { Menu as MenuPrimitive } from "@base-ui/react/menu";
import { CheckIcon as CheckIcon5, ChevronRightIcon as ChevronRightIcon2, CircleIcon } from "lucide-react";
import { createContext as createContext10, useContext as useContext11 } from "react";
import { jsx as jsx98, jsxs as jsxs62 } from "react/jsx-runtime";
function popupClock(cm) {
  const factor = cm.disabled ? 0 : (cm.reduced ? reducedDurationScale : 1) * cm.timeScale;
  return { "--motion-duration-fast": `${duration.fast * factor}s` };
}
function DropdownMenu({ ...props }) {
  return /* @__PURE__ */ jsx98(MenuPrimitive.Root, { "data-slot": "dropdown-menu", ...props });
}
function DropdownMenuTrigger({ ...props }) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx98(MenuPrimitive.Trigger, { "data-slot": "dropdown-menu-trigger", "data-motion": cm.mode, ...props });
}
function DropdownMenuContent({
  align = "start",
  alignOffset = 0,
  side = "bottom",
  sideOffset = 4,
  className,
  style,
  ...props
}) {
  const cm = useCadenceMotion();
  const popupClasses2 = cn(
    "z-50 max-h-(--available-height) min-w-[8rem] origin-(--transform-origin) overflow-x-hidden overflow-y-auto rounded-md border bg-popover p-1 text-popover-foreground shadow-md outline-hidden",
    cm.disabled ? "transition-none duration-0" : "ease-cadence-out duration-(--motion-duration-fast) data-[ending-style]:opacity-0 data-[starting-style]:opacity-0",
    !cm.disabled && (cm.reduced ? "transition-opacity" : "transition-[opacity,scale]"),
    !cm.reduced && "data-[ending-style]:scale-(--motion-scale-in) data-[starting-style]:scale-(--motion-scale-in)"
  );
  return /* @__PURE__ */ jsx98(MenuPrimitive.Portal, { children: /* @__PURE__ */ jsx98(
    MenuPrimitive.Positioner,
    {
      className: "isolate z-50 outline-hidden",
      align,
      alignOffset,
      side,
      sideOffset,
      children: /* @__PURE__ */ jsx98(
        MenuPrimitive.Popup,
        {
          "data-slot": "dropdown-menu-content",
          "data-motion": cm.mode,
          className: typeof className === "function" ? (state) => cn(popupClasses2, className(state)) : cn(popupClasses2, className),
          style: typeof style === "function" ? (state) => ({ ...popupClock(cm), ...style(state) }) : { ...popupClock(cm), ...style },
          ...props
        }
      )
    }
  ) });
}
var DropdownMenuGroupContext = createContext10(false);
function DropdownMenuGroup({ ...props }) {
  return /* @__PURE__ */ jsx98(DropdownMenuGroupContext.Provider, { value: true, children: /* @__PURE__ */ jsx98(MenuPrimitive.Group, { "data-slot": "dropdown-menu-group", ...props }) });
}
function DropdownMenuLabel({
  className,
  inset,
  ...props
}) {
  const inGroup = useContext11(DropdownMenuGroupContext);
  const classes2 = cn("px-2 py-1.5 text-sm font-medium data-[inset]:pl-8", className);
  if (inGroup) {
    return /* @__PURE__ */ jsx98(
      MenuPrimitive.GroupLabel,
      {
        "data-slot": "dropdown-menu-label",
        "data-inset": inset,
        ...props,
        className: classes2
      }
    );
  }
  return /* @__PURE__ */ jsx98("div", { "data-slot": "dropdown-menu-label", "data-inset": inset, className: classes2, ...props });
}
function DropdownMenuItem({
  className,
  inset,
  variant = "default",
  ...props
}) {
  return /* @__PURE__ */ jsx98(
    MenuPrimitive.Item,
    {
      "data-slot": "dropdown-menu-item",
      "data-inset": inset,
      "data-variant": variant,
      className: stateClasses(
        cn(
          "relative flex cursor-default items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-hidden select-none",
          "data-highlighted:bg-accent data-highlighted:text-accent-foreground",
          "data-disabled:pointer-events-none data-disabled:opacity-50",
          "data-[inset]:pl-8",
          "data-[variant=destructive]:text-destructive data-[variant=destructive]:data-highlighted:bg-destructive/10 data-[variant=destructive]:data-highlighted:text-destructive dark:data-[variant=destructive]:data-highlighted:bg-destructive/20",
          "[&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4 [&_svg:not([class*='text-'])]:text-muted-foreground",
          "data-[variant=destructive]:*:[svg]:text-destructive!"
        ),
        className
      ),
      ...props
    }
  );
}
function DropdownMenuSub({ ...props }) {
  return /* @__PURE__ */ jsx98(MenuPrimitive.SubmenuRoot, { "data-slot": "dropdown-menu-sub", ...props });
}
function DropdownMenuSubTrigger({
  className,
  inset,
  children,
  ...props
}) {
  return /* @__PURE__ */ jsxs62(
    MenuPrimitive.SubmenuTrigger,
    {
      "data-slot": "dropdown-menu-sub-trigger",
      "data-inset": inset,
      className: stateClasses(
        cn(
          "flex cursor-default items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-hidden select-none",
          "data-popup-open:bg-accent data-popup-open:text-accent-foreground data-highlighted:bg-accent data-highlighted:text-accent-foreground",
          "data-[inset]:pl-8",
          "[&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4 [&_svg:not([class*='text-'])]:text-muted-foreground"
        ),
        className
      ),
      ...props,
      children: [
        children,
        /* @__PURE__ */ jsx98(ChevronRightIcon2, { className: "ml-auto size-4" })
      ]
    }
  );
}
function DropdownMenuSubContent({
  align = "start",
  alignOffset = -3,
  side = "right",
  sideOffset = 0,
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx98(
    DropdownMenuContent,
    {
      "data-slot": "dropdown-menu-sub-content",
      className: stateClasses(cn("w-auto"), className),
      align,
      alignOffset,
      side,
      sideOffset,
      ...props
    }
  );
}
function DropdownMenuCheckboxItem({
  className,
  children,
  checked,
  inset,
  ...props
}) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsxs62(
    MenuPrimitive.CheckboxItem,
    {
      "data-slot": "dropdown-menu-checkbox-item",
      "data-inset": inset,
      className: stateClasses(
        cn(
          "relative flex cursor-default items-center gap-2 rounded-sm py-1.5 pr-2 pl-8 text-sm outline-hidden select-none",
          "data-highlighted:bg-accent data-highlighted:text-accent-foreground",
          "data-disabled:pointer-events-none data-disabled:opacity-50",
          "[&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4"
        ),
        className
      ),
      checked,
      ...props,
      children: [
        /* @__PURE__ */ jsx98(
          "span",
          {
            "data-slot": "dropdown-menu-checkbox-item-indicator",
            className: "pointer-events-none absolute left-2 flex size-3.5 items-center justify-center",
            children: /* @__PURE__ */ jsx98(
              MenuPrimitive.CheckboxItemIndicator,
              {
                keepMounted: true,
                render: (indicatorProps, state) => {
                  const { className: indicatorClassName, ...rest } = indicatorProps;
                  return /* @__PURE__ */ jsx98(
                    ControlSpan,
                    {
                      ...rest,
                      "data-motion": cm.mode,
                      className: cn("flex items-center justify-center", indicatorClassName),
                      target: state.checked ? { opacity: 1, scale: 1 } : { opacity: 0, scale: cm.reduced ? 1 : scale.in },
                      transition: { ...cm.transition("state.morph"), ...cm.reduced ? { scale: { duration: 0 } } : {} },
                      children: /* @__PURE__ */ jsx98(CheckIcon5, { className: "size-4" })
                    }
                  );
                }
              }
            )
          }
        ),
        children
      ]
    }
  );
}
function DropdownMenuRadioGroup({ ...props }) {
  return /* @__PURE__ */ jsx98(MenuPrimitive.RadioGroup, { "data-slot": "dropdown-menu-radio-group", ...props });
}
function DropdownMenuRadioItem({
  className,
  children,
  inset,
  ...props
}) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsxs62(
    MenuPrimitive.RadioItem,
    {
      "data-slot": "dropdown-menu-radio-item",
      "data-inset": inset,
      className: stateClasses(
        cn(
          "relative flex cursor-default items-center gap-2 rounded-sm py-1.5 pr-2 pl-8 text-sm outline-hidden select-none",
          "data-highlighted:bg-accent data-highlighted:text-accent-foreground",
          "data-disabled:pointer-events-none data-disabled:opacity-50",
          "[&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4"
        ),
        className
      ),
      ...props,
      children: [
        /* @__PURE__ */ jsx98(
          "span",
          {
            "data-slot": "dropdown-menu-radio-item-indicator",
            className: "pointer-events-none absolute left-2 flex size-3.5 items-center justify-center",
            children: /* @__PURE__ */ jsx98(
              MenuPrimitive.RadioItemIndicator,
              {
                keepMounted: true,
                render: (indicatorProps, state) => {
                  const { className: indicatorClassName, ...rest } = indicatorProps;
                  return /* @__PURE__ */ jsx98(
                    ControlSpan,
                    {
                      ...rest,
                      "data-motion": cm.mode,
                      className: cn("flex items-center justify-center", indicatorClassName),
                      target: state.checked ? { opacity: 1, scale: 1 } : { opacity: 0, scale: cm.reduced ? 1 : scale.in },
                      transition: { ...cm.transition("state.morph"), ...cm.reduced ? { scale: { duration: 0 } } : {} },
                      children: /* @__PURE__ */ jsx98(CircleIcon, { className: "size-2 fill-current" })
                    }
                  );
                }
              }
            )
          }
        ),
        children
      ]
    }
  );
}
function DropdownMenuSeparator({ className, ...props }) {
  return /* @__PURE__ */ jsx98(
    MenuPrimitive.Separator,
    {
      "data-slot": "dropdown-menu-separator",
      className: stateClasses(cn("-mx-1 my-1 h-px bg-border"), className),
      ...props
    }
  );
}
function DropdownMenuShortcut({ className, ...props }) {
  return /* @__PURE__ */ jsx98(
    "span",
    {
      "data-slot": "dropdown-menu-shortcut",
      className: cn("ml-auto text-xs tracking-widest text-muted-foreground", className),
      ...props
    }
  );
}

// components/site/previews/dropdown-menu.tsx
import { Fragment as Fragment27, jsx as jsx99, jsxs as jsxs63 } from "react/jsx-runtime";
var previewVariantOptions22 = ["default", "destructive"];
function DropdownMenuPreview() {
  const { control, choose } = usePreviewVariant("DropdownMenu", previewVariantOptions22);
  return /* @__PURE__ */ jsxs63(Fragment27, { children: [
    control,
    /* @__PURE__ */ jsx99(PopupMotionScope, { children: /* @__PURE__ */ jsxs63(PreviewRow, { className: "gap-3", children: [
      /* @__PURE__ */ jsxs63(DropdownMenu, { children: [
        /* @__PURE__ */ jsx99(DropdownMenuTrigger, { render: /* @__PURE__ */ jsx99(Button, { variant: "outline" }), children: "Actions" }),
        /* @__PURE__ */ jsxs63(DropdownMenuContent, { align: "start", className: "w-52", children: [
          /* @__PURE__ */ jsx99(DropdownMenuLabel, { children: "Pull request" }),
          /* @__PURE__ */ jsxs63(DropdownMenuItem, { variant: choose("default"), children: [
            "Edit",
            /* @__PURE__ */ jsx99(DropdownMenuShortcut, { children: "\u2318E" })
          ] }),
          /* @__PURE__ */ jsxs63(DropdownMenuItem, { variant: choose("default"), children: [
            "Duplicate",
            /* @__PURE__ */ jsx99(DropdownMenuShortcut, { children: "\u2318D" })
          ] }),
          /* @__PURE__ */ jsxs63(DropdownMenuSub, { children: [
            /* @__PURE__ */ jsx99(DropdownMenuSubTrigger, { children: "Move to" }),
            /* @__PURE__ */ jsxs63(DropdownMenuSubContent, { className: "w-44", children: [
              /* @__PURE__ */ jsx99(DropdownMenuItem, { variant: choose("default"), children: "Backlog" }),
              /* @__PURE__ */ jsx99(DropdownMenuItem, { variant: choose("default"), children: "In review" }),
              /* @__PURE__ */ jsx99(DropdownMenuItem, { variant: choose("default"), children: "Done" })
            ] })
          ] }),
          /* @__PURE__ */ jsx99(DropdownMenuSeparator, {}),
          /* @__PURE__ */ jsxs63(DropdownMenuItem, { variant: choose("destructive"), children: [
            "Delete",
            /* @__PURE__ */ jsx99(DropdownMenuShortcut, { children: "\u2318\u232B" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs63(DropdownMenu, { children: [
        /* @__PURE__ */ jsx99(DropdownMenuTrigger, { render: /* @__PURE__ */ jsx99(Button, { variant: "ghost" }), children: "View" }),
        /* @__PURE__ */ jsxs63(DropdownMenuContent, { align: "start", className: "w-52", children: [
          /* @__PURE__ */ jsx99(DropdownMenuLabel, { children: "Show" }),
          /* @__PURE__ */ jsx99(DropdownMenuCheckboxItem, { defaultChecked: true, children: "Description" }),
          /* @__PURE__ */ jsx99(DropdownMenuCheckboxItem, { children: "Comments" }),
          /* @__PURE__ */ jsx99(DropdownMenuSeparator, {}),
          /* @__PURE__ */ jsx99(DropdownMenuLabel, { children: "Density" }),
          /* @__PURE__ */ jsxs63(DropdownMenuRadioGroup, { defaultValue: "comfortable", children: [
            /* @__PURE__ */ jsx99(DropdownMenuRadioItem, { value: "compact", children: "Compact" }),
            /* @__PURE__ */ jsx99(DropdownMenuRadioItem, { value: "comfortable", children: "Comfortable" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs63(DropdownMenu, { children: [
        /* @__PURE__ */ jsx99(DropdownMenuTrigger, { render: /* @__PURE__ */ jsx99(Button, { variant: "secondary" }), disabled: true, children: "Disabled" }),
        /* @__PURE__ */ jsx99(DropdownMenuContent, { children: /* @__PURE__ */ jsx99(DropdownMenuItem, { variant: choose("default"), children: "Nothing here" }) })
      ] })
    ] }) })
  ] });
}

// registry/cadence/context-menu/index.tsx
import { ContextMenu as ContextMenuPrimitive } from "@base-ui/react/context-menu";
import { CheckIcon as CheckIcon6, ChevronRightIcon as ChevronRightIcon3, CircleIcon as CircleIcon2 } from "lucide-react";
import { createContext as createContext11, useContext as useContext12 } from "react";
import { jsx as jsx100, jsxs as jsxs64 } from "react/jsx-runtime";
function ContextMenu({ ...props }) {
  return /* @__PURE__ */ jsx100(ContextMenuPrimitive.Root, { "data-slot": "context-menu", ...props });
}
function ContextMenuTrigger({ className, ...props }) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx100(
    ContextMenuPrimitive.Trigger,
    {
      "data-slot": "context-menu-trigger",
      "data-motion": cm.mode,
      className: stateClasses(cn("select-none"), className),
      ...props
    }
  );
}
function ContextMenuContent({
  align = "start",
  alignOffset = 4,
  side = "right",
  sideOffset = 0,
  className,
  style,
  ...props
}) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx100(ContextMenuPrimitive.Portal, { children: /* @__PURE__ */ jsx100(
    ContextMenuPrimitive.Positioner,
    {
      className: "isolate z-50 outline-hidden",
      align,
      alignOffset,
      side,
      sideOffset,
      children: /* @__PURE__ */ jsx100(
        ContextMenuPrimitive.Popup,
        {
          "data-slot": "context-menu-content",
          "data-motion": cm.mode,
          style: popupStyle(cm, style),
          className: popupClasses(
            cm,
            cn(
              "z-50 max-h-(--available-height) min-w-[8rem] origin-(--transform-origin) overflow-x-hidden overflow-y-auto rounded-md border bg-popover p-1 text-popover-foreground shadow-md outline-hidden",
              "transition-[opacity,scale] ease-cadence-out duration-(--motion-duration-fast) data-[ending-style]:opacity-0 data-[starting-style]:opacity-0",
              !cm.reduced && "data-[ending-style]:scale-(--motion-scale-in) data-[starting-style]:scale-(--motion-scale-in)"
            ),
            className
          ),
          ...props
        }
      )
    }
  ) });
}
var ContextMenuGroupContext = createContext11(false);
function ContextMenuLabel({
  className,
  inset,
  ...props
}) {
  const inGroup = useContext12(ContextMenuGroupContext);
  const classes2 = cn("px-2 py-1.5 text-sm font-medium data-[inset]:pl-8", className);
  if (inGroup) {
    return /* @__PURE__ */ jsx100(
      ContextMenuPrimitive.GroupLabel,
      {
        "data-slot": "context-menu-label",
        "data-inset": inset,
        ...props,
        className: classes2
      }
    );
  }
  return /* @__PURE__ */ jsx100("div", { "data-slot": "context-menu-label", "data-inset": inset, className: classes2, ...props });
}
function ContextMenuItem({
  className,
  inset,
  variant = "default",
  ...props
}) {
  return /* @__PURE__ */ jsx100(
    ContextMenuPrimitive.Item,
    {
      "data-slot": "context-menu-item",
      "data-inset": inset,
      "data-variant": variant,
      className: stateClasses(
        cn(
          "relative flex cursor-default items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-hidden select-none",
          "data-highlighted:bg-accent data-highlighted:text-accent-foreground",
          "data-disabled:pointer-events-none data-disabled:opacity-50",
          "data-[inset]:pl-8",
          "data-[variant=destructive]:text-destructive data-[variant=destructive]:data-highlighted:bg-destructive/10 data-[variant=destructive]:data-highlighted:text-destructive dark:data-[variant=destructive]:data-highlighted:bg-destructive/20",
          "[&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4 [&_svg:not([class*='text-'])]:text-muted-foreground",
          "data-[variant=destructive]:*:[svg]:text-destructive!"
        ),
        className
      ),
      ...props
    }
  );
}
function ContextMenuSub({ ...props }) {
  return /* @__PURE__ */ jsx100(ContextMenuPrimitive.SubmenuRoot, { "data-slot": "context-menu-sub", ...props });
}
function ContextMenuSubTrigger({
  className,
  inset,
  children,
  ...props
}) {
  return /* @__PURE__ */ jsxs64(
    ContextMenuPrimitive.SubmenuTrigger,
    {
      "data-slot": "context-menu-sub-trigger",
      "data-inset": inset,
      className: stateClasses(
        cn(
          "flex cursor-default items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-hidden select-none",
          "data-popup-open:bg-accent data-popup-open:text-accent-foreground data-highlighted:bg-accent data-highlighted:text-accent-foreground",
          "data-[inset]:pl-8",
          "[&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4 [&_svg:not([class*='text-'])]:text-muted-foreground"
        ),
        className
      ),
      ...props,
      children: [
        children,
        /* @__PURE__ */ jsx100(ChevronRightIcon3, { className: "ml-auto size-4" })
      ]
    }
  );
}
function ContextMenuSubContent({
  align = "start",
  alignOffset = 4,
  side = "right",
  sideOffset = 0,
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx100(
    ContextMenuContent,
    {
      "data-slot": "context-menu-sub-content",
      className: stateClasses(cn("w-auto"), className),
      align,
      alignOffset,
      side,
      sideOffset,
      ...props
    }
  );
}
function ContextMenuCheckboxItem({
  className,
  children,
  checked,
  inset,
  ...props
}) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsxs64(
    ContextMenuPrimitive.CheckboxItem,
    {
      "data-slot": "context-menu-checkbox-item",
      "data-inset": inset,
      className: stateClasses(
        cn(
          "relative flex cursor-default items-center gap-2 rounded-sm py-1.5 pr-2 pl-8 text-sm outline-hidden select-none",
          "data-highlighted:bg-accent data-highlighted:text-accent-foreground",
          "data-disabled:pointer-events-none data-disabled:opacity-50",
          "[&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4"
        ),
        className
      ),
      checked,
      ...props,
      children: [
        /* @__PURE__ */ jsx100(
          "span",
          {
            "data-slot": "context-menu-checkbox-item-indicator",
            className: "pointer-events-none absolute left-2 flex size-3.5 items-center justify-center",
            children: /* @__PURE__ */ jsx100(
              ContextMenuPrimitive.CheckboxItemIndicator,
              {
                keepMounted: true,
                render: (indicatorProps, state) => {
                  const { className: indicatorClassName, ...rest } = indicatorProps;
                  return /* @__PURE__ */ jsx100(
                    ControlSpan,
                    {
                      ...rest,
                      "data-motion": cm.mode,
                      className: cn("flex items-center justify-center", indicatorClassName),
                      target: state.checked ? { opacity: 1, scale: 1 } : { opacity: 0, scale: cm.reduced ? 1 : scale.in },
                      transition: { ...cm.transition("state.morph"), ...cm.reduced ? { scale: { duration: 0 } } : {} },
                      children: /* @__PURE__ */ jsx100(CheckIcon6, { className: "size-4" })
                    }
                  );
                }
              }
            )
          }
        ),
        children
      ]
    }
  );
}
function ContextMenuSeparator({ className, ...props }) {
  return /* @__PURE__ */ jsx100(
    ContextMenuPrimitive.Separator,
    {
      "data-slot": "context-menu-separator",
      className: stateClasses(cn("-mx-1 my-1 h-px bg-border"), className),
      ...props
    }
  );
}
function ContextMenuShortcut({ className, ...props }) {
  return /* @__PURE__ */ jsx100(
    "span",
    {
      "data-slot": "context-menu-shortcut",
      className: cn("ml-auto text-xs tracking-widest text-muted-foreground", className),
      ...props
    }
  );
}

// components/site/previews/context-menu.tsx
import { Fragment as Fragment28, jsx as jsx101, jsxs as jsxs65 } from "react/jsx-runtime";
var previewVariantOptions23 = ["default", "destructive"];
function ContextMenuPreview() {
  const { control, choose } = usePreviewVariant("ContextMenu", previewVariantOptions23);
  return /* @__PURE__ */ jsxs65(Fragment28, { children: [
    control,
    /* @__PURE__ */ jsx101(PopupMotionScope, { children: /* @__PURE__ */ jsxs65(PreviewRow, { className: "gap-3", children: [
      /* @__PURE__ */ jsxs65(ContextMenu, { children: [
        /* @__PURE__ */ jsxs65(
          ContextMenuTrigger,
          {
            tabIndex: 0,
            className: "flex h-24 w-56 flex-col items-center justify-center gap-1 rounded-lg border border-dashed text-sm text-muted-foreground",
            children: [
              /* @__PURE__ */ jsx101("span", { className: "font-medium text-foreground", children: "Right-click here" }),
              /* @__PURE__ */ jsx101("span", { className: "text-xs", children: "A file, a row, a canvas" })
            ]
          }
        ),
        /* @__PURE__ */ jsxs65(ContextMenuContent, { className: "w-52", children: [
          /* @__PURE__ */ jsxs65(ContextMenuItem, { variant: choose("default"), children: [
            "Open",
            /* @__PURE__ */ jsx101(ContextMenuShortcut, { children: "\u21B5" })
          ] }),
          /* @__PURE__ */ jsxs65(ContextMenuItem, { variant: choose("default"), children: [
            "Rename",
            /* @__PURE__ */ jsx101(ContextMenuShortcut, { children: "F2" })
          ] }),
          /* @__PURE__ */ jsxs65(ContextMenuSub, { children: [
            /* @__PURE__ */ jsx101(ContextMenuSubTrigger, { children: "Open with" }),
            /* @__PURE__ */ jsxs65(ContextMenuSubContent, { className: "w-44", children: [
              /* @__PURE__ */ jsx101(ContextMenuItem, { variant: choose("default"), children: "Editor" }),
              /* @__PURE__ */ jsx101(ContextMenuItem, { variant: choose("default"), children: "Preview" })
            ] })
          ] }),
          /* @__PURE__ */ jsx101(ContextMenuSeparator, {}),
          /* @__PURE__ */ jsxs65(ContextMenuItem, { variant: choose("destructive"), children: [
            "Delete",
            /* @__PURE__ */ jsx101(ContextMenuShortcut, { children: "\u2318\u232B" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs65(ContextMenu, { children: [
        /* @__PURE__ */ jsxs65(
          ContextMenuTrigger,
          {
            tabIndex: 0,
            className: "flex h-24 w-56 flex-col items-center justify-center gap-1 rounded-lg border border-dashed text-sm",
            children: [
              /* @__PURE__ */ jsx101("span", { className: "font-medium", children: "Selection" }),
              /* @__PURE__ */ jsx101("span", { className: "text-xs text-muted-foreground", children: "Checkbox and radio items" })
            ]
          }
        ),
        /* @__PURE__ */ jsxs65(ContextMenuContent, { className: "w-52", children: [
          /* @__PURE__ */ jsx101(ContextMenuLabel, { children: "Show" }),
          /* @__PURE__ */ jsx101(ContextMenuCheckboxItem, { defaultChecked: true, children: "Grid" }),
          /* @__PURE__ */ jsx101(ContextMenuCheckboxItem, { children: "Rulers" })
        ] })
      ] })
    ] }) })
  ] });
}

// registry/cadence/menubar/index.tsx
import { Menubar as MenubarPrimitive } from "@base-ui/react/menubar";
import { jsx as jsx102 } from "react/jsx-runtime";
function Menubar({ className, ...props }) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx102(
    MenubarPrimitive,
    {
      "data-slot": "menubar",
      "data-motion": cm.mode,
      className: stateClasses(
        cn("flex h-9 items-center gap-1 rounded-md border bg-background p-1 shadow-xs"),
        className
      ),
      ...props
    }
  );
}
function MenubarMenu({ ...props }) {
  return /* @__PURE__ */ jsx102(DropdownMenu, { "data-slot": "menubar-menu", ...props });
}
function MenubarTrigger({ className, ...props }) {
  return /* @__PURE__ */ jsx102(
    DropdownMenuTrigger,
    {
      "data-slot": "menubar-trigger",
      className: stateClasses(
        cn(
          "flex items-center rounded-sm px-2 py-1 text-sm font-medium outline-hidden select-none",
          "data-popup-open:bg-accent data-popup-open:text-accent-foreground data-highlighted:bg-accent data-highlighted:text-accent-foreground"
        ),
        className
      ),
      ...props
    }
  );
}
function MenubarContent({
  className,
  align = "start",
  alignOffset = -4,
  sideOffset = 8,
  ...props
}) {
  return /* @__PURE__ */ jsx102(
    DropdownMenuContent,
    {
      "data-slot": "menubar-content",
      align,
      alignOffset,
      sideOffset,
      className: stateClasses(cn("min-w-[12rem]"), className),
      ...props
    }
  );
}
function MenubarItem({
  className,
  inset,
  variant = "default",
  ...props
}) {
  return /* @__PURE__ */ jsx102(
    DropdownMenuItem,
    {
      "data-slot": "menubar-item",
      "data-inset": inset,
      "data-variant": variant,
      className: stateClasses(cn("group/menubar-item"), className),
      ...props
    }
  );
}
function MenubarCheckboxItem({
  className,
  children,
  checked,
  inset,
  ...props
}) {
  return /* @__PURE__ */ jsx102(
    DropdownMenuCheckboxItem,
    {
      "data-slot": "menubar-checkbox-item",
      "data-inset": inset,
      className,
      checked,
      ...props,
      children
    }
  );
}
function MenubarRadioGroup({ ...props }) {
  return /* @__PURE__ */ jsx102(DropdownMenuRadioGroup, { "data-slot": "menubar-radio-group", ...props });
}
function MenubarRadioItem({
  className,
  children,
  inset,
  ...props
}) {
  return /* @__PURE__ */ jsx102(DropdownMenuRadioItem, { "data-slot": "menubar-radio-item", "data-inset": inset, className, ...props, children });
}
function MenubarLabel({ className, inset, ...props }) {
  return /* @__PURE__ */ jsx102(DropdownMenuLabel, { "data-slot": "menubar-label", "data-inset": inset, className, ...props });
}
function MenubarSeparator({ className, ...props }) {
  return /* @__PURE__ */ jsx102(
    DropdownMenuSeparator,
    {
      "data-slot": "menubar-separator",
      className: stateClasses(cn("-mx-1 my-1 h-px"), className),
      ...props
    }
  );
}
function MenubarShortcut({ className, ...props }) {
  return /* @__PURE__ */ jsx102(DropdownMenuShortcut, { "data-slot": "menubar-shortcut", className: cn("ml-auto", className), ...props });
}
function MenubarSub({ ...props }) {
  return /* @__PURE__ */ jsx102(DropdownMenuSub, { "data-slot": "menubar-sub", ...props });
}
function MenubarSubTrigger({ className, inset, ...props }) {
  return /* @__PURE__ */ jsx102(DropdownMenuSubTrigger, { "data-slot": "menubar-sub-trigger", "data-inset": inset, className, ...props });
}
function MenubarSubContent({ className, ...props }) {
  return /* @__PURE__ */ jsx102(DropdownMenuSubContent, { "data-slot": "menubar-sub-content", className, ...props });
}

// components/site/previews/menubar.tsx
import { Fragment as Fragment29, jsx as jsx103, jsxs as jsxs66 } from "react/jsx-runtime";
var previewVariantOptions24 = ["default", "destructive"];
function MenubarPreview() {
  const { control, choose } = usePreviewVariant("Menubar", previewVariantOptions24);
  return /* @__PURE__ */ jsxs66(Fragment29, { children: [
    control,
    /* @__PURE__ */ jsx103(PopupMotionScope, { children: /* @__PURE__ */ jsxs66(Menubar, { children: [
      /* @__PURE__ */ jsxs66(MenubarMenu, { children: [
        /* @__PURE__ */ jsx103(MenubarTrigger, { children: "File" }),
        /* @__PURE__ */ jsxs66(MenubarContent, { children: [
          /* @__PURE__ */ jsxs66(MenubarItem, { variant: choose("default"), children: [
            "New",
            /* @__PURE__ */ jsx103(MenubarShortcut, { children: "\u2318N" })
          ] }),
          /* @__PURE__ */ jsxs66(MenubarItem, { variant: choose("default"), children: [
            "Open\u2026",
            /* @__PURE__ */ jsx103(MenubarShortcut, { children: "\u2318O" })
          ] }),
          /* @__PURE__ */ jsx103(MenubarSeparator, {}),
          /* @__PURE__ */ jsxs66(MenubarItem, { variant: choose("default"), children: [
            "Save",
            /* @__PURE__ */ jsx103(MenubarShortcut, { children: "\u2318S" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs66(MenubarMenu, { children: [
        /* @__PURE__ */ jsx103(MenubarTrigger, { children: "Edit" }),
        /* @__PURE__ */ jsxs66(MenubarContent, { children: [
          /* @__PURE__ */ jsxs66(MenubarItem, { variant: choose("default"), children: [
            "Undo",
            /* @__PURE__ */ jsx103(MenubarShortcut, { children: "\u2318Z" })
          ] }),
          /* @__PURE__ */ jsxs66(MenubarItem, { variant: choose("default"), children: [
            "Redo",
            /* @__PURE__ */ jsx103(MenubarShortcut, { children: "\u21E7\u2318Z" })
          ] }),
          /* @__PURE__ */ jsx103(MenubarSeparator, {}),
          /* @__PURE__ */ jsxs66(MenubarSub, { children: [
            /* @__PURE__ */ jsx103(MenubarSubTrigger, { children: "Find" }),
            /* @__PURE__ */ jsxs66(MenubarSubContent, { className: "w-44", children: [
              /* @__PURE__ */ jsx103(MenubarItem, { variant: choose("default"), children: "Next match" }),
              /* @__PURE__ */ jsx103(MenubarItem, { variant: choose("default"), children: "Previous match" })
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs66(MenubarMenu, { children: [
        /* @__PURE__ */ jsx103(MenubarTrigger, { children: "View" }),
        /* @__PURE__ */ jsxs66(MenubarContent, { children: [
          /* @__PURE__ */ jsx103(MenubarLabel, { children: "Show" }),
          /* @__PURE__ */ jsx103(MenubarCheckboxItem, { defaultChecked: true, children: "Sidebar" }),
          /* @__PURE__ */ jsx103(MenubarCheckboxItem, { children: "Line numbers" }),
          /* @__PURE__ */ jsx103(MenubarSeparator, {}),
          /* @__PURE__ */ jsx103(MenubarLabel, { children: "Density" }),
          /* @__PURE__ */ jsxs66(MenubarRadioGroup, { defaultValue: "comfortable", children: [
            /* @__PURE__ */ jsx103(MenubarRadioItem, { value: "compact", children: "Compact" }),
            /* @__PURE__ */ jsx103(MenubarRadioItem, { value: "comfortable", children: "Comfortable" })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxs66(MenubarMenu, { children: [
        /* @__PURE__ */ jsx103(MenubarTrigger, { children: "Help" }),
        /* @__PURE__ */ jsxs66(MenubarContent, { children: [
          /* @__PURE__ */ jsx103(MenubarItem, { variant: choose("default"), children: "Documentation" }),
          /* @__PURE__ */ jsx103(MenubarItem, { variant: choose("default"), children: "Keyboard shortcuts" })
        ] })
      ] })
    ] }) })
  ] });
}

// components/site/previews/code-block.tsx
import { FileCode2Icon } from "lucide-react";
import { Fragment as Fragment30, jsx as jsx104, jsxs as jsxs67 } from "react/jsx-runtime";
var previewVariantOptions25 = ["default", "destructive"];
var SOURCE = `export async function stream({ prompt, signal }: StreamOptions) {
  const response = await fetch("/api/chat", {
    method: "POST",
    body: JSON.stringify({ prompt }),
    signal,
  });

  if (!response.ok) throw new Error(await response.text());

  const reader = response.body?.pipeThrough(new TextDecoderStream());

  for await (const chunk of reader) {
    controller.enqueue(chunk);
    if (signal.aborted) break;
  }
};`;
var INSTALL = {
  pnpm: "pnpm dlx shadcn@latest add @cadence/code-block",
  npm: "npx shadcn@latest add @cadence/code-block",
  yarn: "yarn dlx shadcn@latest add @cadence/code-block"
};
function CodeBlockPreview() {
  const { control, choose } = usePreviewVariant("CodeBlock", previewVariantOptions25);
  return /* @__PURE__ */ jsxs67(Fragment30, { children: [
    control,
    /* @__PURE__ */ jsx104(PreviewStack, { children: /* @__PURE__ */ jsxs67("div", { className: "grid w-full max-w-xl gap-4", children: [
      /* @__PURE__ */ jsxs67(CodeBlock, { maxLines: 6, language: "tsx", variant: choose("default"), children: [
        /* @__PURE__ */ jsxs67(CodeBlockHeader, { children: [
          /* @__PURE__ */ jsxs67(CodeBlockTitle, { children: [
            /* @__PURE__ */ jsx104(FileCode2Icon, {}),
            "app/api/chat/route.ts"
          ] }),
          /* @__PURE__ */ jsx104(CodeBlockActions, { children: /* @__PURE__ */ jsx104(CodeBlockCopyButton, { value: SOURCE }) })
        ] }),
        /* @__PURE__ */ jsx104(CodeBlockContent, { lineNumbers: true, children: SOURCE }),
        /* @__PURE__ */ jsx104(CodeBlockFooter, { className: "justify-center", children: /* @__PURE__ */ jsx104(CodeBlockExpandButton, {}) })
      ] }),
      /* @__PURE__ */ jsxs67(CodeBlock, { defaultTab: "pnpm", language: "bash", variant: choose("default"), children: [
        /* @__PURE__ */ jsxs67(CodeBlockHeader, { children: [
          /* @__PURE__ */ jsxs67(CodeBlockTabs, { label: "Package manager", children: [
            /* @__PURE__ */ jsx104(CodeBlockTab, { value: "pnpm", children: "pnpm" }),
            /* @__PURE__ */ jsx104(CodeBlockTab, { value: "npm", children: "npm" }),
            /* @__PURE__ */ jsx104(CodeBlockTab, { value: "yarn", children: "yarn" })
          ] }),
          /* @__PURE__ */ jsx104(CodeBlockActions, { children: /* @__PURE__ */ jsx104(CodeBlockCopyButton, { values: INSTALL }) })
        ] }),
        /* @__PURE__ */ jsx104(CodeBlockPanel, { value: "pnpm", children: INSTALL.pnpm }),
        /* @__PURE__ */ jsx104(CodeBlockPanel, { value: "npm", children: INSTALL.npm }),
        /* @__PURE__ */ jsx104(CodeBlockPanel, { value: "yarn", children: INSTALL.yarn })
      ] })
    ] }) })
  ] });
}

// components/site/previews/command.tsx
import { useState as useState24 } from "react";

// registry/cadence/command/index.tsx
import { Command as CommandPrimitive } from "cmdk";
import { CheckIcon as CheckIcon7, SearchIcon as SearchIcon2 } from "lucide-react";
import { jsx as jsx105, jsxs as jsxs68 } from "react/jsx-runtime";
function Command({ className, ...props }) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx105(
    CommandPrimitive,
    {
      "data-motion": cm.mode,
      "data-slot": "command",
      className: cn(
        "flex h-full w-full flex-col overflow-hidden rounded-md bg-popover text-popover-foreground",
        className
      ),
      ...props
    }
  );
}
function CommandDialog({
  title = "Command Palette",
  description = "Search for a command to run...",
  children,
  className,
  showCloseButton = false,
  ...props
}) {
  return /* @__PURE__ */ jsx105(Dialog, { ...props, children: /* @__PURE__ */ jsxs68(
    DialogContent,
    {
      className: cn("top-1/3 translate-y-0 overflow-hidden p-0", className),
      showCloseButton,
      children: [
        /* @__PURE__ */ jsxs68(DialogHeader, { className: "sr-only", children: [
          /* @__PURE__ */ jsx105(DialogTitle, { children: title }),
          /* @__PURE__ */ jsx105(DialogDescription, { children: description })
        ] }),
        children
      ]
    }
  ) });
}
function CommandInput({ className, asChild, children, ...props }) {
  return /* @__PURE__ */ jsx105("div", { "data-slot": "command-input-wrapper", className: "border-b p-2", children: /* @__PURE__ */ jsxs68(InputGroup, { className: "border-0 shadow-none ring-0 focus-within:ring-0", children: [
    /* @__PURE__ */ jsx105(
      CommandPrimitive.Input,
      {
        "data-slot": "command-input",
        className: cn("outline-hidden disabled:cursor-not-allowed disabled:opacity-50", className),
        asChild: true,
        ...props,
        children: asChild ? children : /* @__PURE__ */ jsx105(InputGroupInput, {})
      }
    ),
    /* @__PURE__ */ jsx105(InputGroupAddon, { children: /* @__PURE__ */ jsx105(SearchIcon2, {}) })
  ] }) });
}
function CommandList({ className, ...props }) {
  return /* @__PURE__ */ jsx105(
    CommandPrimitive.List,
    {
      "data-slot": "command-list",
      className: cn("max-h-[300px] scroll-py-1 overflow-x-hidden overflow-y-auto", className),
      ...props
    }
  );
}
function CommandEmpty({ className, ...props }) {
  return /* @__PURE__ */ jsx105(
    CommandPrimitive.Empty,
    {
      "data-slot": "command-empty",
      className: cn("py-6 text-center text-sm", className),
      ...props
    }
  );
}
function CommandGroup({ className, ...props }) {
  return /* @__PURE__ */ jsx105(
    CommandPrimitive.Group,
    {
      "data-slot": "command-group",
      className: cn(
        "overflow-hidden p-1 text-foreground [&_[cmdk-group-heading]]:px-2 [&_[cmdk-group-heading]]:py-1.5 [&_[cmdk-group-heading]]:text-xs [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-muted-foreground",
        className
      ),
      ...props
    }
  );
}
function CommandSeparator({ className, ...props }) {
  return /* @__PURE__ */ jsx105(
    CommandPrimitive.Separator,
    {
      "data-slot": "command-separator",
      "aria-hidden": "true",
      className: cn("-mx-1 h-px bg-border", className),
      ...props
    }
  );
}
function CommandItem({ className, children, ...props }) {
  return /* @__PURE__ */ jsxs68(
    CommandPrimitive.Item,
    {
      "data-slot": "command-item",
      className: cn(
        "group/command-item relative flex cursor-default items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-hidden select-none data-[disabled=true]:pointer-events-none data-[disabled=true]:opacity-50 data-[selected=true]:bg-accent data-[selected=true]:text-accent-foreground [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4 [&_svg:not([class*='text-'])]:text-muted-foreground",
        className
      ),
      ...props,
      children: [
        children,
        /* @__PURE__ */ jsx105(
          CheckIcon7,
          {
            "aria-hidden": "true",
            className: "ml-auto opacity-0 group-has-data-[slot=command-shortcut]/command-item:hidden group-data-[checked=true]/command-item:opacity-100"
          }
        )
      ]
    }
  );
}
function CommandShortcut({ className, ...props }) {
  return /* @__PURE__ */ jsx105(
    "span",
    {
      "data-slot": "command-shortcut",
      className: cn("ml-auto text-xs tracking-widest text-muted-foreground", className),
      ...props
    }
  );
}

// components/site/previews/command.tsx
import { jsx as jsx106, jsxs as jsxs69 } from "react/jsx-runtime";
function Actions({ onSelect }) {
  return /* @__PURE__ */ jsxs69(Command, { label: "Workspace actions", className: "rounded-lg border", children: [
    /* @__PURE__ */ jsx106(CommandInput, { placeholder: "Search workspace..." }),
    /* @__PURE__ */ jsxs69(CommandList, { children: [
      /* @__PURE__ */ jsx106(CommandEmpty, { children: "No actions found." }),
      /* @__PURE__ */ jsxs69(CommandGroup, { heading: "Workspace", children: [
        /* @__PURE__ */ jsx106(CommandItem, { value: "projects", onSelect, children: "Open projects" }),
        /* @__PURE__ */ jsx106(CommandItem, { value: "search", keywords: ["find"], onSelect, children: "Search files" }),
        /* @__PURE__ */ jsx106(CommandItem, { value: "archive", disabled: true, children: "Archive workspace" })
      ] }),
      /* @__PURE__ */ jsx106(CommandSeparator, {}),
      /* @__PURE__ */ jsx106(CommandGroup, { heading: "Account", children: /* @__PURE__ */ jsxs69(CommandItem, { value: "settings", onSelect, children: [
        "Settings",
        /* @__PURE__ */ jsx106(CommandShortcut, { children: "Ctrl+S" })
      ] }) })
    ] })
  ] });
}
function CommandPreview() {
  const [open, setOpen] = useState24(false);
  const [selected, setSelected] = useState24("No action yet");
  return /* @__PURE__ */ jsx106(PopupMotionScope, { children: /* @__PURE__ */ jsxs69("div", { className: "flex w-full max-w-sm flex-col gap-4", children: [
    /* @__PURE__ */ jsx106(Actions, { onSelect: setSelected }),
    /* @__PURE__ */ jsx106(Button, { variant: "outline", onClick: () => setOpen(true), children: "Open command palette" }),
    /* @__PURE__ */ jsx106("p", { role: "status", className: "text-sm text-muted-foreground", children: selected }),
    /* @__PURE__ */ jsx106(CommandDialog, { open, onOpenChange: setOpen, children: /* @__PURE__ */ jsx106(
      Actions,
      {
        onSelect: (value) => {
          setSelected(value);
          setOpen(false);
        }
      }
    ) })
  ] }) });
}

// components/site/previews/toast.tsx
import { useState as useState25 } from "react";

// registry/cadence/toast/index.tsx
import { Toast as ToastPrimitive } from "@base-ui/react/toast";
import { CircleCheckIcon, InfoIcon, Loader2Icon as Loader2Icon2, OctagonXIcon, TriangleAlertIcon as TriangleAlertIcon2, XIcon as XIcon3 } from "lucide-react";
import { jsx as jsx107, jsxs as jsxs70 } from "react/jsx-runtime";
var toast = ToastPrimitive.createToastManager();
function ToastProvider({ ...props }) {
  return /* @__PURE__ */ jsx107(ToastPrimitive.Provider, { ...props });
}
function ToastPortal({ ...props }) {
  return /* @__PURE__ */ jsx107(ToastPrimitive.Portal, { "data-slot": "toast-portal", ...props });
}
function ToastViewport({ className, ...props }) {
  return /* @__PURE__ */ jsx107(
    ToastPrimitive.Viewport,
    {
      "data-slot": "toast-viewport",
      className: stateClasses(
        cn(
          "pointer-events-none fixed inset-x-4 bottom-4 z-50 mx-auto w-auto max-w-sm outline-none sm:right-4 sm:left-auto sm:mx-0 sm:w-full"
        ),
        className
      ),
      ...props
    }
  );
}
function Toast({ className, style, ...props }) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx107(
    ToastPrimitive.Root,
    {
      "data-slot": "toast",
      "data-motion": cm.mode,
      style: popupStyle(cm, style),
      className: popupClasses(
        cm,
        cn(
          "group/toast pointer-events-auto absolute right-0 bottom-[calc(var(--toast-offset-y)+var(--toast-index)*0.75rem)] z-[calc(1000-var(--toast-index))] w-full origin-bottom rounded-lg border bg-popover text-popover-foreground shadow-lg outline-none select-none focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50",
          "transition-[opacity,scale,transform] duration-(--motion-duration-base) ease-cadence-out data-starting-style:opacity-0 data-ending-style:opacity-0 data-limited:pointer-events-none data-limited:opacity-0",
          !cm.reduced && "data-starting-style:scale-(--motion-scale-in) data-ending-style:scale-(--motion-scale-in) [transform:translate(var(--toast-swipe-movement-x),var(--toast-swipe-movement-y))]"
        ),
        className
      ),
      ...props
    }
  );
}
function ToastContent({ className, ...props }) {
  return /* @__PURE__ */ jsx107(
    ToastPrimitive.Content,
    {
      "data-slot": "toast-content",
      className: stateClasses(cn("flex h-full items-center gap-3 overflow-hidden p-4"), className),
      ...props
    }
  );
}
function ToastTitle({ className, ...props }) {
  return /* @__PURE__ */ jsx107(
    ToastPrimitive.Title,
    {
      "data-slot": "toast-title",
      className: stateClasses(cn("text-sm font-medium"), className),
      ...props
    }
  );
}
function ToastDescription({ className, ...props }) {
  return /* @__PURE__ */ jsx107(
    ToastPrimitive.Description,
    {
      "data-slot": "toast-description",
      className: stateClasses(cn("text-sm text-muted-foreground"), className),
      ...props
    }
  );
}
function ToastAction({
  className,
  render = /* @__PURE__ */ jsx107(Button, { variant: "outline", size: "sm" }),
  ...props
}) {
  return /* @__PURE__ */ jsx107(
    ToastPrimitive.Action,
    {
      "data-slot": "toast-action",
      render,
      className: stateClasses(cn("shrink-0"), className),
      ...props
    }
  );
}
function ToastClose({
  className,
  children,
  render = /* @__PURE__ */ jsx107(Button, { variant: "ghost", size: "icon-sm" }),
  ...props
}) {
  return /* @__PURE__ */ jsx107(
    ToastPrimitive.Close,
    {
      "data-slot": "toast-close",
      "aria-label": "Close toast",
      render,
      className: stateClasses(
        cn(
          "relative shrink-0 text-muted-foreground after:absolute after:-inset-2 after:content-[''] hover:text-foreground"
        ),
        className
      ),
      ...props,
      children: children ?? /* @__PURE__ */ jsx107(XIcon3, { "aria-hidden": "true" })
    }
  );
}
function ToastIcon({ type }) {
  let icon = null;
  if (type === "success") {
    icon = /* @__PURE__ */ jsx107(CircleCheckIcon, { "aria-hidden": "true" });
  }
  if (type === "info") {
    icon = /* @__PURE__ */ jsx107(InfoIcon, { "aria-hidden": "true" });
  }
  if (type === "warning") {
    icon = /* @__PURE__ */ jsx107(TriangleAlertIcon2, { "aria-hidden": "true" });
  }
  if (type === "error") {
    icon = /* @__PURE__ */ jsx107(OctagonXIcon, { className: "text-destructive", "aria-hidden": "true" });
  }
  if (type === "loading") {
    icon = /* @__PURE__ */ jsx107(Loader2Icon2, { "aria-hidden": "true" });
  }
  if (!icon) {
    return null;
  }
  return /* @__PURE__ */ jsx107("span", { "data-slot": "toast-icon", className: "shrink-0 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4", children: icon });
}
function ToastList() {
  const { toasts } = ToastPrimitive.useToastManager();
  return toasts.map((toastItem) => /* @__PURE__ */ jsx107(Toast, { toast: toastItem, children: /* @__PURE__ */ jsxs70(ToastContent, { children: [
    /* @__PURE__ */ jsx107(ToastIcon, { type: toastItem.type }),
    /* @__PURE__ */ jsxs70("div", { className: "flex min-w-0 flex-1 flex-col gap-1", children: [
      /* @__PURE__ */ jsx107(ToastTitle, {}),
      /* @__PURE__ */ jsx107(ToastDescription, {})
    ] }),
    /* @__PURE__ */ jsx107(ToastAction, {}),
    /* @__PURE__ */ jsx107(ToastClose, {})
  ] }) }, toastItem.id));
}
function Toaster({ children, toastManager = toast, ...props }) {
  return /* @__PURE__ */ jsxs70(ToastProvider, { toastManager, ...props, children: [
    children,
    /* @__PURE__ */ jsx107(ToastPortal, { children: /* @__PURE__ */ jsx107(ToastViewport, { children: /* @__PURE__ */ jsx107(ToastList, {}) }) })
  ] });
}
var createToastManager = ToastPrimitive.createToastManager;
var useToastManager = ToastPrimitive.useToastManager;

// components/site/previews/toast.tsx
import { jsx as jsx108, jsxs as jsxs71 } from "react/jsx-runtime";
var types = ["success", "info", "warning", "error", "loading"];
function ToastPreview() {
  const { control, choose } = usePreviewVariant("Toast", types);
  const [manager] = useState25(createToastManager);
  const [message, setMessage] = useState25("No action yet");
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsxs71(PopupMotionScope, { children: [
    control,
    /* @__PURE__ */ jsx108(Toaster, { toastManager: manager, timeout: 0, children: /* @__PURE__ */ jsxs71("div", { "data-slot": "toast-demo", "data-motion": cm.mode, className: "flex flex-col items-center gap-4", children: [
      /* @__PURE__ */ jsxs71("div", { className: "flex flex-wrap justify-center gap-2", children: [
        /* @__PURE__ */ jsx108(
          Button,
          {
            onClick: () => manager.add({
              title: "Changes saved",
              description: "Your workspace is up to date.",
              type: choose("success"),
              actionProps: { children: "Undo", onClick: () => setMessage("Changes undone") }
            }),
            children: "Show notification"
          }
        ),
        /* @__PURE__ */ jsx108(
          Button,
          {
            variant: "outline",
            onClick: () => manager.add({
              title: "Connection unavailable",
              description: "Try again when you are online.",
              type: choose("error"),
              priority: "high"
            }),
            children: "Show error"
          }
        ),
        /* @__PURE__ */ jsx108(Button, { variant: "ghost", onClick: () => manager.close(), children: "Dismiss all" })
      ] }),
      /* @__PURE__ */ jsx108("p", { role: "status", className: "text-sm text-muted-foreground", children: message })
    ] }) })
  ] });
}

// components/site/previews/accordion.tsx
import { useState as useState26 } from "react";

// registry/cadence/accordion/index.tsx
import { Accordion as AccordionPrimitive } from "@base-ui/react/accordion";
import { useRender as useRender5 } from "@base-ui/react/use-render";
import { ChevronDownIcon as ChevronDownIcon4, ChevronUpIcon as ChevronUpIcon2 } from "lucide-react";
import { useLayoutEffect as useLayoutEffect12, useRef as useRef14 } from "react";
import { jsx as jsx109, jsxs as jsxs72 } from "react/jsx-runtime";
function Accordion({ className, ...props }) {
  return /* @__PURE__ */ jsx109(
    AccordionPrimitive.Root,
    {
      "data-slot": "accordion",
      className: (state) => cn("flex w-full flex-col", typeof className === "function" ? className(state) : className),
      ...props
    }
  );
}
function AccordionItem({ className, ...props }) {
  return /* @__PURE__ */ jsx109(
    AccordionPrimitive.Item,
    {
      "data-slot": "accordion-item",
      className: (state) => cn("border-b last:border-b-0", typeof className === "function" ? className(state) : className),
      ...props
    }
  );
}
function AccordionTrigger({ className, children, ...props }) {
  return /* @__PURE__ */ jsx109(AccordionPrimitive.Header, { "data-slot": "accordion-header", className: "flex", children: /* @__PURE__ */ jsxs72(
    AccordionPrimitive.Trigger,
    {
      "data-slot": "accordion-trigger",
      className: (state) => cn(
        "group/accordion-trigger relative flex flex-1 items-start justify-between gap-4 rounded-md border border-transparent py-4 text-left text-sm font-medium outline-none hover:underline focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 disabled:pointer-events-none disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50",
        typeof className === "function" ? className(state) : className
      ),
      ...props,
      children: [
        children,
        /* @__PURE__ */ jsx109(
          ChevronDownIcon4,
          {
            "aria-hidden": "true",
            "data-slot": "accordion-trigger-icon",
            className: "pointer-events-none mt-0.5 size-4 shrink-0 text-muted-foreground group-aria-expanded/accordion-trigger:hidden"
          }
        ),
        /* @__PURE__ */ jsx109(
          ChevronUpIcon2,
          {
            "aria-hidden": "true",
            "data-slot": "accordion-trigger-icon",
            className: "pointer-events-none mt-0.5 hidden size-4 shrink-0 text-muted-foreground group-aria-expanded/accordion-trigger:inline"
          }
        )
      ]
    }
  ) });
}
function AccordionBody({ className, children }) {
  const ref = useRef14(null);
  useLayoutEffect12(() => {
    const content = ref.current;
    if (!content) return;
    const measure = () => {
      content.parentElement?.style.setProperty(
        "--cadence-disclosure-height",
        `${Math.max(0, content.getBoundingClientRect().height)}px`
      );
    };
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(content);
    return () => observer.disconnect();
  }, []);
  return /* @__PURE__ */ jsx109(
    "div",
    {
      ref,
      "data-slot": "accordion-content-inner",
      className: cn(
        "flow-root pt-0 pb-4 [&_a]:underline [&_a]:underline-offset-3 [&_a]:hover:text-foreground [&_p:not(:last-child)]:mb-4",
        className
      ),
      children
    }
  );
}
function AccordionSurface({
  elementProps,
  state,
  render
}) {
  return useRender5({
    defaultTagName: "div",
    render,
    props: { ...elementProps },
    state: { ...state },
    stateAttributesMapping: {
      open: () => null,
      disabled: () => null,
      transitionStatus: () => null,
      hidden: () => null,
      index: () => null,
      value: () => null,
      orientation: () => null
    }
  });
}
function AccordionContent({ className, children, render, style, ...props }) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx109(
    AccordionPrimitive.Panel,
    {
      "data-slot": "accordion-content",
      "data-motion": cm.mode,
      style: popupStyle(cm, style),
      className: cn(
        "h-[max(0px,var(--cadence-disclosure-height,var(--accordion-panel-height)))] overflow-hidden text-sm data-[ending-style]:h-0 data-[starting-style]:h-0",
        cm.reduced ? "transition-none duration-0" : "transition-[height] duration-(--motion-duration-slow) ease-cadence-out"
      ),
      render: (elementProps, state) => /* @__PURE__ */ jsx109(
        AccordionSurface,
        {
          elementProps: {
            ...elementProps,
            children: /* @__PURE__ */ jsx109(AccordionBody, { className: typeof className === "function" ? className(state) : className, children })
          },
          state,
          render
        }
      ),
      ...props
    }
  );
}

// components/site/previews/accordion.tsx
import { jsx as jsx110, jsxs as jsxs73 } from "react/jsx-runtime";
function AccordionPreview() {
  const [expanded, setExpanded] = useState26(false);
  return /* @__PURE__ */ jsxs73(Accordion, { className: "w-full max-w-lg", defaultValue: ["install"], children: [
    /* @__PURE__ */ jsxs73(AccordionItem, { value: "install", children: [
      /* @__PURE__ */ jsx110(AccordionTrigger, { children: "How do I install a component?" }),
      /* @__PURE__ */ jsx110(AccordionContent, { children: "Install from the Cadence registry. The source is copied into your project, ready to customise." })
    ] }),
    /* @__PURE__ */ jsxs73(AccordionItem, { value: "motion", children: [
      /* @__PURE__ */ jsx110(AccordionTrigger, { children: "Can I reduce the motion?" }),
      /* @__PURE__ */ jsxs73(AccordionContent, { children: [
        /* @__PURE__ */ jsx110("p", { children: "Yes. Your system preference is respected, and the provider can disable motion entirely." }),
        /* @__PURE__ */ jsx110(Button, { variant: "outline", size: "sm", onClick: () => setExpanded(!expanded), children: "Toggle details" }),
        expanded && /* @__PURE__ */ jsx110("p", { className: "mt-4", children: "Disclosure heights update instantly in reduced and none modes. Full mode follows the measured content height and can reverse while moving." })
      ] })
    ] }),
    /* @__PURE__ */ jsxs73(AccordionItem, { value: "disabled", disabled: true, children: [
      /* @__PURE__ */ jsx110(AccordionTrigger, { children: "Upcoming integrations" }),
      /* @__PURE__ */ jsx110(AccordionContent, { children: "Not available yet." })
    ] })
  ] });
}

// components/site/previews/collapsible.tsx
import { useState as useState27 } from "react";

// registry/cadence/collapsible/index.tsx
import { Collapsible as CollapsiblePrimitive } from "@base-ui/react/collapsible";
import { useLayoutEffect as useLayoutEffect13, useRef as useRef15 } from "react";
import { jsx as jsx111 } from "react/jsx-runtime";
function Collapsible({ ...props }) {
  return /* @__PURE__ */ jsx111(CollapsiblePrimitive.Root, { "data-slot": "collapsible", ...props });
}
function CollapsibleTrigger({ ...props }) {
  return /* @__PURE__ */ jsx111(CollapsiblePrimitive.Trigger, { "data-slot": "collapsible-trigger", ...props });
}
function CollapsibleBody({ children }) {
  const ref = useRef15(null);
  useLayoutEffect13(() => {
    const content = ref.current;
    if (!content) return;
    const panel = content.parentElement;
    const view = content.ownerDocument.defaultView;
    if (!panel || !view) return;
    const measure = () => {
      const style = view.getComputedStyle(panel);
      const edges = style.boxSizing === "border-box" ? [style.paddingTop, style.paddingBottom, style.borderTopWidth, style.borderBottomWidth].reduce(
        (sum, value) => sum + (Number.parseFloat(value) || 0),
        0
      ) : 0;
      const height = `${Math.max(0, content.getBoundingClientRect().height + edges)}px`;
      if (panel.style.getPropertyValue("--cadence-disclosure-height") !== height)
        panel.style.setProperty("--cadence-disclosure-height", height);
    };
    measure();
    const observer = new ResizeObserver(measure);
    observer.observe(content, { box: "border-box" });
    const attributes = new MutationObserver(measure);
    attributes.observe(panel, { attributes: true, attributeFilter: ["class", "style"] });
    view.addEventListener("resize", measure);
    return () => {
      observer.disconnect();
      attributes.disconnect();
      view.removeEventListener("resize", measure);
    };
  }, []);
  return /* @__PURE__ */ jsx111("div", { ref, "data-slot": "collapsible-content-inner", className: "flow-root", children });
}
function CollapsibleContent({ className, children, style, ...props }) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx111(
    CollapsiblePrimitive.Panel,
    {
      "data-slot": "collapsible-content",
      "data-motion": cm.mode,
      style: popupStyle(cm, style),
      className: (state) => cn(
        "h-[max(0px,var(--cadence-disclosure-height,var(--collapsible-panel-height)))] overflow-hidden data-[ending-style]:h-0 data-[starting-style]:h-0",
        cm.reduced ? "transition-none duration-0" : "transition-[height] duration-(--motion-duration-slow) ease-cadence-out",
        typeof className === "function" ? className(state) : className
      ),
      ...props,
      children: /* @__PURE__ */ jsx111(CollapsibleBody, { children })
    }
  );
}

// components/site/previews/collapsible.tsx
import { jsx as jsx112, jsxs as jsxs74 } from "react/jsx-runtime";
function CollapsiblePreview() {
  const [open, setOpen] = useState27(true);
  const [details, setDetails] = useState27(false);
  return /* @__PURE__ */ jsxs74(Collapsible, { open, onOpenChange: setOpen, className: "w-full max-w-lg", children: [
    /* @__PURE__ */ jsxs74("div", { className: "flex items-center justify-between gap-4", children: [
      /* @__PURE__ */ jsx112("h3", { className: "text-sm font-semibold", children: "Project details" }),
      /* @__PURE__ */ jsx112(CollapsibleTrigger, { render: /* @__PURE__ */ jsx112(Button, { variant: "outline", size: "sm" }), children: open ? "Hide details" : "Show details" })
    ] }),
    /* @__PURE__ */ jsx112(CollapsibleContent, { className: "mt-4 rounded-lg border p-4 text-sm", children: /* @__PURE__ */ jsxs74("div", { children: [
      /* @__PURE__ */ jsx112("p", { className: "mb-4", children: "Components are copied into your project so you can make them your own." }),
      /* @__PURE__ */ jsx112(Button, { variant: "outline", size: "sm", onClick: () => setDetails(!details), children: "Toggle extra detail" }),
      details && /* @__PURE__ */ jsx112("p", { className: "mt-4", children: "The disclosure follows content changes and responsive wrapping. Reduced and none modes update its height instantly." })
    ] }) })
  ] });
}

// components/site/previews/tabs.tsx
import { useState as useState28 } from "react";

// registry/cadence/tabs/index.tsx
import { Tabs as TabsPrimitive } from "@base-ui/react/tabs";
import { useRender as useRender6 } from "@base-ui/react/use-render";
import { cva as cva11 } from "class-variance-authority";
import { LayoutGroup, motion as motion8 } from "motion/react";
import { useId as useId4 } from "react";
import { Fragment as Fragment31, jsx as jsx113, jsxs as jsxs75 } from "react/jsx-runtime";
function Tabs({ className, orientation = "horizontal", ...props }) {
  return /* @__PURE__ */ jsx113(
    TabsPrimitive.Root,
    {
      "data-slot": "tabs",
      "data-orientation": orientation,
      orientation,
      className: (state) => cn(
        "group/tabs flex gap-2 data-[orientation=horizontal]:flex-col",
        typeof className === "function" ? className(state) : className
      ),
      ...props
    }
  );
}
var tabsListVariants = cva11(
  "group/tabs-list inline-flex w-fit items-center justify-center rounded-lg p-[3px] text-muted-foreground group-data-[orientation=horizontal]/tabs:h-9 group-data-[orientation=vertical]/tabs:h-fit group-data-[orientation=vertical]/tabs:flex-col data-[variant=line]:rounded-none",
  {
    variants: { variant: { default: "bg-muted", line: "gap-1 bg-transparent" } },
    defaultVariants: { variant: "default" }
  }
);
function TabsList({
  className,
  variant = "default",
  ...props
}) {
  const id = useId4();
  return /* @__PURE__ */ jsx113(LayoutGroup, { id, children: /* @__PURE__ */ jsx113(
    TabsPrimitive.List,
    {
      "data-slot": "tabs-list",
      "data-variant": variant,
      className: (state) => cn(tabsListVariants({ variant }), typeof className === "function" ? className(state) : className),
      ...props
    }
  ) });
}
function TriggerSurface({
  elementProps,
  state,
  render
}) {
  const cm = useCadenceMotion();
  const indicatorClass = "pointer-events-none absolute inset-0 -z-10 rounded-md bg-background shadow-sm dark:bg-input/30 group-data-[variant=line]/tabs-list:rounded-none group-data-[variant=line]/tabs-list:bg-foreground group-data-[variant=line]/tabs-list:shadow-none group-data-[variant=line]/tabs-list:inset-auto group-data-[variant=line]/tabs-list:bottom-[-5px] group-data-[variant=line]/tabs-list:inset-x-0 group-data-[variant=line]/tabs-list:h-0.5 group-data-[orientation=vertical]/tabs:group-data-[variant=line]/tabs-list:inset-y-0 group-data-[orientation=vertical]/tabs:group-data-[variant=line]/tabs-list:left-auto group-data-[orientation=vertical]/tabs:group-data-[variant=line]/tabs-list:-right-1 group-data-[orientation=vertical]/tabs:group-data-[variant=line]/tabs-list:h-auto group-data-[orientation=vertical]/tabs:group-data-[variant=line]/tabs-list:w-0.5";
  return useRender6({
    defaultTagName: "button",
    render,
    state: { ...state },
    stateAttributesMapping: {
      active: () => null,
      disabled: () => null,
      orientation: () => null,
      tabActivationDirection: () => null
    },
    props: {
      ...elementProps,
      children: /* @__PURE__ */ jsxs75(Fragment31, { children: [
        state.active && (cm.reduced || cm.timeScale === 0 ? /* @__PURE__ */ jsx113("span", { "aria-hidden": "true", "data-slot": "tabs-indicator", "data-motion": cm.mode, className: indicatorClass }) : /* @__PURE__ */ jsx113(
          motion8.span,
          {
            "aria-hidden": "true",
            "data-slot": "tabs-indicator",
            "data-motion": cm.mode,
            className: indicatorClass,
            layoutId: "selection",
            initial: false,
            transition: cm.transition("layout.shared")
          }
        )),
        elementProps.children
      ] })
    }
  });
}
function TabsTrigger({ className, render, ...props }) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx113(
    TabsPrimitive.Tab,
    {
      "data-slot": "tabs-trigger",
      "data-motion": cm.mode,
      className: (state) => cn(
        "relative isolate inline-flex h-[calc(100%-1px)] flex-1 items-center justify-center gap-1.5 rounded-md border border-transparent px-2 py-1 text-sm font-medium whitespace-nowrap text-muted-foreground transition-colors group-data-[orientation=vertical]/tabs:w-full group-data-[orientation=vertical]/tabs:justify-start hover:text-foreground focus-visible:border-ring focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:outline-1 focus-visible:outline-ring disabled:pointer-events-none disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50 data-active:text-foreground [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4",
        typeof className === "function" ? className(state) : className
      ),
      render: (elementProps, state) => /* @__PURE__ */ jsx113(TriggerSurface, { elementProps, state, render }),
      ...props
    }
  );
}
function TabsContent({ className, ...props }) {
  return /* @__PURE__ */ jsx113(
    TabsPrimitive.Panel,
    {
      "data-slot": "tabs-content",
      className: (state) => cn("flex-1 outline-none", typeof className === "function" ? className(state) : className),
      ...props
    }
  );
}

// components/site/previews/tabs.tsx
import { Fragment as Fragment32, jsx as jsx114, jsxs as jsxs76 } from "react/jsx-runtime";
var previewVariantOptions26 = ["default", "line"];
function TabsPreview() {
  const { control, choose } = usePreviewVariant("Tabs", previewVariantOptions26);
  const [vertical, setVertical] = useState28(false);
  const [wide, setWide] = useState28(false);
  const [value, setValue] = useState28("overview");
  return /* @__PURE__ */ jsxs76(Fragment32, { children: [
    control,
    /* @__PURE__ */ jsxs76("div", { className: "flex w-full max-w-md flex-col gap-6", children: [
      /* @__PURE__ */ jsxs76("div", { className: "flex flex-wrap gap-2", children: [
        /* @__PURE__ */ jsx114(Button, { variant: "outline", size: "sm", onClick: () => setVertical(!vertical), children: "Toggle orientation" }),
        /* @__PURE__ */ jsx114(Button, { variant: "outline", size: "sm", onClick: () => setWide(!wide), children: "Resize list" }),
        /* @__PURE__ */ jsx114(Button, { variant: "outline", size: "sm", onClick: () => setValue(value === "overview" ? "activity" : "overview"), children: "Change selection" })
      ] }),
      /* @__PURE__ */ jsxs76(Tabs, { value, onValueChange: setValue, orientation: vertical ? "vertical" : "horizontal", children: [
        /* @__PURE__ */ jsxs76(TabsList, { "aria-label": "Project views", className: wide ? "w-full" : void 0, variant: choose("default"), children: [
          /* @__PURE__ */ jsx114(TabsTrigger, { value: "overview", render: /* @__PURE__ */ jsx114("button", { type: "button" }), children: "Overview" }),
          /* @__PURE__ */ jsx114(TabsTrigger, { value: "activity", children: "Activity" }),
          /* @__PURE__ */ jsx114(TabsTrigger, { value: "locked", disabled: true, children: "Locked" })
        ] }),
        /* @__PURE__ */ jsx114(TabsContent, { value: "overview", className: "rounded-lg border p-4 text-sm", children: "Project overview. Peer views share one selection indicator." }),
        /* @__PURE__ */ jsx114(TabsContent, { value: "activity", className: "rounded-lg border p-4 text-sm", children: "Recent activity. Selection is controlled by the example." })
      ] }),
      /* @__PURE__ */ jsxs76(Tabs, { defaultValue: "account", orientation: vertical ? "vertical" : "horizontal", children: [
        /* @__PURE__ */ jsxs76(TabsList, { variant: choose("line"), "aria-label": "Settings views", activateOnFocus: true, children: [
          /* @__PURE__ */ jsx114(TabsTrigger, { value: "account", children: "Account" }),
          /* @__PURE__ */ jsx114(TabsTrigger, { value: "notifications", children: "Notifications" })
        ] }),
        /* @__PURE__ */ jsx114(TabsContent, { value: "account", className: "p-4 text-sm", children: "Account settings" }),
        /* @__PURE__ */ jsx114(TabsContent, { value: "notifications", className: "p-4 text-sm", keepMounted: true, children: "Notification preferences" })
      ] })
    ] })
  ] });
}

// registry/cadence/table/index.tsx
import { jsx as jsx115 } from "react/jsx-runtime";
function Table({ className, ...props }) {
  return /* @__PURE__ */ jsx115("div", { "data-slot": "table-container", className: "relative w-full overflow-x-auto", children: /* @__PURE__ */ jsx115("table", { "data-slot": "table", className: cn("w-full caption-bottom text-sm", className), ...props }) });
}
function TableHeader({ className, ...props }) {
  return /* @__PURE__ */ jsx115("thead", { "data-slot": "table-header", className: cn("[&_tr]:border-b", className), ...props });
}
function TableBody({ className, ...props }) {
  return /* @__PURE__ */ jsx115("tbody", { "data-slot": "table-body", className: cn("[&_tr:last-child]:border-0", className), ...props });
}
function TableFooter({ className, ...props }) {
  return /* @__PURE__ */ jsx115(
    "tfoot",
    {
      "data-slot": "table-footer",
      className: cn("border-t bg-muted/50 font-medium [&>tr]:last:border-b-0", className),
      ...props
    }
  );
}
function TableRow({ className, ...props }) {
  return /* @__PURE__ */ jsx115(
    "tr",
    {
      "data-slot": "table-row",
      className: cn(
        "border-b transition-colors hover:bg-muted/50 has-aria-expanded:bg-muted/50 data-[state=selected]:bg-muted",
        className
      ),
      ...props
    }
  );
}
function TableHead({ className, ...props }) {
  return /* @__PURE__ */ jsx115(
    "th",
    {
      "data-slot": "table-head",
      className: cn(
        "h-10 px-2 text-left align-middle font-medium whitespace-nowrap text-foreground [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]",
        className
      ),
      ...props
    }
  );
}
function TableCell({ className, ...props }) {
  return /* @__PURE__ */ jsx115(
    "td",
    {
      "data-slot": "table-cell",
      className: cn(
        "p-2 align-middle whitespace-nowrap [&:has([role=checkbox])]:pr-0 [&>[role=checkbox]]:translate-y-[2px]",
        className
      ),
      ...props
    }
  );
}
function TableCaption({ className, ...props }) {
  return /* @__PURE__ */ jsx115("caption", { "data-slot": "table-caption", className: cn("mt-4 text-sm text-muted-foreground", className), ...props });
}

// components/site/previews/table.tsx
import { jsx as jsx116, jsxs as jsxs77 } from "react/jsx-runtime";
var invoices = [
  { id: "INV-001", status: "Paid", method: "Credit card", amount: "$250.00" },
  { id: "INV-002", status: "Pending", method: "Bank transfer", amount: "$150.00" },
  { id: "INV-003", status: "Unpaid", method: "PayPal", amount: "$350.00" }
];
function TablePreview() {
  return /* @__PURE__ */ jsx116(PreviewStack, { className: "min-w-0", children: /* @__PURE__ */ jsx116("div", { className: "w-full min-w-0 max-w-xl", children: /* @__PURE__ */ jsxs77(
    Table,
    {
      tabIndex: 0,
      className: "focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-ring",
      children: [
        /* @__PURE__ */ jsx116(TableCaption, { children: "Recent invoices for November." }),
        /* @__PURE__ */ jsx116(TableHeader, { children: /* @__PURE__ */ jsxs77(TableRow, { children: [
          /* @__PURE__ */ jsx116(TableHead, { scope: "col", children: "Invoice" }),
          /* @__PURE__ */ jsx116(TableHead, { scope: "col", children: "Status" }),
          /* @__PURE__ */ jsx116(TableHead, { scope: "col", children: "Payment method" }),
          /* @__PURE__ */ jsx116(TableHead, { scope: "col", className: "text-right", children: "Amount" })
        ] }) }),
        /* @__PURE__ */ jsx116(TableBody, { children: invoices.map((invoice) => /* @__PURE__ */ jsxs77(TableRow, { children: [
          /* @__PURE__ */ jsx116(TableCell, { className: "font-medium", children: invoice.id }),
          /* @__PURE__ */ jsx116(TableCell, { children: invoice.status }),
          /* @__PURE__ */ jsx116(TableCell, { children: invoice.method }),
          /* @__PURE__ */ jsx116(TableCell, { className: "text-right tabular-nums", children: invoice.amount })
        ] }, invoice.id)) }),
        /* @__PURE__ */ jsx116(TableFooter, { children: /* @__PURE__ */ jsxs77(TableRow, { children: [
          /* @__PURE__ */ jsx116(TableCell, { colSpan: 3, children: "Total" }),
          /* @__PURE__ */ jsx116(TableCell, { className: "text-right tabular-nums", children: "$750.00" })
        ] }) })
      ]
    }
  ) }) });
}

// components/site/previews/carousel.tsx
import { useEffect as useEffect17, useMemo as useMemo3, useState as useState30 } from "react";

// registry/cadence/carousel/index.tsx
import useEmblaCarousel from "embla-carousel-react";
import { ArrowLeft, ArrowRight } from "lucide-react";
import * as React5 from "react";
import { jsx as jsx117, jsxs as jsxs78 } from "react/jsx-runtime";
var CarouselContext = React5.createContext(null);
function useCarousel() {
  const context = React5.useContext(CarouselContext);
  if (!context) {
    throw new Error("useCarousel must be used within a <Carousel />");
  }
  return context;
}
function Carousel({
  orientation = "horizontal",
  opts,
  setApi,
  plugins,
  className,
  children,
  ...props
}) {
  const cm = useCadenceMotion();
  const mode = React5.useRef(cm.reduced);
  mode.current = cm.reduced;
  const policy = React5.useMemo(() => {
    let cleanup = () => {
    };
    return {
      name: "cadenceMotion",
      options: {},
      init(embla) {
        const engine = embla.internalEngine();
        const body = engine.scrollBody;
        const original = body.useDuration;
        body.useDuration = (value) => original(mode.current ? 0 : value);
        const release = () => {
          body.useDuration(engine.options.duration);
        };
        embla.on("pointerUp", release);
        cleanup = () => {
          body.useDuration = original;
          embla.off("pointerUp", release);
        };
      },
      destroy() {
        cleanup();
      }
    };
  }, []);
  const authored = cm.transition("data.transition");
  const clock2 = (cm.reduced ? duration.base * cm.timeScale : Number(authored.duration)) * carouselClock.unitsPerSecond;
  const [carouselRef, api] = useEmblaCarousel(
    {
      duration: clock2,
      ...opts,
      axis: orientation === "horizontal" ? "x" : "y"
    },
    [policy, ...plugins ?? []]
  );
  React5.useLayoutEffect(() => {
    if (!api || !cm.reduced && clock2 !== 0) return;
    const engine = api.internalEngine();
    engine.scrollBody.useDuration(0);
    engine.animation.update();
    engine.animation.render(1);
    engine.animation.update();
  }, [api, cm.reduced, clock2]);
  const [canScrollPrev, setCanScrollPrev] = React5.useState(false);
  const [canScrollNext, setCanScrollNext] = React5.useState(false);
  const onSelect = React5.useCallback((api2) => {
    if (!api2) return;
    setCanScrollPrev(api2.canScrollPrev());
    setCanScrollNext(api2.canScrollNext());
  }, []);
  const scrollPrev = React5.useCallback(() => {
    api?.scrollPrev();
  }, [api]);
  const scrollNext = React5.useCallback(() => {
    api?.scrollNext();
  }, [api]);
  const handleKeyDown = React5.useCallback(
    (event) => {
      if (event.key === "ArrowLeft") {
        event.preventDefault();
        scrollPrev();
      } else if (event.key === "ArrowRight") {
        event.preventDefault();
        scrollNext();
      }
    },
    [scrollPrev, scrollNext]
  );
  React5.useEffect(() => {
    if (!api || !setApi) return;
    setApi(api);
  }, [api, setApi]);
  React5.useEffect(() => {
    if (!api) return;
    onSelect(api);
    api.on("reInit", onSelect);
    api.on("select", onSelect);
    return () => {
      api.off("reInit", onSelect);
      api.off("select", onSelect);
    };
  }, [api, onSelect]);
  return /* @__PURE__ */ jsx117(
    CarouselContext.Provider,
    {
      value: {
        carouselRef,
        api,
        opts,
        orientation: orientation || (opts?.axis === "y" ? "vertical" : "horizontal"),
        scrollPrev,
        scrollNext,
        canScrollPrev,
        canScrollNext
      },
      children: /* @__PURE__ */ jsx117(
        "div",
        {
          "data-motion": cm.mode,
          onKeyDownCapture: handleKeyDown,
          className: cn("relative", className),
          role: "region",
          "aria-roledescription": "carousel",
          "data-slot": "carousel",
          ...props,
          children
        }
      )
    }
  );
}
function CarouselContent({ className, ...props }) {
  const { carouselRef, orientation } = useCarousel();
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx117("div", { ref: carouselRef, className: "overflow-hidden", "data-slot": "carousel-content", "data-motion": cm.mode, children: /* @__PURE__ */ jsx117(
    "div",
    {
      "data-motion": cm.mode,
      className: cn("flex", orientation === "horizontal" ? "-ml-4" : "-mt-4 flex-col", className),
      ...props
    }
  ) });
}
function CarouselItem({ className, ...props }) {
  const { orientation } = useCarousel();
  return (
    // biome-ignore lint/a11y/useSemanticElements: Upstream slide is a div, not a fieldset.
    /* @__PURE__ */ jsx117(
      "div",
      {
        role: "group",
        "aria-roledescription": "slide",
        "data-slot": "carousel-item",
        className: cn("min-w-0 shrink-0 grow-0 basis-full", orientation === "horizontal" ? "pl-4" : "pt-4", className),
        ...props
      }
    )
  );
}
function CarouselPrevious({
  className,
  variant = "outline",
  size = "icon-sm",
  ...props
}) {
  const { orientation, scrollPrev, canScrollPrev } = useCarousel();
  return /* @__PURE__ */ jsxs78(
    Button,
    {
      "data-slot": "carousel-previous",
      variant,
      size,
      className: (state) => cn(
        "absolute size-8 rounded-full",
        orientation === "horizontal" ? "top-1/2 -left-12 -translate-y-1/2" : "-top-12 left-1/2 -translate-x-1/2 rotate-90",
        typeof className === "function" ? className(state) : className
      ),
      disabled: !canScrollPrev,
      onClick: scrollPrev,
      ...props,
      children: [
        /* @__PURE__ */ jsx117(ArrowLeft, {}),
        /* @__PURE__ */ jsx117("span", { className: "sr-only", children: "Previous slide" })
      ]
    }
  );
}
function CarouselNext({
  className,
  variant = "outline",
  size = "icon-sm",
  ...props
}) {
  const { orientation, scrollNext, canScrollNext } = useCarousel();
  return /* @__PURE__ */ jsxs78(
    Button,
    {
      "data-slot": "carousel-next",
      variant,
      size,
      className: (state) => cn(
        "absolute size-8 rounded-full",
        orientation === "horizontal" ? "top-1/2 -right-12 -translate-y-1/2" : "-bottom-12 left-1/2 -translate-x-1/2 rotate-90",
        typeof className === "function" ? className(state) : className
      ),
      disabled: !canScrollNext,
      onClick: scrollNext,
      ...props,
      children: [
        /* @__PURE__ */ jsx117(ArrowRight, {}),
        /* @__PURE__ */ jsx117("span", { className: "sr-only", children: "Next slide" })
      ]
    }
  );
}

// components/site/previews/carousel.tsx
import { Fragment as Fragment33, jsx as jsx118, jsxs as jsxs79 } from "react/jsx-runtime";
var previewVariantOptions27 = ["horizontal", "vertical"];
function CarouselPreview() {
  const { control, choose, select: selectPreviewVariant } = usePreviewVariant("Carousel", previewVariantOptions27);
  const [api, setApi] = useState30();
  const [current, setCurrent] = useState30(1);
  const [vertical, setVertical] = useState30(false);
  const [rtl, setRtl] = useState30(false);
  const [free, setFree] = useState30(false);
  const [drag, setDrag] = useState30(true);
  const [loop, setLoop] = useState30(false);
  const [narrow, setNarrow] = useState30(false);
  const [count, setCount] = useState30(4);
  const [pluginReady, setPluginReady] = useState30(false);
  const plugins = useMemo3(
    () => [
      {
        name: "exampleStatus",
        options: {},
        init() {
          setPluginReady(true);
        },
        destroy() {
          setPluginReady(false);
        }
      }
    ],
    []
  );
  useEffect17(() => {
    if (!api) return;
    const update = () => setCurrent(api.selectedScrollSnap() + 1);
    update();
    api.on("select", update).on("reInit", update);
    return () => {
      api.off("select", update).off("reInit", update);
    };
  }, [api]);
  return /* @__PURE__ */ jsxs79(Fragment33, { children: [
    control,
    /* @__PURE__ */ jsxs79("div", { className: "flex min-w-0 w-full max-w-lg flex-col items-center gap-5", children: [
      /* @__PURE__ */ jsxs79("div", { className: "flex flex-wrap justify-center gap-2", children: [
        /* @__PURE__ */ jsx118(
          Button,
          {
            size: "sm",
            variant: "outline",
            onClick: () => {
              selectPreviewVariant("all");
              setVertical(!vertical);
            },
            children: "Toggle orientation"
          }
        ),
        /* @__PURE__ */ jsx118(Button, { size: "sm", variant: "outline", onClick: () => setLoop(!loop), children: "Toggle loop" }),
        /* @__PURE__ */ jsx118(Button, { size: "sm", variant: "outline", onClick: () => setNarrow(!narrow), children: "Resize track" }),
        /* @__PURE__ */ jsx118(Button, { size: "sm", variant: "outline", onClick: () => setCount(count === 4 ? 5 : 4), children: "Change slides" }),
        /* @__PURE__ */ jsx118(Button, { size: "sm", variant: "outline", onClick: () => api?.scrollTo(count - 1, false), children: "Go to last slide" })
      ] }),
      /* @__PURE__ */ jsxs79("div", { className: "flex flex-wrap justify-center gap-2", children: [
        /* @__PURE__ */ jsx118(Button, { size: "sm", variant: "outline", onClick: () => setRtl(!rtl), children: "Toggle RTL" }),
        /* @__PURE__ */ jsx118(Button, { size: "sm", variant: "outline", onClick: () => setFree(!free), children: "Toggle free drag" }),
        /* @__PURE__ */ jsx118(Button, { size: "sm", variant: "outline", onClick: () => setDrag(!drag), children: "Toggle dragging" })
      ] }),
      /* @__PURE__ */ jsx118("div", { className: "w-full px-12 py-12", children: /* @__PURE__ */ jsxs79(
        Carousel,
        {
          "aria-label": "Project highlights",
          tabIndex: 0,
          setApi,
          plugins,
          orientation: choose(vertical ? "vertical" : "horizontal"),
          dir: rtl ? "rtl" : "ltr",
          opts: {
            loop,
            align: "start",
            direction: rtl ? "rtl" : "ltr",
            dragFree: free,
            watchDrag: drag,
            breakpoints: { "(max-width: 480px)": { duration: 37 } }
          },
          className: narrow ? "mx-auto w-3/4 outline-none focus-visible:ring-2 focus-visible:ring-ring" : "w-full outline-none focus-visible:ring-2 focus-visible:ring-ring",
          children: [
            /* @__PURE__ */ jsx118(
              CarouselContent,
              {
                className: choose(vertical ? "vertical" : "horizontal") === "vertical" ? "h-48 touch-pan-x" : "touch-pan-y",
                children: [1, 2, 3, 4, 5].slice(0, count).map((slide) => /* @__PURE__ */ jsx118(CarouselItem, { "aria-label": `${slide} of ${count}`, children: /* @__PURE__ */ jsx118("div", { className: "flex h-44 items-center justify-center rounded-xl border bg-muted text-4xl font-semibold", children: slide }) }, slide))
              }
            ),
            /* @__PURE__ */ jsx118(CarouselPrevious, {}),
            /* @__PURE__ */ jsx118(CarouselNext, {})
          ]
        }
      ) }),
      /* @__PURE__ */ jsxs79("p", { "aria-live": "polite", className: "text-sm text-muted-foreground", children: [
        "Slide ",
        current,
        " of ",
        count,
        pluginReady ? " \xB7 Ready" : ""
      ] })
    ] })
  ] });
}

// registry/cadence/scroll-area/index.tsx
import { ScrollArea as ScrollAreaPrimitive } from "@base-ui/react/scroll-area";
import { jsx as jsx119, jsxs as jsxs80 } from "react/jsx-runtime";
function ScrollArea({ className, children, ...props }) {
  return /* @__PURE__ */ jsxs80(
    ScrollAreaPrimitive.Root,
    {
      "data-slot": "scroll-area",
      className: (state) => cn("relative", typeof className === "function" ? className(state) : className),
      ...props,
      children: [
        /* @__PURE__ */ jsx119(
          ScrollAreaPrimitive.Viewport,
          {
            "data-slot": "scroll-area-viewport",
            className: "size-full rounded-[inherit] transition-[color,box-shadow] outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50 focus-visible:outline-1",
            children
          }
        ),
        /* @__PURE__ */ jsx119(ScrollBar, {}),
        /* @__PURE__ */ jsx119(ScrollAreaPrimitive.Corner, {})
      ]
    }
  );
}
function ScrollBar({ className, orientation = "vertical", ...props }) {
  return /* @__PURE__ */ jsx119(
    ScrollAreaPrimitive.Scrollbar,
    {
      "data-slot": "scroll-area-scrollbar",
      "data-orientation": orientation,
      orientation,
      className: (state) => cn(
        "flex touch-none p-px transition-colors select-none",
        orientation === "vertical" && "h-full w-2.5 border-l border-l-transparent",
        orientation === "horizontal" && "h-2.5 flex-col border-t border-t-transparent",
        typeof className === "function" ? className(state) : className
      ),
      ...props,
      children: /* @__PURE__ */ jsx119(ScrollAreaPrimitive.Thumb, { "data-slot": "scroll-area-thumb", className: "relative flex-1 rounded-full bg-border" })
    }
  );
}

// components/site/previews/scroll-area.tsx
import { Fragment as Fragment34, jsx as jsx120, jsxs as jsxs81 } from "react/jsx-runtime";
var options = ["vertical", "horizontal"];
function ScrollAreaPreview() {
  const { variant, control } = usePreviewVariant("ScrollArea", options);
  return /* @__PURE__ */ jsxs81(Fragment34, { children: [
    control,
    /* @__PURE__ */ jsxs81("div", { className: "grid min-w-0 gap-6", children: [
      /* @__PURE__ */ jsxs81("div", { className: "min-w-0", hidden: variant === "horizontal", children: [
        /* @__PURE__ */ jsx120("h3", { className: "mb-2 text-sm font-medium", children: "Release notes" }),
        /* @__PURE__ */ jsx120(ScrollArea, { "aria-label": "Release notes", className: "h-48 w-full rounded-md border", children: /* @__PURE__ */ jsx120("ul", { className: "flex flex-col gap-3 p-4 pr-6 text-sm", children: Array.from({ length: 20 }, (_, i) => /* @__PURE__ */ jsxs81("li", { children: [
          "Release ",
          20 - i,
          ": improved keyboard navigation and component parity."
        ] }, i.toString())) }) })
      ] }),
      /* @__PURE__ */ jsxs81("div", { className: "min-w-0", hidden: variant === "vertical", children: [
        /* @__PURE__ */ jsx120("h3", { className: "mb-2 text-sm font-medium", children: "Project timeline" }),
        /* @__PURE__ */ jsxs81(ScrollArea, { "aria-label": "Project timeline", className: "w-full rounded-md border", children: [
          /* @__PURE__ */ jsx120("div", { className: "flex w-max gap-4 p-4 pb-6", children: ["Research", "Design", "Build", "Review", "Ship", "Learn"].map((label2) => /* @__PURE__ */ jsx120("div", { className: "flex h-24 w-40 items-center justify-center rounded-md bg-muted text-sm", children: label2 }, label2)) }),
          /* @__PURE__ */ jsx120(ScrollBar, { orientation: "horizontal" })
        ] })
      ] })
    ] })
  ] });
}

// components/site/previews/chart.tsx
import { useState as useState31 } from "react";
import { Area as Area2, AreaChart, Bar as Bar2, BarChart, CartesianGrid, Line as Line2, LineChart, Pie as Pie2, PieChart, XAxis } from "recharts";

// registry/cadence/chart/index.tsx
import { cubicBezier } from "motion/react";
import * as React6 from "react";
import * as RechartsPrimitive from "recharts";
import { Fragment as Fragment35, jsx as jsx121, jsxs as jsxs82 } from "react/jsx-runtime";
var THEMES = { light: "", dark: ".dark" };
var INITIAL_DIMENSION = { width: 320, height: 200 };
var ChartContext = React6.createContext(null);
function useChart() {
  const context = React6.useContext(ChartContext);
  if (!context) {
    throw new Error("useChart must be used within a <ChartContainer />");
  }
  return context;
}
var animatedSeries = /* @__PURE__ */ new Set([
  RechartsPrimitive.Bar,
  RechartsPrimitive.Line,
  RechartsPrimitive.Area,
  RechartsPrimitive.Pie,
  RechartsPrimitive.Scatter,
  RechartsPrimitive.Radar,
  RechartsPrimitive.RadialBar,
  RechartsPrimitive.Funnel
]);
function terminalItems(items) {
  return items?.flatMap((item) => item.status === "removed" ? [] : [item.next]) ?? [];
}
function chartSeries(element, instant) {
  if (element.type === RechartsPrimitive.AnimationControllerProvider) return element;
  const child = element;
  const authored = child.props.animationInterpolateFn;
  const terminal = authored ? (items, _progress, layout) => authored(items, 1, layout) : terminalItems;
  return React6.cloneElement(child, {
    ...animatedSeries.has(child.type) && instant ? { animationInterpolateFn: terminal } : {},
    ...child.props.children !== void 0 && typeof child.props.children !== "function" ? {
      children: React6.Children.map(
        child.props.children,
        (nested) => React6.isValidElement(nested) ? chartSeries(nested, instant) : nested
      )
    } : {}
  });
}
function ChartContainer({
  id,
  className,
  children,
  config: config2,
  initialDimension = INITIAL_DIMENSION,
  ...props
}) {
  const cm = useCadenceMotion();
  const clock2 = cm.transition("data.transition");
  const current = React6.useRef({ reduced: cm.reduced, duration: clock2.duration ?? 0 });
  const running = React6.useRef(/* @__PURE__ */ new Set());
  React6.useLayoutEffect(() => {
    current.current = { reduced: cm.reduced, duration: clock2.duration ?? 0 };
    if (cm.reduced || clock2.duration === 0) for (const finish of running.current) finish();
  }, [cm.reduced, clock2.duration]);
  const controller = React6.useCallback((_timeout, handle, listener) => {
    handle.tick(0);
    handle.tick(handle.getAnimationBegin());
    let frame2 = 0;
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      cancelAnimationFrame(frame2);
      handle.complete();
      listener(handle.getTo());
      running.current.delete(finish);
    };
    running.current.add(finish);
    if (current.current.reduced || current.current.duration === 0 || typeof handle.getFrom() !== "number") {
      finish();
      return () => {
      };
    }
    const easing = cubicBezier(...ease.out);
    let previous;
    let progress = 0;
    const tick = (now) => {
      const duration2 = current.current.duration * 1e3;
      if (duration2 === 0) return finish();
      progress = Math.min(1, progress + (previous === void 0 ? 0 : now - previous) / duration2);
      previous = now;
      if (progress === 1) {
        finish();
        return;
      }
      const from = Number(handle.getFrom());
      listener(from + (Number(handle.getTo()) - from) * easing(progress));
      frame2 = requestAnimationFrame(tick);
    };
    frame2 = requestAnimationFrame(tick);
    return () => {
      done = true;
      cancelAnimationFrame(frame2);
      running.current.delete(finish);
    };
  }, []);
  const uniqueId = React6.useId();
  const chartId = `chart-${id ?? uniqueId.replace(/:/g, "")}`;
  return /* @__PURE__ */ jsx121(ChartContext.Provider, { value: { config: config2 }, children: /* @__PURE__ */ jsxs82(
    "div",
    {
      "data-slot": "chart",
      "data-motion": cm.mode,
      "data-chart": chartId,
      className: cn(
        "flex aspect-video justify-center text-xs [&_.recharts-cartesian-axis-tick_text]:fill-muted-foreground [&_.recharts-cartesian-grid_line[stroke='#ccc']]:stroke-border/50 [&_.recharts-curve.recharts-tooltip-cursor]:stroke-border [&_.recharts-dot[stroke='#fff']]:stroke-transparent [&_.recharts-layer]:outline-hidden [&_.recharts-polar-grid_[stroke='#ccc']]:stroke-border [&_.recharts-radial-bar-background-sector]:fill-muted [&_.recharts-rectangle.recharts-tooltip-cursor]:fill-muted [&_.recharts-reference-line_[stroke='#ccc']]:stroke-border [&_.recharts-sector]:outline-hidden [&_.recharts-sector[stroke='#fff']]:stroke-transparent [&_.recharts-surface]:outline-hidden",
        className
      ),
      ...props,
      children: [
        /* @__PURE__ */ jsx121(ChartStyle, { id: chartId, config: config2 }),
        /* @__PURE__ */ jsx121(RechartsPrimitive.AnimationControllerProvider, { value: controller, children: /* @__PURE__ */ jsx121(RechartsPrimitive.ResponsiveContainer, { initialDimension, children: React6.isValidElement(children) ? chartSeries(children, cm.reduced || clock2.duration === 0) : children }) })
      ]
    }
  ) });
}
var ChartStyle = ({ id, config: config2 }) => {
  const colorConfig = Object.entries(config2).filter(([, config3]) => config3.theme ?? config3.color);
  if (!colorConfig.length) {
    return null;
  }
  return /* @__PURE__ */ jsx121("style", { children: Object.entries(THEMES).map(
    ([theme, prefix]) => `
${prefix} [data-chart=${id}] {
${colorConfig.map(([key, itemConfig]) => {
      const color = itemConfig.theme?.[theme] ?? itemConfig.color;
      return color ? `  --color-${key}: ${color};` : null;
    }).join("\n")}
}
`
  ).join("\n") });
};
function ChartTooltip(props) {
  return /* @__PURE__ */ jsx121(RechartsPrimitive.Tooltip, { ...props, isAnimationActive: false });
}
var contentEngineKeys = /* @__PURE__ */ new Set([
  "allowEscapeViewBox",
  "animationDuration",
  "animationEasing",
  "axisId",
  "content",
  "contentStyle",
  "cursor",
  "defaultIndex",
  "filterNull",
  "includeHidden",
  "isAnimationActive",
  "itemSorter",
  "itemStyle",
  "labelStyle",
  "offset",
  "payloadUniqBy",
  "portal",
  "position",
  "reverseDirection",
  "separator",
  "shared",
  "trigger",
  "useTranslate3d",
  "wrapperStyle",
  "wrapperClassName",
  "accessibilityLayer",
  "coordinate",
  "activeIndex",
  "viewBox",
  "iconSize",
  "iconType",
  "layout",
  "align",
  "inactiveColor",
  "legendType"
]);
function contentDivProps(props) {
  return Object.fromEntries(Object.entries(props).filter(([key]) => !contentEngineKeys.has(key)));
}
function ChartTooltipContent({
  active,
  payload,
  className,
  indicator = "dot",
  hideLabel = false,
  hideIndicator = false,
  label: label2,
  labelFormatter,
  labelClassName,
  formatter,
  color,
  nameKey,
  labelKey,
  ...divProps
}) {
  const { config: config2 } = useChart();
  const tooltipLabel = React6.useMemo(() => {
    if (hideLabel || !payload?.length) {
      return null;
    }
    const [item] = payload;
    const key = `${labelKey ?? item?.dataKey ?? item?.name ?? "value"}`;
    const itemConfig = getPayloadConfigFromPayload(config2, item, key);
    const value = !labelKey && typeof label2 === "string" ? config2[label2]?.label ?? label2 : itemConfig?.label;
    if (labelFormatter) {
      return /* @__PURE__ */ jsx121("div", { className: cn("font-medium", labelClassName), children: labelFormatter(value, payload) });
    }
    if (!value) {
      return null;
    }
    return /* @__PURE__ */ jsx121("div", { className: cn("font-medium", labelClassName), children: value });
  }, [label2, labelFormatter, payload, hideLabel, labelClassName, config2, labelKey]);
  if (!active || !payload?.length) {
    return null;
  }
  const nestLabel = payload.length === 1 && indicator !== "dot";
  return /* @__PURE__ */ jsxs82(
    "div",
    {
      className: cn(
        "grid min-w-[8rem] items-start gap-1.5 rounded-lg border border-border/50 bg-background px-2.5 py-1.5 text-xs shadow-xl",
        className
      ),
      ...contentDivProps(divProps),
      children: [
        !nestLabel ? tooltipLabel : null,
        /* @__PURE__ */ jsx121("div", { className: "grid gap-1.5", children: payload.filter((item) => item.type !== "none").map((item, index) => {
          const key = `${nameKey ?? item.name ?? item.dataKey ?? "value"}`;
          const itemConfig = getPayloadConfigFromPayload(config2, item, key);
          const indicatorColor = color ?? item.payload?.fill ?? item.color;
          return /* @__PURE__ */ jsx121(
            "div",
            {
              className: cn(
                "flex w-full flex-wrap items-stretch gap-2 [&>svg]:h-2.5 [&>svg]:w-2.5 [&>svg]:text-muted-foreground",
                indicator === "dot" && "items-center"
              ),
              children: formatter && item?.value !== void 0 && item.name ? formatter(item.value, item.name, item, index, item.payload) : /* @__PURE__ */ jsxs82(Fragment35, { children: [
                itemConfig?.icon ? /* @__PURE__ */ jsx121(itemConfig.icon, {}) : !hideIndicator && /* @__PURE__ */ jsx121(
                  "div",
                  {
                    className: cn("shrink-0 rounded-[2px] border-(--color-border) bg-(--color-bg)", {
                      "h-2.5 w-2.5": indicator === "dot",
                      "w-1": indicator === "line",
                      "w-0 border-[1.5px] border-dashed bg-transparent": indicator === "dashed",
                      "my-0.5": nestLabel && indicator === "dashed"
                    }),
                    style: {
                      "--color-bg": indicatorColor,
                      "--color-border": indicatorColor
                    }
                  }
                ),
                /* @__PURE__ */ jsxs82(
                  "div",
                  {
                    className: cn(
                      "flex flex-1 justify-between leading-none",
                      nestLabel ? "items-end" : "items-center"
                    ),
                    children: [
                      /* @__PURE__ */ jsxs82("div", { className: "grid gap-1.5", children: [
                        nestLabel ? tooltipLabel : null,
                        /* @__PURE__ */ jsx121("span", { className: "text-muted-foreground", children: itemConfig?.label ?? item.name })
                      ] }),
                      item.value != null && /* @__PURE__ */ jsx121("span", { className: "font-mono font-medium text-foreground tabular-nums", children: typeof item.value === "number" ? item.value.toLocaleString() : String(item.value) })
                    ]
                  }
                )
              ] })
            },
            index
          );
        }) })
      ]
    }
  );
}
var ChartLegend = RechartsPrimitive.Legend;
function ChartLegendContent({
  className,
  hideIcon = false,
  payload,
  verticalAlign = "bottom",
  nameKey,
  formatter,
  onClick,
  onMouseEnter,
  onMouseLeave,
  ...divProps
}) {
  const { config: config2 } = useChart();
  if (!payload?.length) {
    return null;
  }
  return /* @__PURE__ */ jsx121(
    "div",
    {
      className: cn("flex items-center justify-center gap-4", verticalAlign === "top" ? "pb-3" : "pt-3", className),
      ...contentDivProps(divProps),
      children: payload.filter((item) => item.type !== "none").map((item, index) => {
        const key = `${nameKey ?? item.dataKey ?? "value"}`;
        const itemConfig = getPayloadConfigFromPayload(config2, item, key);
        return (
          // biome-ignore lint/a11y/noStaticElementInteractions: role and keyboard activation are enabled together only for a caller click handler.
          /* @__PURE__ */ jsxs82(
            "div",
            {
              className: cn("flex items-center gap-1.5 [&>svg]:h-3 [&>svg]:w-3 [&>svg]:text-muted-foreground"),
              role: onClick ? "button" : void 0,
              tabIndex: onClick ? 0 : void 0,
              onClick: (event) => onClick?.(item, index, event),
              onKeyDown: (event) => {
                if (onClick && (event.key === "Enter" || event.key === " ")) {
                  event.preventDefault();
                  event.currentTarget.click();
                }
              },
              onMouseEnter: (event) => onMouseEnter?.(item, index, event),
              onMouseLeave: (event) => onMouseLeave?.(item, index, event),
              children: [
                itemConfig?.icon && !hideIcon ? /* @__PURE__ */ jsx121(itemConfig.icon, {}) : /* @__PURE__ */ jsx121(
                  "div",
                  {
                    className: "h-2 w-2 shrink-0 rounded-[2px]",
                    style: {
                      backgroundColor: item.color
                    }
                  }
                ),
                formatter ? formatter(itemConfig?.label ?? item.value, item, index) : itemConfig?.label
              ]
            },
            index
          )
        );
      })
    }
  );
}
function getPayloadConfigFromPayload(config2, payload, key) {
  if (typeof payload !== "object" || payload === null) {
    return void 0;
  }
  const payloadPayload = "payload" in payload && typeof payload.payload === "object" && payload.payload !== null ? payload.payload : void 0;
  let configLabelKey = key;
  if (key in payload && typeof payload[key] === "string") {
    configLabelKey = payload[key];
  } else if (payloadPayload && key in payloadPayload && typeof payloadPayload[key] === "string") {
    configLabelKey = payloadPayload[key];
  }
  return configLabelKey in config2 ? config2[configLabelKey] : config2[key];
}

// components/site/previews/chart.tsx
import { jsx as jsx122, jsxs as jsxs83 } from "react/jsx-runtime";
var variants2 = ["bar", "line", "area", "pie"];
var config = {
  desktop: { label: "Desktop", color: "var(--foreground)" },
  mobile: { label: "Mobile", color: "var(--muted-foreground)" }
};
var baseline = [
  { month: "Jan", desktop: 186, mobile: 80 },
  { month: "Feb", desktop: 305, mobile: 200 },
  { month: "Mar", desktop: 237, mobile: 120 },
  { month: "Apr", desktop: 73, mobile: 190 }
];
function ChartPreview() {
  const [authoredType, setType] = useState31("bar");
  const { control, choose, select } = usePreviewVariant("Chart", variants2);
  const type = choose(authoredType);
  const [updated, setUpdated] = useState31(false);
  const [mode, setMode] = useState31();
  const data = updated ? baseline.map((row) => ({ ...row, desktop: 350 - row.desktop, mobile: row.mobile + 40 })) : baseline;
  return /* @__PURE__ */ jsxs83("div", { className: "grid w-full min-w-0 grid-cols-1 gap-4", children: [
    control,
    /* @__PURE__ */ jsxs83("div", { className: "flex flex-wrap items-center gap-3", children: [
      /* @__PURE__ */ jsx122(Button, { variant: "outline", onClick: () => setUpdated((value) => !value), children: "Update data" }),
      /* @__PURE__ */ jsxs83("label", { className: "text-sm", children: [
        "Chart motion",
        " ",
        /* @__PURE__ */ jsxs83(
          "select",
          {
            "aria-label": "Chart motion",
            className: "rounded border bg-background p-1",
            value: mode ?? "inherit",
            onChange: (event) => setMode(event.target.value === "inherit" ? void 0 : event.target.value),
            children: [
              /* @__PURE__ */ jsx122("option", { value: "inherit", children: "Inherit" }),
              /* @__PURE__ */ jsx122("option", { value: "full", children: "Full" }),
              /* @__PURE__ */ jsx122("option", { value: "reduced", children: "Reduced" }),
              /* @__PURE__ */ jsx122("option", { value: "none", children: "None" })
            ]
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxs83("label", { className: "text-sm", children: [
      "Chart type",
      " ",
      /* @__PURE__ */ jsxs83(
        "select",
        {
          "aria-label": "Chart type",
          className: "rounded border bg-background p-1",
          value: type,
          onChange: (event) => {
            select("all");
            setType(event.target.value);
          },
          children: [
            /* @__PURE__ */ jsx122("option", { value: "bar", children: "Bar" }),
            /* @__PURE__ */ jsx122("option", { value: "line", children: "Line" }),
            /* @__PURE__ */ jsx122("option", { value: "area", children: "Area" }),
            /* @__PURE__ */ jsx122("option", { value: "pie", children: "Pie" })
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsxs83("p", { className: "text-sm font-medium", children: [
      "Monthly visits \xB7 ",
      updated ? "Updated" : "Baseline"
    ] }),
    /* @__PURE__ */ jsx122(CadenceProvider, { mode, children: /* @__PURE__ */ jsx122(ChartContainer, { config, className: "h-64 w-full min-w-0", "aria-label": "Monthly visits", children: type === "bar" ? /* @__PURE__ */ jsxs83(BarChart, { accessibilityLayer: true, data, children: [
      /* @__PURE__ */ jsx122(CartesianGrid, { vertical: false }),
      /* @__PURE__ */ jsx122(XAxis, { dataKey: "month", tickLine: false, axisLine: false }),
      /* @__PURE__ */ jsx122(ChartTooltip, { content: /* @__PURE__ */ jsx122(ChartTooltipContent, {}) }),
      /* @__PURE__ */ jsx122(ChartLegend, { content: /* @__PURE__ */ jsx122(ChartLegendContent, {}) }),
      /* @__PURE__ */ jsx122(
        Bar2,
        {
          dataKey: "desktop",
          fill: "var(--color-desktop)",
          radius: 4,
          isAnimationActive: true,
          animationDuration: 5e3
        }
      ),
      /* @__PURE__ */ jsx122(Bar2, { dataKey: "mobile", fill: "var(--color-mobile)", radius: 4, isAnimationActive: true, animationBegin: 5e3 })
    ] }) : type === "line" ? /* @__PURE__ */ jsxs83(LineChart, { accessibilityLayer: true, data, children: [
      /* @__PURE__ */ jsx122(XAxis, { dataKey: "month" }),
      /* @__PURE__ */ jsx122(ChartTooltip, { content: /* @__PURE__ */ jsx122(ChartTooltipContent, {}) }),
      /* @__PURE__ */ jsx122(Line2, { dataKey: "desktop", stroke: "var(--color-desktop)", isAnimationActive: true, animationDuration: 5e3 })
    ] }) : type === "area" ? /* @__PURE__ */ jsxs83(AreaChart, { accessibilityLayer: true, data, children: [
      /* @__PURE__ */ jsx122(XAxis, { dataKey: "month" }),
      /* @__PURE__ */ jsx122(ChartTooltip, { content: /* @__PURE__ */ jsx122(ChartTooltipContent, {}) }),
      /* @__PURE__ */ jsx122(Area2, { dataKey: "desktop", fill: "var(--color-mobile)", stroke: "var(--color-desktop)", isAnimationActive: true })
    ] }) : /* @__PURE__ */ jsxs83(PieChart, { accessibilityLayer: true, children: [
      /* @__PURE__ */ jsx122(ChartTooltip, { content: /* @__PURE__ */ jsx122(ChartTooltipContent, { nameKey: "month" }) }),
      /* @__PURE__ */ jsx122(Pie2, { data, dataKey: "desktop", nameKey: "month", fill: "var(--color-desktop)", isAnimationActive: true })
    ] }) }) }),
    /* @__PURE__ */ jsxs83("details", { className: "text-sm", children: [
      /* @__PURE__ */ jsx122("summary", { className: "cursor-pointer", children: "View data table" }),
      /* @__PURE__ */ jsxs83("table", { className: "mt-2 w-full text-left", children: [
        /* @__PURE__ */ jsx122("caption", { className: "sr-only", children: "Monthly visits" }),
        /* @__PURE__ */ jsx122("thead", { children: /* @__PURE__ */ jsxs83("tr", { children: [
          /* @__PURE__ */ jsx122("th", { scope: "col", children: "Month" }),
          /* @__PURE__ */ jsx122("th", { scope: "col", children: "Desktop" }),
          /* @__PURE__ */ jsx122("th", { scope: "col", children: "Mobile" })
        ] }) }),
        /* @__PURE__ */ jsx122("tbody", { children: data.map((row) => /* @__PURE__ */ jsxs83("tr", { children: [
          /* @__PURE__ */ jsx122("th", { scope: "row", children: row.month }),
          /* @__PURE__ */ jsx122("td", { children: row.desktop }),
          /* @__PURE__ */ jsx122("td", { children: row.mobile })
        ] }, row.month)) })
      ] })
    ] })
  ] });
}

// components/site/previews/calendar.tsx
import { enUS, fr } from "date-fns/locale";
import { useState as useState32 } from "react";

// registry/cadence/calendar/index.tsx
import { ChevronDownIcon as ChevronDownIcon5, ChevronLeftIcon as ChevronLeftIcon2, ChevronRightIcon as ChevronRightIcon4 } from "lucide-react";
import * as React7 from "react";
import {
  DayPicker,
  getDefaultClassNames
} from "react-day-picker";
import { jsx as jsx123 } from "react/jsx-runtime";
function Calendar({
  className,
  classNames,
  showOutsideDays = true,
  captionLayout = "label",
  buttonVariant = "ghost",
  locale,
  formatters,
  components,
  ...props
}) {
  const defaultClassNames = getDefaultClassNames();
  return /* @__PURE__ */ jsx123(LocaleContext, { value: locale, children: /* @__PURE__ */ jsx123(
    DayPicker,
    {
      showOutsideDays,
      className: cn(
        "group/calendar bg-background p-3 [--cell-size:--spacing(8)] [[data-slot=card-content]_&]:bg-transparent [[data-slot=popover-content]_&]:bg-transparent",
        String.raw`rtl:**:[.rdp-button\_next>svg]:rotate-180`,
        String.raw`rtl:**:[.rdp-button\_previous>svg]:rotate-180`,
        className
      ),
      captionLayout,
      locale,
      formatters: {
        formatMonthDropdown: (date) => date.toLocaleString(locale?.code, { month: "short" }),
        ...formatters
      },
      classNames: {
        root: cn("w-fit", defaultClassNames.root),
        months: cn("relative flex flex-col gap-4 md:flex-row", defaultClassNames.months),
        month: cn("flex w-full flex-col gap-4", defaultClassNames.month),
        nav: cn("absolute inset-x-0 top-0 flex w-full items-center justify-between gap-1", defaultClassNames.nav),
        button_previous: cn(
          buttonVariants({ variant: buttonVariant }),
          "size-(--cell-size) p-0 select-none aria-disabled:opacity-50",
          defaultClassNames.button_previous
        ),
        button_next: cn(
          buttonVariants({ variant: buttonVariant }),
          "size-(--cell-size) p-0 select-none aria-disabled:opacity-50",
          defaultClassNames.button_next
        ),
        month_caption: cn(
          "flex h-(--cell-size) w-full items-center justify-center px-(--cell-size)",
          defaultClassNames.month_caption
        ),
        dropdowns: cn(
          "flex h-(--cell-size) w-full items-center justify-center gap-1.5 text-sm font-medium",
          defaultClassNames.dropdowns
        ),
        dropdown_root: cn(
          "relative rounded-md border border-input shadow-xs has-focus:border-ring has-focus:ring-[3px] has-focus:ring-ring/50",
          defaultClassNames.dropdown_root
        ),
        dropdown: cn("absolute inset-0 bg-popover opacity-0", defaultClassNames.dropdown),
        caption_label: cn(
          "font-medium select-none",
          captionLayout === "label" ? "text-sm" : "flex h-8 items-center gap-1 rounded-md pr-1 pl-2 text-sm [&>svg]:size-3.5 [&>svg]:text-muted-foreground",
          defaultClassNames.caption_label
        ),
        month_grid: cn("w-full border-collapse", defaultClassNames.month_grid),
        weekdays: cn("flex", defaultClassNames.weekdays),
        weekday: cn(
          "flex-1 rounded-md text-[0.8rem] font-normal text-muted-foreground select-none",
          defaultClassNames.weekday
        ),
        week: cn("mt-2 flex w-full", defaultClassNames.week),
        week_number_header: cn("w-(--cell-size) select-none", defaultClassNames.week_number_header),
        week_number: cn("text-[0.8rem] text-muted-foreground select-none", defaultClassNames.week_number),
        day: cn(
          "group/day relative aspect-square h-full w-full p-0 text-center select-none [&:last-child[data-selected=true]_button]:rounded-r-md",
          props.showWeekNumber ? "[&:nth-child(2)[data-selected=true]_button]:rounded-l-md" : "[&:first-child[data-selected=true]_button]:rounded-l-md",
          defaultClassNames.day
        ),
        range_start: cn("rounded-l-md bg-accent", defaultClassNames.range_start),
        range_middle: cn("rounded-none", defaultClassNames.range_middle),
        range_end: cn("rounded-r-md bg-accent", defaultClassNames.range_end),
        today: cn(
          "rounded-md bg-accent text-accent-foreground data-[selected=true]:rounded-none",
          defaultClassNames.today
        ),
        outside: cn("text-muted-foreground aria-selected:text-muted-foreground", defaultClassNames.outside),
        disabled: cn("text-muted-foreground opacity-50", defaultClassNames.disabled),
        hidden: cn("invisible", defaultClassNames.hidden),
        ...classNames
      },
      components: {
        Root: CalendarRoot,
        Month: CalendarMonth,
        MonthGrid: CalendarMonthGrid,
        Chevron: CalendarChevron,
        DayButton: LocalDayButton,
        WeekNumber: CalendarWeekNumber,
        ...components
      },
      ...props
    }
  ) });
}
function CalendarDayButton({
  className,
  day,
  modifiers,
  locale,
  ...props
}) {
  const defaultClassNames = getDefaultClassNames();
  const ref = React7.useRef(null);
  React7.useEffect(() => {
    if (modifiers.focused) ref.current?.focus();
  }, [modifiers.focused]);
  return /* @__PURE__ */ jsx123(
    "button",
    {
      ref,
      type: "button",
      "data-slot": "button",
      "data-variant": "ghost",
      "data-size": "icon",
      "data-day": day.date.toLocaleDateString(locale?.code),
      "data-selected-single": modifiers.selected && !modifiers.range_start && !modifiers.range_end && !modifiers.range_middle,
      "data-range-start": modifiers.range_start,
      "data-range-end": modifiers.range_end,
      "data-range-middle": modifiers.range_middle,
      className: cn(
        buttonVariants({ variant: "ghost", size: "icon" }),
        "flex aspect-square size-auto w-full min-w-(--cell-size) flex-col gap-1 leading-none font-normal group-data-[focused=true]/day:relative group-data-[focused=true]/day:z-10 group-data-[focused=true]/day:border-ring group-data-[focused=true]/day:ring-[3px] group-data-[focused=true]/day:ring-ring/50 data-[range-end=true]:rounded-md data-[range-end=true]:rounded-r-md data-[range-end=true]:bg-primary data-[range-end=true]:text-primary-foreground data-[range-middle=true]:rounded-none data-[range-middle=true]:bg-accent data-[range-middle=true]:text-accent-foreground data-[range-start=true]:rounded-md data-[range-start=true]:rounded-l-md data-[range-start=true]:bg-primary data-[range-start=true]:text-primary-foreground data-[selected-single=true]:bg-primary data-[selected-single=true]:text-primary-foreground dark:hover:text-accent-foreground [&>span]:text-xs [&>span]:opacity-70",
        defaultClassNames.day,
        className
      ),
      ...props
    }
  );
}
var LocaleContext = React7.createContext(void 0);
function LocalDayButton(props) {
  const locale = React7.useContext(LocaleContext);
  return /* @__PURE__ */ jsx123(CalendarDayButton, { locale, ...props });
}
function CalendarChevron({ className, orientation, ...props }) {
  const Icon = orientation === "left" ? ChevronLeftIcon2 : orientation === "right" ? ChevronRightIcon4 : ChevronDownIcon5;
  return /* @__PURE__ */ jsx123(Icon, { className: cn("size-4", className), ...props });
}
function CalendarWeekNumber({ children, ...props }) {
  return /* @__PURE__ */ jsx123("td", { ...props, children: /* @__PURE__ */ jsx123("div", { className: "flex size-(--cell-size) items-center justify-center text-center", children }) });
}
var MonthContext = React7.createContext(0);
function CalendarMonth({ calendarMonth, displayIndex: _displayIndex, ...props }) {
  return /* @__PURE__ */ jsx123(MonthContext, { value: calendarMonth.date.getTime(), children: /* @__PURE__ */ jsx123("div", { ...props }) });
}
function CalendarRoot({ rootRef, ...props }) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx123("div", { "data-slot": "calendar", "data-motion": cm.mode, ref: rootRef, ...props });
}
function CalendarMonthGrid({ style, ...props }) {
  const cm = useCadenceMotion();
  const month = React7.useContext(MonthContext);
  const previous = React7.useRef(month);
  const scope = React7.useRef(null);
  const { mode, reduced, timeScale } = cm;
  const transition = cm.transition("data.transition");
  React7.useLayoutEffect(() => {
    const changed = previous.current !== month;
    const direction = month > previous.current ? 1 : -1;
    previous.current = month;
    const element = scope.current;
    if (!element || !changed || mode === "none") return;
    if (!element.animate) return;
    const from = {};
    const to = {};
    if (style?.opacity === void 0) {
      from.opacity = 0;
      to.opacity = 1;
    }
    if (!reduced && !style?.transform) {
      from.transform = `translateX(${direction * cm.distance.sm}px)`;
      to.transform = "none";
    }
    const easing = Array.isArray(transition.ease) ? `cubic-bezier(${transition.ease.join(",")})` : "linear";
    const animation = element.animate([from, to], { duration: (transition.duration ?? 0) * 1e3, easing });
    return () => animation.cancel();
  }, [month, mode, reduced, timeScale, scope, style?.transform, style?.opacity]);
  return /* @__PURE__ */ jsx123("table", { ref: scope, "data-slot": "calendar-month-grid", "data-motion": cm.mode, style, ...props });
}

// components/site/previews/calendar.tsx
import { Fragment as Fragment36, jsx as jsx124, jsxs as jsxs84 } from "react/jsx-runtime";
var previewVariantOptions28 = ["default", "secondary", "destructive", "outline", "ghost", "link"];
function CalendarPreview() {
  const { control, choose } = usePreviewVariant("Calendar", previewVariantOptions28);
  const [month, setMonth] = useState32(new Date(2026, 10, 1));
  const [date, setDate] = useState32(new Date(2026, 10, 12));
  const [multiple, setMultiple] = useState32([]);
  const [range, setRange] = useState32();
  const [kind, setKind] = useState32("single");
  const [mode, setMode] = useState32();
  const [months, setMonths] = useState32(1);
  const [french, setFrench] = useState32(false);
  const common = {
    month,
    numberOfMonths: months,
    onMonthChange: setMonth,
    locale: french ? fr : enUS,
    weekStartsOn: 1,
    disabled: new Date(2026, 10, 5),
    fixedWeeks: true,
    className: "rounded-md border",
    captionLayout: "dropdown",
    startMonth: new Date(2025, 0),
    endMonth: new Date(2028, 11)
  };
  return /* @__PURE__ */ jsxs84(Fragment36, { children: [
    control,
    /* @__PURE__ */ jsxs84("div", { className: "flex w-full min-w-0 flex-col items-center gap-4", children: [
      /* @__PURE__ */ jsxs84("div", { className: "flex flex-wrap justify-center gap-3 text-sm", children: [
        /* @__PURE__ */ jsxs84("label", { children: [
          "Selection",
          " ",
          /* @__PURE__ */ jsxs84("select", { "aria-label": "Selection mode", value: kind, onChange: (e) => setKind(e.target.value), children: [
            /* @__PURE__ */ jsx124("option", { children: "single" }),
            /* @__PURE__ */ jsx124("option", { children: "multiple" }),
            /* @__PURE__ */ jsx124("option", { children: "range" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs84("label", { children: [
          "Motion",
          " ",
          /* @__PURE__ */ jsxs84(
            "select",
            {
              "aria-label": "Calendar motion",
              value: mode ?? "inherit",
              onChange: (e) => setMode(e.target.value === "inherit" ? void 0 : e.target.value),
              children: [
                /* @__PURE__ */ jsx124("option", { value: "inherit", children: "inherit" }),
                /* @__PURE__ */ jsx124("option", { children: "full" }),
                /* @__PURE__ */ jsx124("option", { children: "reduced" }),
                /* @__PURE__ */ jsx124("option", { children: "none" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxs84("label", { children: [
          "Months",
          " ",
          /* @__PURE__ */ jsxs84("select", { "aria-label": "Displayed months", value: months, onChange: (e) => setMonths(Number(e.target.value)), children: [
            /* @__PURE__ */ jsx124("option", { value: "1", children: "1" }),
            /* @__PURE__ */ jsx124("option", { value: "2", children: "2" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs84("label", { children: [
          /* @__PURE__ */ jsx124("input", { type: "checkbox", checked: french, onChange: (e) => setFrench(e.target.checked) }),
          " French"
        ] }),
        /* @__PURE__ */ jsx124(
          "button",
          {
            type: "button",
            className: "underline",
            onClick: () => {
              setMonth(new Date(2026, 10, 1));
              setDate(new Date(2026, 10, 20));
            },
            children: "Set November 20"
          }
        )
      ] }),
      /* @__PURE__ */ jsx124(CadenceProvider, { mode, children: kind === "single" ? /* @__PURE__ */ jsx124(Calendar, { ...common, mode: "single", selected: date, onSelect: setDate, buttonVariant: choose("ghost") }) : kind === "multiple" ? /* @__PURE__ */ jsx124(
        Calendar,
        {
          ...common,
          mode: "multiple",
          selected: multiple,
          onSelect: setMultiple,
          buttonVariant: choose("ghost")
        }
      ) : /* @__PURE__ */ jsx124(Calendar, { ...common, mode: "range", selected: range, onSelect: setRange, buttonVariant: choose("ghost") }) }),
      /* @__PURE__ */ jsx124("p", { "aria-live": "polite", className: "text-sm text-muted-foreground", children: kind === "single" ? date?.toDateString() ?? "No date" : kind === "multiple" ? `${multiple?.length ?? 0} dates` : `${range?.from?.toDateString() ?? "Start"} \u2013 ${range?.to?.toDateString() ?? "End"}` })
    ] })
  ] });
}

// components/site/previews/navigation-menu.tsx
import { useState as useState33 } from "react";

// registry/cadence/navigation-menu/index.tsx
import { NavigationMenu as NavigationMenuPrimitive } from "@base-ui/react/navigation-menu";
import { cva as cva12 } from "class-variance-authority";
import { ChevronDownIcon as ChevronDownIcon6 } from "lucide-react";
import * as React8 from "react";
import { jsx as jsx125, jsxs as jsxs85 } from "react/jsx-runtime";
function useNavigationGuards(ref) {
  return React8.useCallback(
    (node) => {
      let refCleanup;
      if (typeof ref === "function") refCleanup = ref(node) || void 0;
      else if (ref) ref.current = node;
      if (!node) return;
      const repair = () => {
        for (const guard of node.querySelectorAll('[data-base-ui-focus-guard][aria-hidden="true"]')) {
          guard.removeAttribute("aria-hidden");
        }
      };
      repair();
      const observer = new MutationObserver(repair);
      observer.observe(node, { childList: true, subtree: true });
      return () => {
        observer.disconnect();
        if (typeof refCleanup === "function") refCleanup();
        else if (typeof ref === "function") ref(null);
        else if (ref) ref.current = null;
      };
    },
    [ref]
  );
}
function clock(cm) {
  const factor = cm.disabled ? 0 : (cm.reduced ? reducedDurationScale : 1) * cm.timeScale;
  return {
    "--motion-duration-fast": `${duration.fast * factor}s`,
    "--motion-duration-slow": `${duration.slow * factor}s`
  };
}
function classes(base, value) {
  return typeof value === "function" ? (state) => cn(base, value(state)) : cn(base, value);
}
function NavigationMenu({
  align = "start",
  className,
  children,
  ref,
  ...props
}) {
  const guardRef = useNavigationGuards(ref);
  return /* @__PURE__ */ jsxs85(
    NavigationMenuPrimitive.Root,
    {
      ref: guardRef,
      "data-slot": "navigation-menu",
      className: classes(
        "cn-navigation-menu group/navigation-menu relative flex max-w-max flex-1 items-center justify-center",
        className
      ),
      ...props,
      children: [
        children,
        /* @__PURE__ */ jsx125(NavigationMenuPositioner, { align })
      ]
    }
  );
}
function NavigationMenuList({ className, ...props }) {
  return /* @__PURE__ */ jsx125(
    NavigationMenuPrimitive.List,
    {
      "data-slot": "navigation-menu-list",
      className: classes("group flex flex-1 list-none items-center justify-center gap-1", className),
      ...props
    }
  );
}
function NavigationMenuItem({ className, ...props }) {
  return /* @__PURE__ */ jsx125(
    NavigationMenuPrimitive.Item,
    {
      "data-slot": "navigation-menu-item",
      className: classes("cn-navigation-menu-item relative", className),
      ...props
    }
  );
}
var navigationMenuTriggerStyle = cva12(
  "group/navigation-menu-trigger inline-flex h-9 w-max items-center justify-center rounded-md bg-background px-4 py-2 text-sm font-medium outline-none hover:bg-accent focus-visible:ring-[3px] focus-visible:ring-ring/50 data-disabled:pointer-events-none data-disabled:opacity-50 data-popup-open:bg-accent/50"
);
function NavigationMenuTrigger({ className, children, ...props }) {
  return /* @__PURE__ */ jsxs85(
    NavigationMenuPrimitive.Trigger,
    {
      "data-slot": "navigation-menu-trigger",
      className: classes(navigationMenuTriggerStyle(), className),
      ...props,
      children: [
        children,
        " ",
        /* @__PURE__ */ jsx125(ChevronDownIcon6, { className: "ml-1 size-3", "aria-hidden": "true" })
      ]
    }
  );
}
function NavigationMenuContent({ className, style, ...props }) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx125(
    NavigationMenuPrimitive.Content,
    {
      style: typeof style === "function" ? (state) => ({ ...clock(cm), ...style(state) }) : { ...clock(cm), ...style },
      "data-slot": "navigation-menu-content",
      "data-motion": cm.mode,
      "data-reduced": cm.reduced || void 0,
      className: classes(
        cn(
          "h-full w-auto p-2 transition-opacity duration-(--motion-duration-fast) ease-cadence-out",
          cm.disabled && "transition-none",
          !cm.disabled && "data-ending-style:opacity-0 data-starting-style:opacity-0"
        ),
        className
      ),
      ...props
    }
  );
}
function NavigationMenuPositioner({
  className,
  ref,
  side = "bottom",
  sideOffset = 8,
  align = "start",
  alignOffset = 0,
  ...props
}) {
  const guardRef = useNavigationGuards(ref);
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx125(NavigationMenuPrimitive.Portal, { children: /* @__PURE__ */ jsx125(
    NavigationMenuPrimitive.Positioner,
    {
      ref: guardRef,
      "data-slot": "navigation-menu-positioner",
      "data-motion": cm.mode,
      side,
      sideOffset,
      align,
      alignOffset,
      className: classes(
        "isolate z-50 h-(--positioner-height) w-(--positioner-width) max-w-(--available-width)",
        className
      ),
      ...props,
      children: /* @__PURE__ */ jsx125(
        NavigationMenuPrimitive.Popup,
        {
          style: clock(cm),
          "data-slot": "navigation-menu-popup",
          "data-motion": cm.mode,
          className: cn(
            "relative h-(--popup-height) w-(--popup-width) min-h-0 min-w-0 max-h-(--available-height) max-w-(--available-width) origin-(--transform-origin) rounded-md border bg-popover text-popover-foreground shadow-md ease-cadence-out duration-(--motion-duration-fast)",
            !cm.disabled && "data-ending-style:opacity-0 data-starting-style:opacity-0",
            cm.disabled ? "transition-none" : cm.reduced ? "transition-opacity" : "transition-[opacity,scale,width,height] duration-[var(--motion-duration-fast),var(--motion-duration-fast),var(--motion-duration-slow),var(--motion-duration-slow)] data-starting-style:scale-(--motion-scale-in) data-ending-style:scale-(--motion-scale-in)"
          ),
          children: /* @__PURE__ */ jsx125(
            NavigationMenuPrimitive.Viewport,
            {
              "data-slot": "navigation-menu-viewport",
              className: "relative size-full overflow-auto"
            }
          )
        }
      )
    }
  ) });
}
function NavigationMenuLink({ className, ...props }) {
  return /* @__PURE__ */ jsx125(
    NavigationMenuPrimitive.Link,
    {
      "data-slot": "navigation-menu-link",
      className: classes(
        "flex flex-col gap-1 rounded-sm p-2 text-sm outline-none hover:bg-accent focus-visible:ring-[3px] focus-visible:ring-ring/50 data-active:bg-accent/50",
        className
      ),
      ...props
    }
  );
}

// components/site/previews/navigation-menu.tsx
import { jsx as jsx126, jsxs as jsxs86 } from "react/jsx-runtime";
function NavigationMenuPreview() {
  const inherited = useCadenceMotion();
  const [mode, setMode] = useState33();
  const [value, setValue] = useState33(null);
  const [expanded, setExpanded] = useState33(false);
  return /* @__PURE__ */ jsxs86("div", { className: "flex min-h-96 w-full flex-col items-start gap-4", children: [
    /* @__PURE__ */ jsxs86("div", { className: "flex flex-wrap items-center gap-3 text-sm", children: [
      /* @__PURE__ */ jsxs86("label", { children: [
        "Menu motion",
        " ",
        /* @__PURE__ */ jsx126(
          "select",
          {
            "aria-label": "Menu motion",
            value: mode ?? inherited.mode,
            onChange: (e) => setMode(e.target.value),
            children: ["full", "reduced", "none"].map((m) => /* @__PURE__ */ jsx126("option", { children: m }, m))
          }
        )
      ] }),
      /* @__PURE__ */ jsx126(
        "button",
        {
          type: "button",
          className: "rounded border px-2 py-1",
          onClick: () => setValue(value === "learn" ? "build" : "learn"),
          children: "Switch panel"
        }
      ),
      /* @__PURE__ */ jsxs86("label", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsx126("input", { type: "checkbox", checked: expanded, onChange: (e) => setExpanded(e.target.checked) }),
        "Extra links"
      ] })
    ] }),
    /* @__PURE__ */ jsx126(CadenceProvider, { mode, children: /* @__PURE__ */ jsx126(NavigationMenu, { className: "flex-none", "aria-label": "Example navigation", value, onValueChange: setValue, children: /* @__PURE__ */ jsxs86(NavigationMenuList, { children: [
      /* @__PURE__ */ jsxs86(NavigationMenuItem, { value: "learn", children: [
        /* @__PURE__ */ jsx126(NavigationMenuTrigger, { children: "Learn" }),
        /* @__PURE__ */ jsxs86(NavigationMenuContent, { className: "w-60", keepMounted: true, children: [
          /* @__PURE__ */ jsx126("button", { type: "button", className: "rounded p-2 text-sm underline", onClick: () => setExpanded((v) => !v), children: "Toggle details" }),
          /* @__PURE__ */ jsx126(NavigationMenuLink, { href: "#installation", children: "Installation" }),
          /* @__PURE__ */ jsx126(NavigationMenuLink, { href: "#usage", children: "Usage" }),
          expanded && /* @__PURE__ */ jsx126(NavigationMenuLink, { href: "#motion-contract", children: "Motion contract" })
        ] })
      ] }),
      /* @__PURE__ */ jsxs86(NavigationMenuItem, { value: "build", children: [
        /* @__PURE__ */ jsx126(NavigationMenuTrigger, { children: "Build" }),
        /* @__PURE__ */ jsxs86(NavigationMenuContent, { className: "grid w-80 grid-cols-2 gap-2", keepMounted: true, children: [
          /* @__PURE__ */ jsx126(
            "button",
            {
              type: "button",
              className: "col-span-2 rounded p-2 text-sm underline",
              onClick: () => setExpanded((v) => !v),
              children: "Toggle details"
            }
          ),
          expanded && /* @__PURE__ */ jsx126(NavigationMenuLink, { href: "#motion-contract", children: "Motion contract" }),
          ["Components", "Templates", "Themes", "Registry", "Accessibility", "Performance"].map((text) => /* @__PURE__ */ jsx126(NavigationMenuLink, { href: "#usage", children: text }, text))
        ] })
      ] }),
      /* @__PURE__ */ jsx126(NavigationMenuItem, { children: /* @__PURE__ */ jsx126(NavigationMenuLink, { href: "#api", children: "API" }) })
    ] }) }) })
  ] });
}

// components/site/previews/resizable.tsx
import { useState as useState34 } from "react";
import { useGroupRef, usePanelRef } from "react-resizable-panels";

// registry/cadence/resizable/index.tsx
import { GripVerticalIcon } from "lucide-react";
import * as ResizablePrimitive from "react-resizable-panels";
import { jsx as jsx127 } from "react/jsx-runtime";
function ResizablePanelGroup({ className, ...props }) {
  return /* @__PURE__ */ jsx127(
    ResizablePrimitive.Group,
    {
      "data-slot": "resizable-panel-group",
      className: cn("flex h-full w-full aria-[orientation=vertical]:flex-col", className),
      ...props
    }
  );
}
function ResizablePanel({ ...props }) {
  return /* @__PURE__ */ jsx127(ResizablePrimitive.Panel, { "data-slot": "resizable-panel", ...props });
}
function ResizableHandle({
  withHandle,
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx127(
    ResizablePrimitive.Separator,
    {
      "data-slot": "resizable-handle",
      className: cn(
        "relative flex w-px items-center justify-center bg-border after:absolute after:inset-y-0 after:left-1/2 after:w-1 after:-translate-x-1/2 focus-visible:ring-1 focus-visible:ring-ring focus-visible:ring-offset-1 focus-visible:outline-hidden aria-[orientation=horizontal]:h-px aria-[orientation=horizontal]:w-full aria-[orientation=horizontal]:after:left-0 aria-[orientation=horizontal]:after:h-1 aria-[orientation=horizontal]:after:w-full aria-[orientation=horizontal]:after:translate-x-0 aria-[orientation=horizontal]:after:-translate-y-1/2 [&[aria-orientation=horizontal]>div]:rotate-90",
        className
      ),
      ...props,
      children: withHandle && /* @__PURE__ */ jsx127("div", { className: "z-10 flex h-4 w-3 items-center justify-center rounded-xs border bg-border", children: /* @__PURE__ */ jsx127(GripVerticalIcon, { "aria-hidden": "true", className: "size-2.5" }) })
    }
  );
}

// components/site/previews/resizable.tsx
import { Fragment as Fragment37, jsx as jsx128, jsxs as jsxs87 } from "react/jsx-runtime";
var previewVariantOptions29 = ["horizontal", "vertical"];
function ResizablePreview() {
  const {
    control: variantControl,
    choose,
    select: selectPreviewVariant
  } = usePreviewVariant("Resizable", previewVariantOptions29);
  const inherited = useCadenceMotion();
  const [mode, setMode] = useState34();
  const [vertical, setVertical] = useState34(false);
  const [disabled, setDisabled] = useState34(false);
  const [size, setSize] = useState34(40);
  const [origin, setOrigin] = useState34("initial");
  const group = useGroupRef();
  const panel = usePanelRef();
  const control = "rounded border px-2 py-1 text-sm";
  return /* @__PURE__ */ jsxs87(Fragment37, { children: [
    variantControl,
    /* @__PURE__ */ jsxs87("div", { className: "flex w-full min-w-0 flex-col gap-4", children: [
      /* @__PURE__ */ jsxs87("div", { className: "flex flex-wrap items-center gap-3 text-sm", children: [
        /* @__PURE__ */ jsxs87("label", { children: [
          "Panel motion",
          " ",
          /* @__PURE__ */ jsx128(
            "select",
            {
              "aria-label": "Panel motion",
              value: mode ?? inherited.mode,
              onChange: (e) => setMode(e.target.value),
              children: ["full", "reduced", "none"].map((m) => /* @__PURE__ */ jsx128("option", { children: m }, m))
            }
          )
        ] }),
        /* @__PURE__ */ jsxs87("label", { children: [
          /* @__PURE__ */ jsx128(
            "input",
            {
              type: "checkbox",
              checked: choose(vertical ? "vertical" : "horizontal") === "vertical",
              onChange: (e) => {
                selectPreviewVariant("all");
                setVertical(e.target.checked);
              }
            }
          ),
          " ",
          "Vertical"
        ] }),
        /* @__PURE__ */ jsxs87("label", { children: [
          /* @__PURE__ */ jsx128("input", { type: "checkbox", checked: disabled, onChange: (e) => setDisabled(e.target.checked) }),
          " Lock layout"
        ] }),
        /* @__PURE__ */ jsx128("button", { type: "button", className: control, onClick: () => panel.current?.collapse(), children: "Collapse" }),
        /* @__PURE__ */ jsx128("button", { type: "button", className: control, onClick: () => panel.current?.expand(), children: "Expand" }),
        /* @__PURE__ */ jsx128("button", { type: "button", className: control, onClick: () => panel.current?.resize("55%"), children: "Resize to 55%" }),
        /* @__PURE__ */ jsx128(
          "button",
          {
            type: "button",
            className: control,
            onClick: () => group.current?.setLayout({ explorer: 40, editor: 60 }),
            children: "Reset layout"
          }
        )
      ] }),
      /* @__PURE__ */ jsxs87("p", { className: "text-sm text-muted-foreground", "data-testid": "layout-report", children: [
        "Explorer ",
        Math.round(size),
        "% \xB7 ",
        origin
      ] }),
      /* @__PURE__ */ jsx128(CadenceProvider, { mode, children: /* @__PURE__ */ jsxs87(
        ResizablePanelGroup,
        {
          groupRef: group,
          orientation: choose(vertical ? "vertical" : "horizontal"),
          disabled,
          className: "min-h-64 rounded-md border",
          style: { height: 288 },
          onLayoutChanged: (_, meta) => setOrigin(meta.isUserInteraction ? "user" : "external"),
          children: [
            /* @__PURE__ */ jsx128(
              ResizablePanel,
              {
                id: "explorer",
                panelRef: panel,
                defaultSize: "40%",
                minSize: "20%",
                maxSize: "60%",
                collapsible: true,
                onResize: (s) => setSize(s.asPercentage),
                children: /* @__PURE__ */ jsxs87("div", { className: "flex h-full min-w-0 flex-col gap-3 overflow-auto p-4 text-sm", children: [
                  /* @__PURE__ */ jsx128("strong", { children: "Explorer" }),
                  /* @__PURE__ */ jsxs87("label", { children: [
                    "Draft",
                    /* @__PURE__ */ jsx128(
                      "input",
                      {
                        "aria-label": "Draft",
                        className: "mt-2 w-full min-w-0 rounded border bg-background px-2 py-1",
                        defaultValue: "Keep this note"
                      }
                    )
                  ] })
                ] })
              }
            ),
            /* @__PURE__ */ jsx128(ResizableHandle, { withHandle: true, "aria-label": "Resize explorer" }),
            /* @__PURE__ */ jsx128(ResizablePanel, { id: "editor", defaultSize: "60%", minSize: "40%", children: /* @__PURE__ */ jsx128("div", { className: "flex h-full items-center justify-center p-4 text-sm", children: "Editor" }) })
          ]
        }
      ) }),
      /* @__PURE__ */ jsx128("p", { className: "text-sm text-muted-foreground", children: "Drag the divider or focus it and use arrow keys. Enter collapses and expands the explorer." })
    ] })
  ] });
}

// components/site/previews/data-table.tsx
import { useState as useState36 } from "react";

// registry/cadence/data-table/index.tsx
import {
  columnFilteringFeature,
  columnVisibilityFeature,
  createColumnHelper,
  createFilteredRowModel,
  createPaginatedRowModel,
  createSortedRowModel,
  filterFn_includesString,
  rowPaginationFeature,
  rowSelectionFeature,
  rowSortingFeature,
  sortFn_alphanumeric,
  sortFn_text,
  tableFeatures,
  useTable
} from "@tanstack/react-table";
import { ArrowUpDown, ChevronDown as ChevronDown2, MoreHorizontal as MoreHorizontal2 } from "lucide-react";
import * as React9 from "react";
import { jsx as jsx129, jsxs as jsxs88 } from "react/jsx-runtime";
var features = tableFeatures({
  columnFilteringFeature,
  columnVisibilityFeature,
  rowPaginationFeature,
  rowSelectionFeature,
  rowSortingFeature,
  filteredRowModel: createFilteredRowModel(),
  paginatedRowModel: createPaginatedRowModel(),
  sortedRowModel: createSortedRowModel(),
  filterFns: { includesString: filterFn_includesString },
  sortFns: { alphanumeric: sortFn_alphanumeric, text: sortFn_text }
});
var columnHelper = createColumnHelper();
var examplePayments = [
  {
    id: "m5gr84i9",
    amount: 316,
    status: "success",
    email: "ken99@example.com"
  },
  {
    id: "3u1reuv4",
    amount: 242,
    status: "success",
    email: "Abe45@example.com"
  },
  {
    id: "derv1ws0",
    amount: 837,
    status: "processing",
    email: "Monserrat44@example.com"
  },
  {
    id: "5kma53ae",
    amount: 874,
    status: "success",
    email: "Silas22@example.com"
  },
  {
    id: "bhqecj4p",
    amount: 721,
    status: "failed",
    email: "carmella@example.com"
  }
];
var columns = columnHelper.columns([
  columnHelper.display({
    id: "select",
    header: ({ table }) => /* @__PURE__ */ jsx129(
      Checkbox,
      {
        className: "inline-flex",
        checked: table.getIsAllPageRowsSelected(),
        indeterminate: table.getIsSomePageRowsSelected() && !table.getIsAllPageRowsSelected(),
        onCheckedChange: (value) => table.toggleAllPageRowsSelected(!!value),
        "aria-label": "Select all"
      }
    ),
    cell: ({ row }) => /* @__PURE__ */ jsx129(
      Checkbox,
      {
        className: "inline-flex",
        checked: row.getIsSelected(),
        onCheckedChange: (value) => row.toggleSelected(!!value),
        "aria-label": `Select ${row.original.email}`
      }
    ),
    enableSorting: false,
    enableHiding: false
  }),
  columnHelper.accessor("status", {
    header: "Status",
    cell: ({ row }) => /* @__PURE__ */ jsx129("div", { className: "capitalize", children: row.getValue("status") })
  }),
  columnHelper.accessor("email", {
    header: ({ column }) => {
      return /* @__PURE__ */ jsxs88(Button, { variant: "ghost", onClick: () => column.toggleSorting(column.getIsSorted() === "asc"), children: [
        "Email",
        /* @__PURE__ */ jsx129(ArrowUpDown, {})
      ] });
    },
    cell: ({ row }) => /* @__PURE__ */ jsx129("div", { className: "lowercase", children: row.getValue("email") })
  }),
  columnHelper.accessor("amount", {
    header: () => /* @__PURE__ */ jsx129("div", { className: "text-right", children: "Amount" }),
    cell: ({ row }) => {
      const amount = parseFloat(row.getValue("amount"));
      const formatted = new Intl.NumberFormat("en-US", {
        style: "currency",
        currency: "USD"
      }).format(amount);
      return /* @__PURE__ */ jsx129("div", { className: "text-right font-medium", children: formatted });
    }
  }),
  columnHelper.display({
    id: "actions",
    enableHiding: false,
    cell: ({ row }) => {
      const payment = row.original;
      return /* @__PURE__ */ jsxs88(DropdownMenu, { children: [
        /* @__PURE__ */ jsxs88(DropdownMenuTrigger, { render: /* @__PURE__ */ jsx129(Button, { variant: "ghost", size: "icon-xs" }), children: [
          /* @__PURE__ */ jsx129("span", { className: "sr-only", children: "Open menu" }),
          /* @__PURE__ */ jsx129(MoreHorizontal2, {})
        ] }),
        /* @__PURE__ */ jsxs88(DropdownMenuContent, { align: "end", className: "w-44", children: [
          /* @__PURE__ */ jsxs88(DropdownMenuGroup, { children: [
            /* @__PURE__ */ jsx129(DropdownMenuLabel, { children: "Actions" }),
            /* @__PURE__ */ jsx129(DropdownMenuItem, { onClick: () => navigator.clipboard.writeText(payment.id), children: "Copy payment ID" })
          ] }),
          /* @__PURE__ */ jsx129(DropdownMenuSeparator, {}),
          /* @__PURE__ */ jsx129(DropdownMenuGroup, { children: /* @__PURE__ */ jsx129(DropdownMenuItem, { render: /* @__PURE__ */ jsx129("a", { href: `mailto:${payment.email}` }), children: "Email customer" }) })
        ] })
      ] });
    }
  })
]);
function DataTableDemo({
  data = examplePayments,
  className,
  sorting: controlledSorting,
  onSortingChange,
  columnFilters: controlledFilters,
  onColumnFiltersChange,
  columnVisibility: controlledVisibility,
  onColumnVisibilityChange,
  rowSelection: controlledSelection,
  onRowSelectionChange,
  pagination: controlledPagination,
  onPaginationChange,
  ...props
}) {
  const cm = useCadenceMotion();
  const [sorting, setSorting] = React9.useState([]);
  const [columnFilters, setColumnFilters] = React9.useState([]);
  const [columnVisibility, setColumnVisibility] = React9.useState({});
  const [rowSelection, setRowSelection] = React9.useState({});
  const [pagination, setPagination] = React9.useState({ pageIndex: 0, pageSize: 10 });
  const table = useTable({
    features,
    data,
    columns,
    getRowId: (payment) => payment.id,
    onSortingChange: onSortingChange ?? setSorting,
    onColumnFiltersChange: onColumnFiltersChange ?? setColumnFilters,
    onColumnVisibilityChange: onColumnVisibilityChange ?? setColumnVisibility,
    onRowSelectionChange: onRowSelectionChange ?? setRowSelection,
    onPaginationChange: onPaginationChange ?? setPagination,
    state: {
      sorting: controlledSorting ?? sorting,
      columnFilters: controlledFilters ?? columnFilters,
      columnVisibility: controlledVisibility ?? columnVisibility,
      rowSelection: controlledSelection ?? rowSelection,
      pagination: controlledPagination ?? pagination
    }
  });
  return /* @__PURE__ */ jsxs88("div", { "data-slot": "data-table", "data-motion": cm.mode, className: cn("w-full min-w-0", className), ...props, children: [
    /* @__PURE__ */ jsxs88("div", { className: "flex items-center gap-2 py-4", children: [
      /* @__PURE__ */ jsx129(
        Input,
        {
          "aria-label": "Filter emails",
          placeholder: "Filter emails...",
          value: table.getColumn("email")?.getFilterValue() ?? "",
          onChange: (event) => table.getColumn("email")?.setFilterValue(event.target.value),
          className: "min-w-0 max-w-sm"
        }
      ),
      /* @__PURE__ */ jsxs88(DropdownMenu, { children: [
        /* @__PURE__ */ jsxs88(DropdownMenuTrigger, { render: /* @__PURE__ */ jsx129(Button, { variant: "outline", className: "ml-auto" }), children: [
          "Columns ",
          /* @__PURE__ */ jsx129(ChevronDown2, {})
        ] }),
        /* @__PURE__ */ jsx129(DropdownMenuContent, { align: "end", className: "w-44", children: /* @__PURE__ */ jsx129(DropdownMenuGroup, { children: table.getAllColumns().filter((column) => column.getCanHide()).map((column) => {
          return /* @__PURE__ */ jsx129(
            DropdownMenuCheckboxItem,
            {
              className: "capitalize",
              checked: column.getIsVisible(),
              onCheckedChange: (value) => column.toggleVisibility(!!value),
              children: column.id
            },
            column.id
          );
        }) }) })
      ] })
    ] }),
    /* @__PURE__ */ jsx129("div", { className: "overflow-hidden rounded-md border", children: /* @__PURE__ */ jsxs88(Table, { "aria-label": "Payments", tabIndex: 0, className: "focus-visible:outline-2 focus-visible:outline-ring", children: [
      /* @__PURE__ */ jsx129(TableHeader, { children: table.getHeaderGroups().map((headerGroup) => /* @__PURE__ */ jsx129(TableRow, { children: headerGroup.headers.map((header) => {
        return /* @__PURE__ */ jsx129(
          TableHead,
          {
            scope: "col",
            "aria-sort": header.column.getIsSorted() === "asc" ? "ascending" : header.column.getIsSorted() === "desc" ? "descending" : void 0,
            children: header.isPlaceholder ? null : /* @__PURE__ */ jsx129(table.FlexRender, { header })
          },
          header.id
        );
      }) }, headerGroup.id)) }),
      /* @__PURE__ */ jsx129(TableBody, { children: table.getRowModel().rows?.length ? table.getRowModel().rows.map((row) => /* @__PURE__ */ jsx129(TableRow, { "data-state": row.getIsSelected() && "selected", children: row.getVisibleCells().map((cell) => /* @__PURE__ */ jsx129(TableCell, { children: /* @__PURE__ */ jsx129(table.FlexRender, { cell }) }, cell.id)) }, row.id)) : /* @__PURE__ */ jsx129(TableRow, { children: /* @__PURE__ */ jsx129(TableCell, { colSpan: table.getVisibleLeafColumns().length, className: "h-24 text-center", children: "No results." }) }) })
    ] }) }),
    /* @__PURE__ */ jsxs88("div", { className: "flex flex-wrap items-center justify-end gap-2 py-4", children: [
      /* @__PURE__ */ jsxs88("div", { role: "status", className: "min-w-36 flex-1 text-sm text-muted-foreground", children: [
        table.getFilteredSelectedRowModel().rows.length,
        " of ",
        table.getFilteredRowModel().rows.length,
        " row(s) selected."
      ] }),
      /* @__PURE__ */ jsxs88("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsx129(
          Button,
          {
            variant: "outline",
            size: "sm",
            onClick: () => table.previousPage(),
            disabled: !table.getCanPreviousPage(),
            children: "Previous"
          }
        ),
        /* @__PURE__ */ jsx129(Button, { variant: "outline", size: "sm", onClick: () => table.nextPage(), disabled: !table.getCanNextPage(), children: "Next" })
      ] })
    ] })
  ] });
}

// components/site/previews/data-table.tsx
import { jsx as jsx130, jsxs as jsxs89 } from "react/jsx-runtime";
var payments = Array.from({ length: 23 }, (_, i) => ({
  id: `payment-${i + 1}`,
  email: `person${String(i + 1).padStart(2, "0")}@example.com`,
  amount: (i + 1) * 23,
  status: i % 3 === 0 ? "processing" : "success"
}));
function DataTablePreview() {
  const [mode, setMode] = useState36("full");
  const [sorting, setSorting] = useState36([]);
  const [columnFilters, setColumnFilters] = useState36([]);
  const [columnVisibility, setColumnVisibility] = useState36({});
  const [rowSelection, setRowSelection] = useState36({});
  const [pagination, setPagination] = useState36({ pageIndex: 0, pageSize: 10 });
  const [updated, setUpdated] = useState36(false);
  return /* @__PURE__ */ jsxs89("div", { className: "w-full min-w-0", children: [
    /* @__PURE__ */ jsxs89("div", { className: "flex flex-wrap items-center gap-2 text-sm", children: [
      /* @__PURE__ */ jsxs89("label", { children: [
        "Table motion",
        " ",
        /* @__PURE__ */ jsxs89(
          "select",
          {
            "aria-label": "Table motion",
            value: mode,
            onChange: (e) => setMode(e.target.value),
            className: "rounded border bg-background p-1",
            children: [
              /* @__PURE__ */ jsx130("option", { value: "full", children: "full" }),
              /* @__PURE__ */ jsx130("option", { value: "reduced", children: "reduced" }),
              /* @__PURE__ */ jsx130("option", { value: "none", children: "none" })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxs89("label", { children: [
        "Rows per page",
        " ",
        /* @__PURE__ */ jsxs89(
          "select",
          {
            "aria-label": "Rows per page",
            value: pagination.pageSize,
            onChange: (e) => setPagination({ pageIndex: 0, pageSize: Number(e.target.value) }),
            className: "rounded border bg-background p-1",
            children: [
              /* @__PURE__ */ jsx130("option", { value: "5", children: "5" }),
              /* @__PURE__ */ jsx130("option", { value: "10", children: "10" }),
              /* @__PURE__ */ jsx130("option", { value: "20", children: "20" })
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsx130(
        "button",
        {
          type: "button",
          className: "rounded border px-2 py-1",
          onClick: () => {
            setSorting([]);
            setColumnFilters([]);
            setColumnVisibility({});
            setRowSelection({});
            setPagination({ pageIndex: 0, pageSize: 10 });
          },
          children: "Reset table"
        }
      ),
      /* @__PURE__ */ jsx130("button", { type: "button", className: "rounded border px-2 py-1", onClick: () => setUpdated((value) => !value), children: "Update first payment" })
    ] }),
    /* @__PURE__ */ jsx130(CadenceProvider, { mode, children: /* @__PURE__ */ jsx130(
      DataTableDemo,
      {
        data: updated ? payments.map((payment, i) => i === 0 ? { ...payment, amount: 999 } : payment) : payments,
        sorting,
        onSortingChange: setSorting,
        columnFilters,
        onColumnFiltersChange: setColumnFilters,
        columnVisibility,
        onColumnVisibilityChange: setColumnVisibility,
        rowSelection,
        onRowSelectionChange: setRowSelection,
        pagination,
        onPaginationChange: setPagination
      }
    ) })
  ] });
}

// components/site/previews/sidebar.tsx
import { Home, Inbox, Settings } from "lucide-react";
import { useState as useState39 } from "react";

// registry/cadence/sidebar/index.tsx
import { mergeProps as mergeProps5 } from "@base-ui/react/merge-props";
import { useRender as useRender7 } from "@base-ui/react/use-render";
import { cva as cva13 } from "class-variance-authority";
import { PanelLeftIcon } from "lucide-react";
import { animate as animate3, useMotionValue as useMotionValue3 } from "motion/react";
import * as React11 from "react";

// registry/cadence/lib/hooks/use-mobile.ts
import * as React10 from "react";
var MOBILE_BREAKPOINT = 768;
function useIsMobile() {
  const [isMobile, setIsMobile] = React10.useState(void 0);
  React10.useEffect(() => {
    const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`);
    const onChange = () => {
      setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
    };
    mql.addEventListener("change", onChange);
    setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
    return () => mql.removeEventListener("change", onChange);
  }, []);
  return !!isMobile;
}

// registry/cadence/sidebar/index.tsx
import { jsx as jsx131, jsxs as jsxs90 } from "react/jsx-runtime";
var SIDEBAR_COOKIE_NAME = "sidebar_state";
var SIDEBAR_COOKIE_MAX_AGE = 60 * 60 * 24 * 7;
var SIDEBAR_WIDTH = "16rem";
var SIDEBAR_WIDTH_MOBILE = "18rem";
var SIDEBAR_WIDTH_ICON = "3rem";
var SIDEBAR_KEYBOARD_SHORTCUT = "b";
var SidebarContext = React11.createContext(null);
function useSidebar() {
  const context = React11.useContext(SidebarContext);
  if (!context) {
    throw new Error("useSidebar must be used within a SidebarProvider.");
  }
  return context;
}
function SidebarProvider({
  defaultOpen = true,
  open: openProp,
  onOpenChange: setOpenProp,
  className,
  style,
  children,
  ...props
}) {
  const isMobile = useIsMobile();
  const [openMobile, setOpenMobile] = React11.useState(false);
  const [_open, _setOpen] = React11.useState(defaultOpen);
  const open = openProp ?? _open;
  const setOpen = React11.useCallback(
    (value) => {
      const openState = typeof value === "function" ? value(open) : value;
      if (setOpenProp) {
        setOpenProp(openState);
      } else {
        _setOpen(openState);
      }
      document.cookie = `${SIDEBAR_COOKIE_NAME}=${openState}; path=/; max-age=${SIDEBAR_COOKIE_MAX_AGE}`;
    },
    [setOpenProp, open]
  );
  const toggleSidebar = React11.useCallback(() => {
    return isMobile ? setOpenMobile((open2) => !open2) : setOpen((open2) => !open2);
  }, [isMobile, setOpen]);
  React11.useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key === SIDEBAR_KEYBOARD_SHORTCUT && (event.metaKey || event.ctrlKey)) {
        event.preventDefault();
        toggleSidebar();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [toggleSidebar]);
  const state = open ? "expanded" : "collapsed";
  const contextValue = React11.useMemo(
    () => ({
      state,
      open,
      setOpen,
      isMobile,
      openMobile,
      setOpenMobile,
      toggleSidebar
    }),
    [state, open, setOpen, isMobile, openMobile, toggleSidebar]
  );
  return /* @__PURE__ */ jsx131(SidebarContext.Provider, { value: contextValue, children: /* @__PURE__ */ jsx131(
    "div",
    {
      "data-slot": "sidebar-wrapper",
      style: {
        "--sidebar-width": SIDEBAR_WIDTH,
        "--sidebar-width-icon": SIDEBAR_WIDTH_ICON,
        ...style
      },
      className: cn("group/sidebar-wrapper flex min-h-svh w-full has-data-[variant=inset]:bg-sidebar", className),
      ...props,
      children
    }
  ) });
}
function Sidebar2({
  side = "left",
  variant = "sidebar",
  collapsible = "offcanvas",
  className,
  children,
  dir,
  ref,
  style,
  ...props
}) {
  const { isMobile, state, openMobile, setOpenMobile } = useSidebar();
  const cm = useCadenceMotion();
  const offcanvas = state === "collapsed" && collapsible === "offcanvas";
  const node = React11.useRef(null);
  const progress = useMotionValue3(offcanvas ? side === "left" ? -100 : 100 : 0);
  const mergedRef = React11.useCallback(
    (element) => {
      node.current = element;
      const cleanup = typeof ref === "function" ? ref(element) : void 0;
      if (ref && typeof ref !== "function") ref.current = element;
      return () => {
        node.current = null;
        if (typeof cleanup === "function") cleanup();
        else if (typeof ref === "function") ref(null);
        else if (ref) ref.current = null;
      };
    },
    [ref]
  );
  const target = !cm.reduced && offcanvas ? side === "left" ? -100 : 100 : 0;
  const transition = cm.transition("layout.move");
  React11.useLayoutEffect(() => {
    const element = node.current;
    if (!element || isMobile || collapsible === "none" || style?.transform !== void 0) return;
    let active = true;
    const write = (value) => {
      if (!active) return;
      element.style.transform = value === 0 ? "none" : `translateX(${value}%)`;
    };
    if (cm.reduced || transition.duration === 0) {
      const resting = cm.reduced ? 0 : target;
      progress.jump(resting);
      write(resting);
      return;
    }
    write(progress.get());
    const controls = animate3(progress, target, { ...transition, onUpdate: write });
    return () => {
      active = false;
      controls.stop();
      progress.stop();
    };
  }, [target, cm.mode, cm.timeScale, cm.reduced, isMobile, collapsible, style?.transform]);
  if (collapsible === "none") {
    return /* @__PURE__ */ jsx131(
      "div",
      {
        "data-slot": "sidebar",
        ref,
        dir,
        style,
        className: cn("flex h-full w-(--sidebar-width) flex-col bg-sidebar text-sidebar-foreground", className),
        ...props,
        children
      }
    );
  }
  if (isMobile) {
    return /* @__PURE__ */ jsx131(Sheet, { open: openMobile, onOpenChange: setOpenMobile, children: /* @__PURE__ */ jsxs90(
      SheetContent,
      {
        ref,
        dir,
        "data-sidebar": "sidebar",
        "data-slot": "sidebar",
        "data-mobile": "true",
        className: cn("w-(--sidebar-width) bg-sidebar p-0 text-sidebar-foreground [&>button]:hidden", className),
        style: {
          "--sidebar-width": SIDEBAR_WIDTH_MOBILE,
          ...style
        },
        side,
        ...props,
        children: [
          /* @__PURE__ */ jsxs90(SheetHeader, { className: "sr-only", children: [
            /* @__PURE__ */ jsx131(SheetTitle, { children: "Sidebar" }),
            /* @__PURE__ */ jsx131(SheetDescription, { children: "Displays the mobile sidebar." })
          ] }),
          /* @__PURE__ */ jsx131("div", { className: "flex h-full w-full flex-col", children })
        ]
      }
    ) });
  }
  return /* @__PURE__ */ jsxs90(
    "div",
    {
      className: "group peer hidden text-sidebar-foreground md:block",
      "data-state": state,
      "data-collapsible": state === "collapsed" ? collapsible : "",
      "data-variant": variant,
      "data-side": side,
      "data-slot": "sidebar",
      children: [
        /* @__PURE__ */ jsx131(
          "div",
          {
            "data-slot": "sidebar-gap",
            className: cn(
              "cn-sidebar-gap relative w-(--sidebar-width) bg-transparent",
              "group-data-[collapsible=offcanvas]:w-0",
              "group-data-[side=right]:rotate-180",
              variant === "floating" || variant === "inset" ? "group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+(--spacing(4)))]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon)"
            )
          }
        ),
        /* @__PURE__ */ jsx131(
          "div",
          {
            ref: mergedRef,
            dir,
            style: { transform: cm.reduced || progress.get() === 0 ? "none" : `translateX(${progress.get()}%)`, ...style },
            "data-slot": "sidebar-container",
            "data-motion": cm.mode,
            inert: offcanvas || void 0,
            "data-side": side,
            className: cn(
              "fixed inset-y-0 z-10 hidden h-svh w-(--sidebar-width) data-[side=left]:left-0 data-[side=right]:right-0 md:flex",
              cm.reduced && "data-[side=left]:group-data-[collapsible=offcanvas]:left-[calc(var(--sidebar-width)*-1)] data-[side=right]:group-data-[collapsible=offcanvas]:right-[calc(var(--sidebar-width)*-1)]",
              // Adjust the padding for floating and inset variants.
              variant === "floating" || variant === "inset" ? "p-2 group-data-[collapsible=icon]:w-[calc(var(--sidebar-width-icon)+(--spacing(4))+2px)]" : "group-data-[collapsible=icon]:w-(--sidebar-width-icon) group-data-[side=left]:border-r group-data-[side=right]:border-l",
              className
            ),
            ...props,
            children: /* @__PURE__ */ jsx131(
              "div",
              {
                "data-sidebar": "sidebar",
                "data-slot": "sidebar-inner",
                className: "flex size-full flex-col bg-sidebar group-data-[variant=floating]:rounded-lg group-data-[variant=floating]:border group-data-[variant=floating]:border-sidebar-border group-data-[variant=floating]:shadow-sm",
                children
              }
            )
          }
        )
      ]
    }
  );
}
function SidebarTrigger({ className, onClick, ...props }) {
  const { toggleSidebar } = useSidebar();
  return /* @__PURE__ */ jsxs90(
    Button,
    {
      "data-sidebar": "trigger",
      "data-slot": "sidebar-trigger",
      variant: "ghost",
      size: "icon-sm",
      className: (state) => cn("size-7", typeof className === "function" ? className(state) : className),
      onClick: (event) => {
        onClick?.(event);
        toggleSidebar();
      },
      ...props,
      children: [
        /* @__PURE__ */ jsx131(PanelLeftIcon, { "aria-hidden": "true" }),
        /* @__PURE__ */ jsx131("span", { className: "sr-only", children: "Toggle Sidebar" })
      ]
    }
  );
}
function SidebarRail({ className, ...props }) {
  const { toggleSidebar } = useSidebar();
  return /* @__PURE__ */ jsx131(
    "button",
    {
      "data-sidebar": "rail",
      "data-slot": "sidebar-rail",
      "aria-label": "Toggle Sidebar",
      tabIndex: -1,
      onClick: toggleSidebar,
      title: "Toggle Sidebar",
      className: cn(
        "absolute inset-y-0 z-20 hidden w-4 -translate-x-1/2 group-data-[side=left]:-right-4 group-data-[side=right]:left-0 after:absolute after:inset-y-0 after:left-1/2 after:w-[2px] hover:after:bg-sidebar-border sm:flex",
        "in-data-[side=left]:cursor-w-resize in-data-[side=right]:cursor-e-resize",
        "[[data-side=left][data-state=collapsed]_&]:cursor-e-resize [[data-side=right][data-state=collapsed]_&]:cursor-w-resize",
        "group-data-[collapsible=offcanvas]:translate-x-0 group-data-[collapsible=offcanvas]:after:left-full hover:group-data-[collapsible=offcanvas]:bg-sidebar",
        "[[data-side=left][data-collapsible=offcanvas]_&]:-right-2",
        "[[data-side=right][data-collapsible=offcanvas]_&]:-left-2",
        className
      ),
      ...props
    }
  );
}
function SidebarInput({ className, ...props }) {
  return /* @__PURE__ */ jsx131(
    Input,
    {
      "data-slot": "sidebar-input",
      "data-sidebar": "input",
      className: (state) => cn("h-8 w-full bg-background shadow-none", typeof className === "function" ? className(state) : className),
      ...props
    }
  );
}
function SidebarHeader({ className, ...props }) {
  return /* @__PURE__ */ jsx131(
    "div",
    {
      "data-slot": "sidebar-header",
      "data-sidebar": "header",
      className: cn("flex flex-col gap-2 p-2", className),
      ...props
    }
  );
}
function SidebarFooter({ className, ...props }) {
  return /* @__PURE__ */ jsx131(
    "div",
    {
      "data-slot": "sidebar-footer",
      "data-sidebar": "footer",
      className: cn("flex flex-col gap-2 p-2", className),
      ...props
    }
  );
}
function SidebarContent({ className, ...props }) {
  return /* @__PURE__ */ jsx131(
    "div",
    {
      "data-slot": "sidebar-content",
      "data-sidebar": "content",
      className: cn(
        "flex min-h-0 flex-1 flex-col gap-2 overflow-auto group-data-[collapsible=icon]:overflow-hidden",
        className
      ),
      ...props
    }
  );
}
function SidebarGroup({ className, ...props }) {
  return /* @__PURE__ */ jsx131(
    "div",
    {
      "data-slot": "sidebar-group",
      "data-sidebar": "group",
      className: cn("relative flex w-full min-w-0 flex-col p-2", className),
      ...props
    }
  );
}
function SidebarGroupLabel({
  className,
  render,
  ...props
}) {
  return useRender7({
    defaultTagName: "div",
    props: mergeProps5(
      {
        className: cn(
          "flex h-8 shrink-0 items-center rounded-md px-2 text-xs font-medium text-sidebar-foreground/70 ring-sidebar-ring outline-hidden focus-visible:ring-2 [&>svg]:size-4 [&>svg]:shrink-0",
          "group-data-[collapsible=icon]:-mt-8 group-data-[collapsible=icon]:opacity-0",
          className
        )
      },
      props
    ),
    render,
    state: {
      slot: "sidebar-group-label",
      sidebar: "group-label"
    }
  });
}
function SidebarMenu({ className, ...props }) {
  return /* @__PURE__ */ jsx131(
    "ul",
    {
      "data-slot": "sidebar-menu",
      "data-sidebar": "menu",
      className: cn("flex w-full min-w-0 flex-col gap-1", className),
      ...props
    }
  );
}
function SidebarMenuItem({ className, ...props }) {
  return /* @__PURE__ */ jsx131(
    "li",
    {
      "data-slot": "sidebar-menu-item",
      "data-sidebar": "menu-item",
      className: cn("group/menu-item relative", className),
      ...props
    }
  );
}
var sidebarMenuButtonVariants = cva13(
  "peer/menu-button flex w-full items-center gap-2 overflow-hidden rounded-md p-2 text-left text-sm ring-sidebar-ring outline-hidden group-has-data-[sidebar=menu-action]/menu-item:pr-8 group-data-[collapsible=icon]:size-8! group-data-[collapsible=icon]:p-2! hover:bg-sidebar-accent hover:text-sidebar-accent-foreground focus-visible:ring-2 active:bg-sidebar-accent active:text-sidebar-accent-foreground disabled:pointer-events-none disabled:opacity-50 aria-disabled:pointer-events-none aria-disabled:opacity-50 data-[active=true]:bg-sidebar-accent data-[active=true]:font-medium data-[active=true]:text-sidebar-accent-foreground data-[state=open]:hover:bg-sidebar-accent data-[state=open]:hover:text-sidebar-accent-foreground [&>span:last-child]:truncate [&>svg]:size-4 [&>svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "hover:bg-sidebar-accent hover:text-sidebar-accent-foreground",
        outline: "bg-background shadow-[0_0_0_1px_var(--sidebar-border,var(--border))] hover:bg-sidebar-accent hover:text-sidebar-accent-foreground hover:shadow-[0_0_0_1px_var(--sidebar-accent)]"
      },
      size: {
        default: "h-8 text-sm",
        sm: "h-7 text-xs",
        lg: "h-12 text-sm group-data-[collapsible=icon]:p-0!"
      }
    },
    defaultVariants: {
      variant: "default",
      size: "default"
    }
  }
);
function SidebarMenuButton({
  render,
  isActive: isActive2 = false,
  variant = "default",
  size = "default",
  tooltip,
  className,
  ...props
}) {
  const { isMobile, state } = useSidebar();
  const comp = useRender7({
    defaultTagName: "button",
    props: mergeProps5(
      {
        className: cn(sidebarMenuButtonVariants({ variant, size }), className)
      },
      props
    ),
    render: !tooltip ? render : /* @__PURE__ */ jsx131(TooltipTrigger, { render }),
    state: {
      slot: "sidebar-menu-button",
      sidebar: "menu-button",
      size,
      active: isActive2
    }
  });
  if (!tooltip) {
    return comp;
  }
  if (typeof tooltip === "string") {
    tooltip = {
      children: tooltip
    };
  }
  return /* @__PURE__ */ jsxs90(Tooltip, { disabled: tooltip.hidden ?? (state !== "collapsed" || isMobile), children: [
    comp,
    /* @__PURE__ */ jsx131(TooltipContent, { side: "right", align: "center", hidden: state !== "collapsed" || isMobile, ...tooltip })
  ] });
}

// components/site/previews/sidebar.tsx
import { Fragment as Fragment38, jsx as jsx132, jsxs as jsxs91 } from "react/jsx-runtime";
var previewVariantOptions30 = ["sidebar", "floating", "inset"];
function Controls() {
  const { state, openMobile, setOpen, setOpenMobile } = useSidebar();
  return /* @__PURE__ */ jsxs91("div", { className: "flex flex-wrap items-center gap-2", children: [
    /* @__PURE__ */ jsx132(SidebarTrigger, {}),
    /* @__PURE__ */ jsx132("button", { className: "rounded-md border px-2 py-1 text-sm", type: "button", onClick: () => setOpen(true), children: "Expand" }),
    /* @__PURE__ */ jsx132("button", { className: "rounded-md border px-2 py-1 text-sm", type: "button", onClick: () => setOpen(false), children: "Collapse" }),
    /* @__PURE__ */ jsx132("button", { className: "rounded-md border px-2 py-1 text-sm", type: "button", onClick: () => setOpenMobile(false), children: "Close mobile" }),
    /* @__PURE__ */ jsxs91("output", { "data-testid": "sidebar-state", children: [
      state,
      " / ",
      openMobile ? "mobile open" : "mobile closed"
    ] })
  ] });
}
function SidebarPreview() {
  const { control, choose, select: selectPreviewVariant } = usePreviewVariant("Sidebar", previewVariantOptions30);
  const [mode, setMode] = useState39("full");
  const [open, setOpen] = useState39(true);
  const [side, setSide] = useState39("left");
  const [collapsible, setCollapsible] = useState39("offcanvas");
  const [variant, setVariant] = useState39("sidebar");
  return /* @__PURE__ */ jsxs91(Fragment38, { children: [
    control,
    /* @__PURE__ */ jsxs91("div", { className: "grid w-full min-w-0 gap-4", children: [
      /* @__PURE__ */ jsxs91("div", { className: "flex flex-wrap gap-3 text-sm", children: [
        /* @__PURE__ */ jsxs91("label", { children: [
          "Panel motion",
          " ",
          /* @__PURE__ */ jsx132("select", { "aria-label": "Panel motion", value: mode, onChange: (e) => setMode(e.target.value), children: ["full", "reduced", "none"].map((v) => /* @__PURE__ */ jsx132("option", { children: v }, v)) })
        ] }),
        /* @__PURE__ */ jsxs91("label", { children: [
          "Side",
          " ",
          /* @__PURE__ */ jsxs91("select", { value: side, onChange: (e) => setSide(e.target.value), children: [
            /* @__PURE__ */ jsx132("option", { children: "left" }),
            /* @__PURE__ */ jsx132("option", { children: "right" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs91("label", { children: [
          "Collapse mode",
          " ",
          /* @__PURE__ */ jsx132("select", { value: collapsible, onChange: (e) => setCollapsible(e.target.value), children: ["offcanvas", "icon", "none"].map((v) => /* @__PURE__ */ jsx132("option", { children: v }, v)) })
        ] }),
        /* @__PURE__ */ jsxs91("label", { children: [
          "Variant",
          " ",
          /* @__PURE__ */ jsx132(
            "select",
            {
              value: choose(variant),
              onChange: (e) => {
                selectPreviewVariant("all");
                setVariant(e.target.value);
              },
              children: ["sidebar", "floating", "inset"].map((v) => /* @__PURE__ */ jsx132("option", { children: v }, v))
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsx132(CadenceProvider, { mode, children: /* @__PURE__ */ jsxs91(
        SidebarProvider,
        {
          open,
          onOpenChange: setOpen,
          className: `relative isolate h-96 min-h-96 overflow-hidden rounded-lg border [transform:translateZ(0)] ${side === "right" ? "flex-row-reverse" : ""}`,
          children: [
            /* @__PURE__ */ jsxs91(Sidebar2, { side, collapsible, variant: choose(variant), className: "absolute h-full", children: [
              /* @__PURE__ */ jsxs91(SidebarHeader, { children: [
                /* @__PURE__ */ jsx132("strong", { children: "Acme workspace" }),
                /* @__PURE__ */ jsx132(SidebarInput, { "aria-label": "Search workspace", placeholder: "Search workspace" })
              ] }),
              /* @__PURE__ */ jsx132(SidebarContent, { children: /* @__PURE__ */ jsx132("nav", { "aria-label": "Workspace", children: /* @__PURE__ */ jsxs91(SidebarGroup, { children: [
                /* @__PURE__ */ jsx132(SidebarGroupLabel, { children: "Workspace" }),
                /* @__PURE__ */ jsx132(SidebarMenu, { children: [
                  [Home, "Overview"],
                  [Inbox, "Inbox"],
                  [Settings, "Settings"]
                ].map(([Icon, label2]) => /* @__PURE__ */ jsx132(SidebarMenuItem, { children: /* @__PURE__ */ jsxs91(
                  SidebarMenuButton,
                  {
                    render: /* @__PURE__ */ jsx132("a", { href: "#workspace-content" }),
                    tooltip: String(label2),
                    isActive: label2 === "Overview",
                    children: [
                      typeof Icon !== "string" && /* @__PURE__ */ jsx132(Icon, { "aria-hidden": "true" }),
                      /* @__PURE__ */ jsx132("span", { children: String(label2) })
                    ]
                  }
                ) }, String(label2))) })
              ] }) }) }),
              /* @__PURE__ */ jsx132(SidebarFooter, { children: /* @__PURE__ */ jsx132("span", { className: "truncate text-xs", children: "Acme team" }) }),
              /* @__PURE__ */ jsx132(SidebarRail, {})
            ] }),
            /* @__PURE__ */ jsxs91("div", { id: "workspace-content", className: "flex min-w-0 flex-1 flex-col gap-4 p-4", children: [
              /* @__PURE__ */ jsx132(Controls, {}),
              /* @__PURE__ */ jsx132("h3", { className: "font-medium", children: "Project overview" }),
              /* @__PURE__ */ jsx132("p", { className: "text-sm text-muted-foreground", children: "Use the toggle or Ctrl/Cmd+B. On small screens, navigation opens in a sheet." }),
              /* @__PURE__ */ jsx132(
                "input",
                {
                  className: "min-w-0 rounded border p-2",
                  "aria-label": "Workspace draft",
                  placeholder: "Draft stays during desktop toggles"
                }
              )
            ] })
          ]
        }
      ) })
    ] })
  ] });
}

// components/site/previews/date-picker.tsx
import { fr as fr2 } from "date-fns/locale";
import { useState as useState41 } from "react";

// registry/cadence/date-picker/index.tsx
import { format } from "date-fns";
import { enUS as enUS2 } from "date-fns/locale";
import { CalendarIcon } from "lucide-react";
import * as React12 from "react";
import { jsx as jsx133, jsxs as jsxs92 } from "react/jsx-runtime";
function DatePickerDemo(props) {
  const {
    mode = "single",
    value,
    defaultValue,
    onValueChange,
    calendarProps,
    label: label2 = "Choose date",
    placeholder = "Pick a date",
    disabled = false,
    open,
    defaultOpen,
    onOpenChange,
    triggerProps,
    contentProps,
    className,
    ...rootProps
  } = props;
  const [internal, setInternal] = React12.useState(defaultValue);
  const selected = Object.hasOwn(props, "value") ? value : internal;
  const cm = useCadenceMotion();
  const locale = { ...enUS2, ...calendarProps?.locale };
  const triggerClass = triggerProps?.className;
  const contentClass = contentProps?.className;
  const text = selected instanceof Date ? format(selected, "PPP", { locale }) : selected?.from ? `${format(selected.from, "PPP", { locale })}${selected.to ? ` \u2013 ${format(selected.to, "PPP", { locale })}` : ""}` : placeholder;
  function change(next) {
    if (!Object.hasOwn(props, "value")) setInternal(next);
    if (props.mode === "range") props.onValueChange?.(next);
    else props.onValueChange?.(next);
  }
  return /* @__PURE__ */ jsx133(
    "div",
    {
      "data-slot": "date-picker",
      "data-motion": cm.mode,
      className: cn("inline-flex max-w-full", className),
      ...rootProps,
      children: /* @__PURE__ */ jsxs92(Popover, { open, defaultOpen, onOpenChange, children: [
        /* @__PURE__ */ jsxs92(
          PopoverTrigger,
          {
            render: /* @__PURE__ */ jsx133(
              Button,
              {
                variant: "outline",
                ...triggerProps,
                disabled: disabled || triggerProps?.disabled,
                "data-empty": !selected,
                className: typeof triggerClass === "function" ? (state) => cn(
                  "max-w-full justify-start text-left font-normal data-[empty=true]:text-muted-foreground",
                  triggerClass(state)
                ) : cn(
                  "max-w-full justify-start text-left font-normal data-[empty=true]:text-muted-foreground",
                  triggerProps?.className
                )
              }
            ),
            children: [
              /* @__PURE__ */ jsx133(CalendarIcon, { "data-icon": "inline-start" }),
              /* @__PURE__ */ jsxs92("span", { className: "sr-only", children: [
                label2,
                ": "
              ] }),
              /* @__PURE__ */ jsx133("span", { className: "truncate", children: text })
            ]
          }
        ),
        /* @__PURE__ */ jsxs92(
          PopoverContent,
          {
            align: "start",
            ...contentProps,
            className: typeof contentClass === "function" ? (state) => cn(
              "max-h-(--available-height) w-auto max-w-(--available-width) overflow-auto p-0",
              contentClass(state)
            ) : cn(
              "max-h-(--available-height) w-auto max-w-(--available-width) overflow-auto p-0",
              contentProps?.className
            ),
            children: [
              /* @__PURE__ */ jsx133(PopoverTitle, { className: "sr-only", children: label2 }),
              mode === "range" ? /* @__PURE__ */ jsx133(
                Calendar,
                {
                  autoFocus: true,
                  numberOfMonths: 2,
                  defaultMonth: selected?.from,
                  ...calendarProps,
                  mode: "range",
                  required: false,
                  selected,
                  onSelect: change
                }
              ) : /* @__PURE__ */ jsx133(
                Calendar,
                {
                  autoFocus: true,
                  defaultMonth: selected,
                  ...calendarProps,
                  mode: "single",
                  required: false,
                  selected,
                  onSelect: change
                }
              )
            ]
          }
        )
      ] })
    }
  );
}

// components/site/previews/date-picker.tsx
import { jsx as jsx134, jsxs as jsxs93 } from "react/jsx-runtime";
function DatePickerPreview() {
  const [mode, setMode] = useState41("full");
  const [date, setDate] = useState41(new Date(2026, 10, 12));
  const [range, setRange] = useState41();
  const [french, setFrench] = useState41(false);
  return /* @__PURE__ */ jsxs93("div", { className: "flex w-full max-w-xl flex-col gap-5", children: [
    /* @__PURE__ */ jsxs93("label", { className: "flex flex-wrap items-center gap-2 text-sm", children: [
      "Picker motion",
      /* @__PURE__ */ jsxs93(
        "select",
        {
          "aria-label": "Picker motion",
          value: mode,
          onChange: (e) => setMode(e.target.value),
          className: "rounded-md border bg-background p-1",
          children: [
            /* @__PURE__ */ jsx134("option", { value: "full", children: "Full" }),
            /* @__PURE__ */ jsx134("option", { value: "reduced", children: "Reduced" }),
            /* @__PURE__ */ jsx134("option", { value: "none", children: "None" })
          ]
        }
      )
    ] }),
    /* @__PURE__ */ jsx134(CadenceProvider, { mode, timeScale: 4, children: /* @__PURE__ */ jsxs93("div", { className: "flex flex-col items-start gap-4", children: [
      /* @__PURE__ */ jsx134(
        DatePickerDemo,
        {
          label: "Appointment",
          value: date,
          onValueChange: setDate,
          calendarProps: {
            defaultMonth: new Date(2026, 10, 1),
            today: new Date(2026, 10, 1),
            disabled: new Date(2026, 10, 5),
            locale: french ? fr2 : void 0
          }
        }
      ),
      /* @__PURE__ */ jsxs93("div", { className: "flex flex-wrap gap-2", children: [
        /* @__PURE__ */ jsx134(Button, { variant: "outline", size: "sm", onClick: () => setDate(void 0), children: "Clear date" }),
        /* @__PURE__ */ jsx134(Button, { variant: "outline", size: "sm", onClick: () => setDate(new Date(2026, 10, 20)), children: "Set November 20" }),
        /* @__PURE__ */ jsx134(Button, { variant: "outline", size: "sm", onClick: () => setFrench(!french), children: "Switch language" })
      ] }),
      /* @__PURE__ */ jsx134(
        DatePickerDemo,
        {
          mode: "range",
          label: "Travel dates",
          value: range,
          onValueChange: setRange,
          calendarProps: { defaultMonth: new Date(2026, 10, 1), today: new Date(2026, 10, 1) }
        }
      ),
      /* @__PURE__ */ jsx134(
        Button,
        {
          variant: "outline",
          size: "sm",
          onClick: () => setRange({ from: new Date(2026, 10, 10), to: new Date(2026, 10, 15) }),
          children: "Apply travel preset"
        }
      ),
      /* @__PURE__ */ jsx134(DatePickerDemo, { label: "Unavailable", disabled: true }),
      /* @__PURE__ */ jsx134("output", { className: "text-sm text-muted-foreground", "aria-live": "polite", children: date ? `Selected day: ${date.getDate()}` : "No date selected" })
    ] }) })
  ] });
}

// components/site/previews/attachment.tsx
import { FileTextIcon as FileTextIcon2, XIcon as XIcon4 } from "lucide-react";
import { useState as useState42 } from "react";

// registry/cadence/attachment/index.tsx
import { mergeProps as mergeProps6 } from "@base-ui/react/merge-props";
import { useRender as useRender8 } from "@base-ui/react/use-render";
import { cva as cva14 } from "class-variance-authority";
import { jsx as jsx135 } from "react/jsx-runtime";
var attachmentVariants = cva14(
  "group/attachment relative flex w-fit max-w-full min-w-0 shrink-0 flex-wrap rounded-xl border bg-card text-card-foreground transition-colors focus-within:ring-1 focus-within:ring-ring/50 has-[>a,>button]:hover:bg-muted/50 data-[state=error]:border-destructive/30 data-[state=idle]:border-dashed",
  {
    variants: {
      size: {
        default: "gap-2 text-sm has-data-[slot=attachment-content]:px-2.5 has-data-[slot=attachment-content]:py-2 has-data-[slot=attachment-media]:p-2",
        sm: "gap-2.5 text-xs has-data-[slot=attachment-content]:px-2 has-data-[slot=attachment-content]:py-1.5 has-data-[slot=attachment-media]:p-1.5",
        xs: "gap-1.5 rounded-lg text-xs has-data-[slot=attachment-content]:px-1.5 has-data-[slot=attachment-content]:py-1 has-data-[slot=attachment-media]:p-1"
      },
      orientation: {
        horizontal: "min-w-40 items-center",
        vertical: "w-24 flex-col has-data-[slot=attachment-content]:w-30"
      }
    }
  }
);
function Attachment({
  className,
  state = "done",
  size = "default",
  orientation = "horizontal",
  ...props
}) {
  const cm = useCadenceMotion();
  return /* @__PURE__ */ jsx135(
    "div",
    {
      "data-motion": cm.mode,
      "data-slot": "attachment",
      "data-state": state,
      "data-size": size,
      "data-orientation": orientation,
      className: cn(attachmentVariants({ size, orientation }), className),
      ...props
    }
  );
}
var attachmentMediaVariants = cva14(
  "relative flex aspect-square w-10 shrink-0 items-center justify-center overflow-hidden rounded-lg bg-muted text-foreground group-data-[orientation=vertical]/attachment:w-full group-data-[size=sm]/attachment:w-8 group-data-[size=xs]/attachment:w-7 group-data-[size=xs]/attachment:rounded-md group-data-[state=error]/attachment:bg-destructive/10 group-data-[state=error]/attachment:text-destructive group-data-[orientation=vertical]/attachment:*:data-[slot=spinner]:size-6! [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 group-data-[orientation=vertical]/attachment:[&_svg:not([class*='size-'])]:size-6 group-data-[size=xs]/attachment:[&_svg:not([class*='size-'])]:size-3.5",
  {
    variants: {
      variant: {
        icon: "",
        image: "opacity-60 group-data-[state=done]/attachment:opacity-100 group-data-[state=idle]/attachment:opacity-100 *:[img]:aspect-square *:[img]:w-full *:[img]:object-cover"
      }
    },
    defaultVariants: {
      variant: "icon"
    }
  }
);
function AttachmentMedia({
  className,
  variant = "icon",
  ...props
}) {
  return /* @__PURE__ */ jsx135(
    "div",
    {
      "data-slot": "attachment-media",
      "data-variant": variant,
      className: cn(attachmentMediaVariants({ variant }), className),
      ...props
    }
  );
}
function AttachmentContent({ className, ...props }) {
  return /* @__PURE__ */ jsx135(
    "div",
    {
      "data-slot": "attachment-content",
      className: cn(
        "max-w-full min-w-0 flex-1 leading-tight group-data-[orientation=vertical]/attachment:px-1",
        className
      ),
      ...props
    }
  );
}
function AttachmentTitle({ className, ...props }) {
  const cm = useCadenceMotion();
  const pulse = cm.mode === "none" ? "animate-none" : "group-data-[state=processing]/attachment:animate-pulse group-data-[state=uploading]/attachment:animate-pulse";
  return /* @__PURE__ */ jsx135(
    "span",
    {
      "data-motion": cm.mode,
      "data-slot": "attachment-title",
      className: cn(
        "block max-w-full min-w-0 truncate font-medium",
        pulse,
        cm.reduced ? "transform-none" : void 0,
        className
      ),
      ...props
    }
  );
}
function AttachmentDescription({ className, ...props }) {
  return /* @__PURE__ */ jsx135(
    "span",
    {
      "data-slot": "attachment-description",
      className: cn(
        "mt-0.5 block min-w-0 truncate text-xs text-muted-foreground group-data-[state=error]/attachment:text-destructive/80",
        "max-w-full",
        className
      ),
      ...props
    }
  );
}
function AttachmentActions({ className, ...props }) {
  return /* @__PURE__ */ jsx135(
    "div",
    {
      "data-slot": "attachment-actions",
      className: cn(
        "relative z-20 flex shrink-0 items-center group-data-[orientation=vertical]/attachment:absolute group-data-[orientation=vertical]/attachment:top-3 group-data-[orientation=vertical]/attachment:right-3 group-data-[orientation=vertical]/attachment:gap-1",
        className
      ),
      ...props
    }
  );
}
function AttachmentAction({ className, variant, size = "icon-xs", ...props }) {
  return /* @__PURE__ */ jsx135(
    Button,
    {
      "data-slot": "attachment-action",
      variant: variant ?? "ghost",
      size,
      className: typeof className === "function" ? (state) => cn("cn-attachment-action", className(state)) : cn("cn-attachment-action", className),
      ...props
    }
  );
}
function AttachmentTrigger({ className, render, type, ...props }) {
  return useRender8({
    defaultTagName: "button",
    props: mergeProps6(
      {
        type: render ? type : type ?? "button",
        className: cn(
          "cn-attachment-trigger absolute inset-0 z-10 rounded-[inherit] outline-none focus-visible:ring-[3px] focus-visible:ring-ring/50",
          className
        )
      },
      props
    ),
    render,
    state: {
      slot: "attachment-trigger"
    }
  });
}
function AttachmentGroup({ className, ...props }) {
  return /* @__PURE__ */ jsx135(
    "div",
    {
      "data-slot": "attachment-group",
      className: cn(
        "flex min-w-0 scroll-fade-x snap-x snap-mandatory scroll-px-1 scrollbar-none gap-3 overflow-x-auto overscroll-x-contain py-1 *:data-[slot=attachment]:flex-none *:data-[slot=attachment]:snap-start",
        className
      ),
      ...props
    }
  );
}

// components/site/previews/attachment.tsx
import { Fragment as Fragment39, jsx as jsx136, jsxs as jsxs94 } from "react/jsx-runtime";
var previewVariantOptions31 = ["default", "sm", "xs"];
function AttachmentPreview() {
  const { control, choose, select: selectPreviewVariant } = usePreviewVariant("Attachment", previewVariantOptions31);
  const [mode, setMode] = useState42("full");
  const [state, setState] = useState42("uploading");
  const [size, setSize] = useState42("default");
  const [vertical, setVertical] = useState42(false);
  const [removed, setRemoved] = useState42(false);
  const [name, setName] = useState42("sales-dashboard.pdf");
  const [notice, setNotice] = useState42("Local demonstration; no file is uploaded.");
  return /* @__PURE__ */ jsxs94(Fragment39, { children: [
    control,
    /* @__PURE__ */ jsxs94("div", { className: "flex w-full min-w-0 max-w-lg flex-col gap-4", children: [
      /* @__PURE__ */ jsxs94("div", { className: "flex flex-wrap gap-3 text-sm", children: [
        /* @__PURE__ */ jsxs94("label", { children: [
          "Attachment motion",
          " ",
          /* @__PURE__ */ jsxs94(
            "select",
            {
              "aria-label": "Attachment motion",
              value: mode,
              onChange: (e) => setMode(e.target.value),
              className: "rounded border bg-background p-1",
              children: [
                /* @__PURE__ */ jsx136("option", { value: "full", children: "Full" }),
                /* @__PURE__ */ jsx136("option", { value: "reduced", children: "Reduced" }),
                /* @__PURE__ */ jsx136("option", { value: "none", children: "None" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxs94("label", { children: [
          "State",
          " ",
          /* @__PURE__ */ jsx136(
            "select",
            {
              "aria-label": "State",
              value: state,
              onChange: (e) => setState(e.target.value),
              className: "rounded border bg-background p-1",
              children: ["idle", "uploading", "processing", "error", "done"].map((s) => /* @__PURE__ */ jsx136("option", { children: s }, s))
            }
          )
        ] }),
        /* @__PURE__ */ jsxs94("label", { children: [
          "Size",
          " ",
          /* @__PURE__ */ jsxs94(
            "select",
            {
              "aria-label": "Size",
              value: choose(size),
              onChange: (e) => {
                selectPreviewVariant("all");
                setSize(e.target.value);
              },
              className: "rounded border bg-background p-1",
              children: [
                /* @__PURE__ */ jsx136("option", { children: "default" }),
                /* @__PURE__ */ jsx136("option", { children: "sm" }),
                /* @__PURE__ */ jsx136("option", { children: "xs" })
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxs94("label", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsx136("input", { type: "checkbox", checked: vertical, onChange: (e) => setVertical(e.target.checked) }),
          "Vertical"
        ] })
      ] }),
      /* @__PURE__ */ jsxs94("label", { className: "flex min-w-0 flex-col gap-2 text-sm", children: [
        "Choose a local file (name only)",
        /* @__PURE__ */ jsx136(
          "input",
          {
            type: "file",
            name: "attachment",
            className: "w-full min-w-0 text-sm",
            onChange: (e) => {
              const file = e.target.files?.[0];
              if (file) {
                setName(file.name);
                setState("idle");
                setRemoved(false);
                setNotice(`Selected ${file.name}; no upload started.`);
              }
            }
          }
        )
      ] }),
      /* @__PURE__ */ jsxs94(CadenceProvider, { mode, children: [
        !removed && /* @__PURE__ */ jsxs94(
          Attachment,
          {
            "data-testid": "live-attachment",
            state,
            size: choose(size),
            orientation: vertical ? "vertical" : "horizontal",
            "aria-busy": state === "uploading" || state === "processing",
            children: [
              /* @__PURE__ */ jsx136(AttachmentMedia, { "aria-hidden": "true", children: /* @__PURE__ */ jsx136(FileTextIcon2, {}) }),
              /* @__PURE__ */ jsxs94(AttachmentContent, { children: [
                /* @__PURE__ */ jsx136(AttachmentTitle, { title: name, children: name }),
                /* @__PURE__ */ jsx136(AttachmentDescription, { children: state === "error" ? "Upload failed \xB7 retry in your application" : `${state} \xB7 local demo` })
              ] }),
              /* @__PURE__ */ jsx136(AttachmentTrigger, { "aria-label": `Inspect ${name}`, onClick: () => setNotice(`Inspecting ${name}`) }),
              /* @__PURE__ */ jsx136(AttachmentActions, { children: /* @__PURE__ */ jsx136(
                AttachmentAction,
                {
                  "aria-label": `Remove ${name}`,
                  onClick: () => {
                    setRemoved(true);
                    setNotice(`Removed ${name}`);
                  },
                  children: /* @__PURE__ */ jsx136(XIcon4, {})
                }
              ) })
            ]
          }
        ),
        /* @__PURE__ */ jsx136(
          "button",
          {
            type: "button",
            className: "w-fit rounded border px-3 py-1 text-sm focus-visible:ring-2 focus-visible:ring-ring",
            onClick: () => {
              setRemoved(false);
              setName("sales-dashboard.pdf");
              setState("uploading");
              setNotice("Demo reset");
            },
            children: "Reset attachment"
          }
        ),
        /* @__PURE__ */ jsx136(
          AttachmentGroup,
          {
            tabIndex: 0,
            role: "group",
            "aria-label": "Reference files",
            className: "w-full focus-visible:outline-2 focus-visible:outline-ring",
            children: [
              "research-notes-with-a-very-long-name.md",
              "project-roadmap.pdf",
              "interface-reference.svg",
              "meeting-notes.txt"
            ].map((file, i) => /* @__PURE__ */ jsxs94(Attachment, { orientation: "vertical", size: choose("sm"), children: [
              /* @__PURE__ */ jsx136(AttachmentMedia, { variant: i === 2 ? "image" : "icon", children: i === 2 ? (
                // biome-ignore lint/performance/noImgElement: Native images are AttachmentMedia's public composition API.
                /* @__PURE__ */ jsx136(
                  "img",
                  {
                    alt: "Interface diagram",
                    width: 80,
                    height: 80,
                    src: "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 80 80'%3E%3Crect width='80' height='80' fill='%23d4d4d8'/%3E%3Crect x='10' y='10' width='60' height='60' rx='6' fill='%23fafafa'/%3E%3Cpath d='M20 28h40M20 40h24M20 52h32' stroke='%2352525b' stroke-width='4'/%3E%3C/svg%3E"
                  }
                )
              ) : /* @__PURE__ */ jsx136(FileTextIcon2, { "aria-hidden": "true" }) }),
              /* @__PURE__ */ jsxs94(AttachmentContent, { children: [
                /* @__PURE__ */ jsx136(AttachmentTitle, { title: file, children: file }),
                /* @__PURE__ */ jsxs94(AttachmentDescription, { children: [
                  "Reference \xB7 ",
                  i + 1,
                  " MB"
                ] })
              ] }),
              /* @__PURE__ */ jsx136(AttachmentTrigger, { render: /* @__PURE__ */ jsx136("a", { href: "#attachment-details", "aria-label": `Details for ${file}` }) })
            ] }, file))
          }
        )
      ] }),
      /* @__PURE__ */ jsx136("p", { id: "attachment-details", role: "status", className: "text-sm text-muted-foreground", children: notice })
    ] })
  ] });
}

// components/site/previews/bubble.tsx
import { useState as useState43 } from "react";

// registry/cadence/bubble/index.tsx
import { mergeProps as mergeProps7 } from "@base-ui/react/merge-props";
import { useRender as useRender9 } from "@base-ui/react/use-render";
import { cva as cva15 } from "class-variance-authority";
import { jsx as jsx137 } from "react/jsx-runtime";
function BubbleGroup({ className, ...props }) {
  return /* @__PURE__ */ jsx137("div", { "data-slot": "bubble-group", className: cn("flex min-w-0 flex-col gap-2", className), ...props });
}
var bubbleVariants = cva15(
  "group/bubble relative flex w-fit max-w-[80%] min-w-0 flex-col gap-1 group-data-[align=end]/message:self-end data-[align=end]:self-end data-[variant=ghost]:max-w-full",
  {
    variants: {
      variant: {
        default: "*:data-[slot=bubble-content]:bg-primary *:data-[slot=bubble-content]:text-primary-foreground [&>[data-slot=bubble-content]:is(button,a):hover]:bg-primary/80",
        secondary: "*:data-[slot=bubble-content]:bg-secondary *:data-[slot=bubble-content]:text-secondary-foreground [&>[data-slot=bubble-content]:is(button,a):hover]:bg-[color-mix(in_oklch,var(--secondary),var(--foreground)_5%)]",
        muted: "*:data-[slot=bubble-content]:bg-muted [&>[data-slot=bubble-content]:is(button,a):hover]:bg-[color-mix(in_oklch,var(--muted),var(--foreground)_5%)]",
        tinted: "*:data-[slot=bubble-content]:bg-[oklch(from_var(--primary)_0.93_calc(c*0.4)_h)] *:data-[slot=bubble-content]:text-foreground dark:*:data-[slot=bubble-content]:bg-[oklch(from_var(--primary)_0.3_calc(c*0.4)_h)] [&>[data-slot=bubble-content]:is(button,a):hover]:bg-[oklch(from_var(--primary)_0.88_calc(c*0.5)_h)] dark:[&>[data-slot=bubble-content]:is(button,a):hover]:bg-[oklch(from_var(--primary)_0.35_calc(c*0.5)_h)]",
        outline: "*:data-[slot=bubble-content]:border-border *:data-[slot=bubble-content]:bg-background [&>[data-slot=bubble-content]:is(button,a):hover]:bg-muted [&>[data-slot=bubble-content]:is(button,a):hover]:text-foreground dark:[&>[data-slot=bubble-content]:is(button,a):hover]:bg-input/30",
        ghost: "border-none *:data-[slot=bubble-content]:rounded-none *:data-[slot=bubble-content]:bg-transparent *:data-[slot=bubble-content]:p-0 [&>[data-slot=bubble-content]:is(button,a):hover]:bg-muted [&>[data-slot=bubble-content]:is(button,a):hover]:text-foreground dark:[&>[data-slot=bubble-content]:is(button,a):hover]:bg-muted/50",
        destructive: "*:data-[slot=bubble-content]:bg-destructive/10 *:data-[slot=bubble-content]:text-foreground *:data-[slot=bubble-content]:border-destructive/50 dark:*:data-[slot=bubble-content]:bg-destructive/20 [&>[data-slot=bubble-content]:is(button,a):hover]:bg-destructive/20 dark:[&>[data-slot=bubble-content]:is(button,a):hover]:bg-destructive/30"
      }
    },
    defaultVariants: {
      variant: "default"
    }
  }
);
function Bubble({
  variant = "default",
  align = "start",
  className,
  style,
  ...props
}) {
  const cm = useCadenceMotion();
  const clock2 = cm.transition("data.transition");
  return /* @__PURE__ */ jsx137(
    "div",
    {
      "data-motion": cm.mode,
      style: { transitionDuration: `${clock2.duration}s`, ...style },
      "data-slot": "bubble",
      "data-variant": variant,
      "data-align": align,
      className: cn(
        bubbleVariants({ variant }),
        cm.disabled ? "transition-none duration-0" : "transition-opacity ease-cadence-out starting:opacity-0",
        cm.reduced && "transform-none",
        className
      ),
      ...props
    }
  );
}
function BubbleContent({ className, render, ...props }) {
  return useRender9({
    defaultTagName: "div",
    props: mergeProps7(
      {
        className: cn(
          "w-fit max-w-full min-w-0 overflow-hidden rounded-xl border border-transparent px-3 py-2 text-sm leading-relaxed wrap-break-word group-data-[align=end]/bubble:self-end [&:is(button)]:text-left [&:is(button,a)]:transition-colors [&:is(button,a)]:outline-none [&:is(button,a)]:focus-visible:border-ring [&:is(button,a)]:focus-visible:ring-3 [&:is(button,a)]:focus-visible:ring-ring/50",
          className
        )
      },
      props
    ),
    render,
    state: {
      slot: "bubble-content"
    }
  });
}
var bubbleReactionsVariants = cva15(
  "absolute z-10 flex w-fit shrink-0 items-center justify-center gap-1 rounded-full bg-muted px-1.5 py-0.5 text-sm ring-3 ring-card has-[button]:p-0",
  {
    variants: {
      side: {
        top: "top-0 -translate-y-3/4",
        bottom: "bottom-0 translate-y-3/4"
      },
      align: {
        start: "left-3",
        end: "right-3"
      }
    },
    defaultVariants: {
      side: "bottom",
      align: "end"
    }
  }
);
function BubbleReactions({
  side = "bottom",
  align = "end",
  className,
  ...props
}) {
  return /* @__PURE__ */ jsx137(
    "div",
    {
      "data-slot": "bubble-reactions",
      "data-align": align,
      "data-side": side,
      className: cn(bubbleReactionsVariants({ side, align }), className),
      ...props
    }
  );
}

// components/site/previews/bubble.tsx
import { Fragment as Fragment40, jsx as jsx138, jsxs as jsxs95 } from "react/jsx-runtime";
var previewVariantOptions32 = ["default", "secondary", "muted", "tinted", "outline", "ghost", "destructive"];
var variants3 = ["default", "secondary", "muted", "tinted", "outline", "ghost", "destructive"];
function BubblePreview() {
  const { control, choose, select: selectPreviewVariant } = usePreviewVariant("Bubble", previewVariantOptions32);
  const [mode, setMode] = useState43("full");
  const [variant, setVariant] = useState43("muted");
  const [align, setAlign] = useState43("start");
  const [side, setSide] = useState43("bottom");
  const [reactionAlign, setReactionAlign] = useState43("end");
  const [messages, setMessages] = useState43([{ id: "initial", text: "The registry is ready." }]);
  const [liked, setLiked] = useState43(false);
  const [notice, setNotice] = useState43("Choose a reply or append local text.");
  return /* @__PURE__ */ jsxs95(Fragment40, { children: [
    control,
    /* @__PURE__ */ jsxs95("div", { className: "flex w-full min-w-0 max-w-lg flex-col gap-5", children: [
      /* @__PURE__ */ jsxs95("div", { className: "flex flex-wrap gap-3 text-sm", children: [
        /* @__PURE__ */ jsxs95("label", { children: [
          "Bubble motion",
          " ",
          /* @__PURE__ */ jsx138("select", { "aria-label": "Bubble motion", value: mode, onChange: (e) => setMode(e.target.value), children: ["full", "reduced", "none"].map((v) => /* @__PURE__ */ jsx138("option", { children: v }, v)) })
        ] }),
        /* @__PURE__ */ jsxs95("label", { children: [
          "Variant",
          " ",
          /* @__PURE__ */ jsx138(
            "select",
            {
              "aria-label": "Variant",
              value: choose(variant),
              onChange: (e) => {
                selectPreviewVariant("all");
                setVariant(e.target.value);
              },
              children: variants3.map((v) => /* @__PURE__ */ jsx138("option", { children: v }, v))
            }
          )
        ] }),
        /* @__PURE__ */ jsxs95("label", { children: [
          "Alignment",
          " ",
          /* @__PURE__ */ jsxs95("select", { "aria-label": "Alignment", value: align, onChange: (e) => setAlign(e.target.value), children: [
            /* @__PURE__ */ jsx138("option", { children: "start" }),
            /* @__PURE__ */ jsx138("option", { children: "end" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs95("label", { children: [
          "Reaction side",
          " ",
          /* @__PURE__ */ jsxs95("select", { "aria-label": "Reaction side", value: side, onChange: (e) => setSide(e.target.value), children: [
            /* @__PURE__ */ jsx138("option", { children: "bottom" }),
            /* @__PURE__ */ jsx138("option", { children: "top" })
          ] })
        ] }),
        /* @__PURE__ */ jsxs95("label", { children: [
          "Reaction alignment",
          " ",
          /* @__PURE__ */ jsxs95(
            "select",
            {
              "aria-label": "Reaction alignment",
              value: reactionAlign,
              onChange: (e) => setReactionAlign(e.target.value),
              children: [
                /* @__PURE__ */ jsx138("option", { children: "end" }),
                /* @__PURE__ */ jsx138("option", { children: "start" })
              ]
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxs95("div", { className: "flex flex-wrap gap-2", children: [
        /* @__PURE__ */ jsx138(
          "button",
          {
            type: "button",
            className: "rounded border px-3 py-1 text-sm",
            onClick: () => setMessages((m) => [...m, { id: crypto.randomUUID(), text: `Reply ${m.length + 1}: ready for review.` }]),
            children: "Add reply"
          }
        ),
        /* @__PURE__ */ jsx138(
          "button",
          {
            type: "button",
            className: "rounded border px-3 py-1 text-sm",
            onClick: () => setMessages((m) => m.map((v, i) => i === 0 ? { ...v, text: `${v.text} Another local chunk.` } : v)),
            children: "Append text"
          }
        )
      ] }),
      /* @__PURE__ */ jsx138(CadenceProvider, { mode, timeScale: 4, children: /* @__PURE__ */ jsxs95(BubbleGroup, { role: "group", "aria-label": "Local conversation", className: "gap-8 py-5", children: [
        messages.map((message, i) => /* @__PURE__ */ jsxs95(Bubble, { variant: choose(variant), align, "data-testid": `reply-${i}`, children: [
          /* @__PURE__ */ jsx138(BubbleContent, { children: choose(variant) === "destructive" ? `Delivery failed: ${message.text}` : message.text }),
          i === 0 && /* @__PURE__ */ jsx138(BubbleReactions, { side, align: reactionAlign, children: /* @__PURE__ */ jsxs95(
            "button",
            {
              type: "button",
              className: "rounded-full px-2 py-1 outline-none focus-visible:ring-2 focus-visible:ring-ring",
              "aria-pressed": liked,
              "aria-label": "Thumbs up",
              onClick: () => setLiked((v) => !v),
              children: [
                "\u{1F44D} ",
                liked ? 1 : 0
              ]
            }
          ) })
        ] }, message.id)),
        /* @__PURE__ */ jsx138(Bubble, { align: "end", variant: choose("default"), children: /* @__PURE__ */ jsx138(BubbleContent, { render: /* @__PURE__ */ jsx138("button", { type: "button", onClick: () => setNotice("Reply selected.") }), children: "Show the review checklist" }) }),
        /* @__PURE__ */ jsx138(Bubble, { variant: choose("outline"), children: /* @__PURE__ */ jsx138(BubbleContent, { render: /* @__PURE__ */ jsx138("a", { href: "#bubble-details" }), children: "Read bubble details" }) }),
        /* @__PURE__ */ jsx138(Bubble, { variant: choose("ghost"), children: /* @__PURE__ */ jsx138(BubbleContent, { children: "Long content wraps: extremely-long-continuous-conversation-content-that-must-fit-within-a-small-mobile-viewport-without-overflow." }) })
      ] }) }),
      /* @__PURE__ */ jsx138("p", { role: "status", className: "text-sm text-muted-foreground", children: notice }),
      /* @__PURE__ */ jsx138("p", { id: "bubble-details", className: "text-sm text-muted-foreground", children: "Local text only. Your application owns transport, message IDs, cancellation, retry and scroll position." })
    ] })
  ] });
}

// .cache/button-route-prototype/all-previews.jsx
var previews = { "button": ButtonPreview, "badge": BadgePreview, "kbd": KbdPreview, "separator": SeparatorPreview, "label": LabelPreview, "input": InputPreview, "textarea": TextareaPreview, "card": CardPreview, "aspect-ratio": AspectRatioPreview, "avatar": AvatarPreview, "skeleton": SkeletonPreview, "dialog": DialogPreview, "alert": AlertPreview, "empty": EmptyPreview, "item": ItemPreview, "field": FieldPreview, "button-group": ButtonGroupPreview, "input-group": InputGroupPreview, "breadcrumb": BreadcrumbPreview, "pagination": PaginationPreview, "spinner": SpinnerPreview, "checkbox": CheckboxPreview, "radio-group": RadioGroupPreview, "switch": SwitchPreview, "slider": SliderPreview, "toggle": TogglePreview, "toggle-group": ToggleGroupPreview, "input-otp": InputOtpPreview, "progress": ProgressPreview, "alert-dialog": AlertDialogPreview, "popover": PopoverPreview, "tooltip": TooltipPreview, "hover-card": HoverCardPreview, "sheet": SheetPreview, "drawer": DrawerPreview, "select": SelectPreview, "combobox": ComboboxPreview, "dropdown-menu": DropdownMenuPreview, "context-menu": ContextMenuPreview, "menubar": MenubarPreview, "code-block": CodeBlockPreview, "command": CommandPreview, "toast": ToastPreview, "accordion": AccordionPreview, "collapsible": CollapsiblePreview, "tabs": TabsPreview, "table": TablePreview, "carousel": CarouselPreview, "scroll-area": ScrollAreaPreview, "chart": ChartPreview, "calendar": CalendarPreview, "navigation-menu": NavigationMenuPreview, "resizable": ResizablePreview, "data-table": DataTablePreview, "sidebar": SidebarPreview, "date-picker": DatePickerPreview, "attachment": AttachmentPreview, "bubble": BubblePreview };

// components/site/preview.tsx
import { jsx as jsx139 } from "react/jsx-runtime";
function Preview({ id }) {
  const Component = previews[id];
  if (!Component) {
    return /* @__PURE__ */ jsx139("p", { className: "text-sm text-muted-foreground", children: "Preview coming soon." });
  }
  return /* @__PURE__ */ jsx139(Component, {});
}
function PreviewFrame({ id }) {
  const resolved = useCadenceMotion().mode;
  return /* @__PURE__ */ jsx139("div", { "data-preview": id, "data-preview-motion": resolved, className: "rounded-xl border border-border bg-background", children: /* @__PURE__ */ jsx139(MeasuredHeight, { className: "grid min-h-80 place-items-center p-6", children: /* @__PURE__ */ jsx139(Preview, { id }) }) });
}

// app/(site)/components/[id]/page.tsx
import { jsx as jsx140, jsxs as jsxs96 } from "react/jsx-runtime";
async function generateMetadata({ params }) {
  const { id } = await params;
  const doc = await getComponent(id);
  if (!doc) return {};
  return { title: doc.title, description: doc.description };
}
async function ComponentPage({ params }) {
  const { id } = await params;
  const doc = await getComponent(id);
  if (!doc) notFound();
  const components = await listComponents();
  const index = components.findIndex((component) => component.slug === id);
  const previous = components[index - 1];
  const next = components[index + 1];
  const files = await getComponentSource(id);
  return /* @__PURE__ */ jsxs96(DocumentEntrance, { as: "article", className: "mx-auto max-w-3xl py-12", children: [
    /* @__PURE__ */ jsxs96("nav", { className: "text-xs text-muted-foreground", children: [
      /* @__PURE__ */ jsx140(link_default, { className: "underline underline-offset-4 hover:text-foreground", href: "/components", children: "Components" }),
      /* @__PURE__ */ jsx140("span", { className: "px-2", children: "/" }),
      /* @__PURE__ */ jsx140("span", { children: doc.title })
    ] }),
    /* @__PURE__ */ jsxs96("header", { className: "mt-4", children: [
      /* @__PURE__ */ jsx140("h1", { className: "text-3xl font-semibold tracking-tight", children: doc.title }),
      /* @__PURE__ */ jsx140("p", { className: "mt-2 text-base text-muted-foreground", children: doc.description })
    ] }),
    /* @__PURE__ */ jsx140("section", { className: "mt-8", "aria-label": "Live preview", children: /* @__PURE__ */ jsx140(PreviewFrame, { id: doc.slug }) }),
    /* @__PURE__ */ jsxs96("details", { className: "mt-4 rounded-lg border border-border p-4", children: [
      /* @__PURE__ */ jsx140("summary", { className: "cursor-pointer text-sm font-medium", children: "Component source" }),
      /* @__PURE__ */ jsx140("p", { className: "my-3 text-sm text-muted-foreground", children: "Installable source from the registry payload. See Usage below for examples." }),
      /* @__PURE__ */ jsx140("div", { className: "grid min-w-0 gap-4", children: files.map((file) => /* @__PURE__ */ jsx140(
        CodeFence,
        {
          title: file.path,
          source: file.content,
          language: file.path.endsWith("css") ? "css" : "tsx"
        },
        file.path
      )) })
    ] }),
    /* @__PURE__ */ jsx140("section", { className: "mt-4", children: /* @__PURE__ */ jsx140(Mdx, { source: doc.body, toc: true }) }),
    /* @__PURE__ */ jsxs96("footer", { className: "mt-12 grid gap-6 border-t border-border pt-6 text-sm", children: [
      /* @__PURE__ */ jsx140(
        "a",
        {
          className: "underline underline-offset-4",
          href: `https://github.com/Linruoxin-Sy/cadence-ui/edit/main/content/components/${doc.slug}.mdx`,
          children: "Edit this page"
        }
      ),
      /* @__PURE__ */ jsxs96("nav", { "aria-label": "Component pagination", className: "flex justify-between gap-4", children: [
        previous ? /* @__PURE__ */ jsxs96(link_default, { rel: "prev", href: `/components/${previous.slug}`, children: [
          "Previous: ",
          previous.title
        ] }) : /* @__PURE__ */ jsx140("span", {}),
        next && /* @__PURE__ */ jsxs96(link_default, { rel: "next", href: `/components/${next.slug}`, children: [
          "Next: ",
          next.title
        ] })
      ] })
    ] })
  ] });
}

// components/site/component-catalog.tsx
import { useEffect as useEffect21, useId as useId6, useRef as useRef20, useState as useState44 } from "react";
import { Fragment as Fragment41, jsx as jsx141, jsxs as jsxs97 } from "react/jsx-runtime";
var EMPTY2 = { q: "", category: "", intensity: "", complexity: "" };
var label = (value) => value === "ai" ? "AI" : value.charAt(0).toUpperCase() + value.slice(1);
function ComponentCatalog({ components }) {
  const [filters, setFilters] = useState44(EMPTY2);
  const [draft, setDraft] = useState44("");
  const [ready, setReady] = useState44(false);
  const [invalid, setInvalid] = useState44(false);
  const previousFocus = useRef20(null);
  const search = useRef20(null);
  const list = useRef20(null);
  const uid = useId6();
  const categories = [...new Set(components.flatMap((entry) => entry.categories))].sort();
  const choices = { category: categories, intensity: ["subtle", "medium", "expressive"], complexity: ["S", "M", "L"] };
  useEffect21(() => {
    const read = () => {
      previousFocus.current = document.activeElement;
      const params = new URLSearchParams(window.location.search);
      const next = { ...EMPTY2, q: params.get("q") ?? "" };
      let unknown = false;
      for (const key of ["category", "intensity", "complexity"]) {
        const value = params.get(key) ?? "";
        const valid = key === "category" ? components.some((entry) => entry.categories.includes(value)) : (key === "intensity" ? ["subtle", "medium", "expressive"] : ["S", "M", "L"]).includes(value);
        next[key] = valid ? value : "";
        unknown ||= Boolean(value && !valid);
      }
      setFilters(next);
      setDraft(next.q);
      setInvalid(unknown);
      setReady(true);
    };
    read();
    window.addEventListener("popstate", read);
    return () => window.removeEventListener("popstate", read);
  }, [components]);
  useEffect21(() => {
    if (previousFocus.current && list.current?.contains(previousFocus.current) && previousFocus.current.closest("[hidden]"))
      search.current?.focus();
  });
  const apply = (next) => {
    setFilters(next);
    setDraft(next.q);
    setInvalid(false);
    const url = new URL(window.location.href);
    for (const key of Object.keys(EMPTY2)) {
      if (next[key]) url.searchParams.set(key, next[key]);
      else url.searchParams.delete(key);
    }
    if (url.href !== window.location.href) window.history.pushState(window.history.state, "", url);
  };
  const matches = components.map((entry) => {
    const text = `${entry.slug} ${entry.title} ${entry.description}`.toLowerCase();
    return filters.q.toLowerCase().trim().split(/\s+/).every((word) => text.includes(word)) && (!filters.category || entry.categories.includes(filters.category)) && (!filters.intensity || entry.intensity === filters.intensity) && (!filters.complexity || entry.complexity === filters.complexity);
  });
  const count = matches.filter(Boolean).length;
  const control = "min-w-0 rounded-md border border-border bg-background px-3 py-2 text-sm";
  return /* @__PURE__ */ jsxs97(Fragment41, { children: [
    /* @__PURE__ */ jsx141(
      "form",
      {
        className: "mt-8",
        onSubmit: (event) => {
          event.preventDefault();
          apply({ ...filters, q: draft.trim() });
        },
        children: /* @__PURE__ */ jsxs97("fieldset", { disabled: !ready, className: "grid min-w-0 gap-4 sm:grid-cols-3", children: [
          /* @__PURE__ */ jsx141("legend", { className: "sr-only", children: "Filter components" }),
          /* @__PURE__ */ jsxs97("label", { className: "grid gap-1 text-sm sm:col-span-3", htmlFor: `${uid}-search`, children: [
            "Search components",
            /* @__PURE__ */ jsx141(
              "input",
              {
                ref: search,
                id: `${uid}-search`,
                type: "search",
                className: control,
                value: draft,
                onChange: (event) => setDraft(event.target.value)
              }
            )
          ] }),
          ["category", "intensity", "complexity"].map((key) => /* @__PURE__ */ jsxs97("label", { className: "grid gap-1 text-sm", htmlFor: `${uid}-${key}`, children: [
            label(key),
            /* @__PURE__ */ jsxs97(
              "select",
              {
                id: `${uid}-${key}`,
                className: control,
                value: filters[key],
                onChange: (event) => apply({ ...filters, [key]: event.target.value }),
                children: [
                  /* @__PURE__ */ jsxs97("option", { value: "", children: [
                    "All ",
                    key === "category" ? "categories" : key === "intensity" ? "intensities" : "complexities"
                  ] }),
                  choices[key].map((value) => /* @__PURE__ */ jsx141("option", { value, children: label(value) }, value))
                ]
              }
            )
          ] }, key)),
          /* @__PURE__ */ jsxs97("div", { className: "flex gap-3 sm:col-span-3", children: [
            /* @__PURE__ */ jsx141("button", { className: control, type: "submit", children: "Search" }),
            /* @__PURE__ */ jsx141("button", { className: control, type: "button", onClick: () => apply(EMPTY2), children: "Clear filters" })
          ] })
        ] })
      }
    ),
    /* @__PURE__ */ jsx141("noscript", { children: /* @__PURE__ */ jsx141("p", { className: "mt-3 text-sm", children: "Enable JavaScript to filter. All components are listed below." }) }),
    /* @__PURE__ */ jsxs97("p", { className: "mt-4 text-sm text-muted-foreground", role: "status", children: [
      count,
      " of ",
      components.length,
      " components",
      invalid ? ". Unknown filter ignored; showing matching components." : ""
    ] }),
    count === 0 && /* @__PURE__ */ jsx141("p", { className: "py-8", children: "No components match. Try another search or clear filters." }),
    /* @__PURE__ */ jsx141("div", { ref: list, "data-catalog-results": true, className: "mt-6 divide-y divide-border border-y border-border", children: components.map((entry, index) => /* @__PURE__ */ jsx141("div", { hidden: !matches[index], children: /* @__PURE__ */ jsxs97(
      link_default,
      {
        href: `/components/${entry.slug}`,
        className: "group flex flex-col gap-2 py-5 sm:flex-row sm:items-center sm:justify-between",
        children: [
          /* @__PURE__ */ jsxs97("div", { children: [
            /* @__PURE__ */ jsxs97("h2", { className: "text-sm font-semibold group-hover:underline", children: [
              entry.title,
              " ",
              /* @__PURE__ */ jsx141("span", { className: "font-mono text-xs text-muted-foreground", children: entry.complexity })
            ] }),
            /* @__PURE__ */ jsx141("p", { className: "mt-1 max-w-2xl text-sm text-muted-foreground", children: entry.description })
          ] }),
          /* @__PURE__ */ jsxs97("div", { className: "flex shrink-0 flex-wrap gap-2 text-xs text-muted-foreground", children: [
            /* @__PURE__ */ jsx141("span", { children: entry.categories.map(label).join(", ") }),
            /* @__PURE__ */ jsxs97("span", { children: [
              "\xB7 ",
              entry.intensity
            ] })
          ] })
        ]
      }
    ) }, entry.slug)) })
  ] });
}

// app/(site)/components/page.tsx
import { jsx as jsx142, jsxs as jsxs98 } from "react/jsx-runtime";
async function ComponentsPage() {
  const components = await listComponents();
  return /* @__PURE__ */ jsxs98("div", { className: "mx-auto max-w-3xl py-12", children: [
    /* @__PURE__ */ jsx142("h1", { className: "text-3xl font-semibold tracking-tight", children: "Components" }),
    /* @__PURE__ */ jsxs98("p", { className: "mt-3 max-w-2xl text-sm text-muted-foreground", children: [
      components.length,
      " items, each shipping its source, its motion contract, and a reduced-motion branch. Install any of them with the shadcn CLI."
    ] }),
    /* @__PURE__ */ jsx142(
      ComponentCatalog,
      {
        components: components.map(({ slug, title, description, categories, intensity, complexity }) => ({
          slug,
          title,
          description,
          categories: categories ?? [],
          intensity,
          complexity
        }))
      }
    )
  ] });
}

// app/(site)/docs/page.tsx
import { jsx as jsx143, jsxs as jsxs99 } from "react/jsx-runtime";
async function DocsPage() {
  const guides = await listGuides();
  return /* @__PURE__ */ jsxs99("div", { className: "mx-auto max-w-3xl py-12", children: [
    /* @__PURE__ */ jsx143("h1", { className: "text-3xl font-semibold tracking-tight", children: "Documentation" }),
    /* @__PURE__ */ jsx143("p", { className: "mt-3 text-sm text-muted-foreground", children: "These guides cover the whole system. Each component page adds its own API and motion contract." }),
    /* @__PURE__ */ jsx143("div", { className: "mt-10 grid gap-4 sm:grid-cols-2", children: guides.map((guide) => /* @__PURE__ */ jsxs99(
      link_default,
      {
        href: `/docs/${guide.slug}`,
        className: "rounded-xl border border-border p-5 transition-colors hover:bg-muted/40",
        children: [
          /* @__PURE__ */ jsx143("h2", { className: "text-sm font-semibold", children: guide.title }),
          /* @__PURE__ */ jsx143("p", { className: "mt-2 text-sm text-muted-foreground", children: guide.description }),
          /* @__PURE__ */ jsxs99("p", { className: "mt-3 font-mono text-[11px] text-muted-foreground", children: [
            "/docs/",
            guide.slug
          ] })
        ]
      },
      guide.slug
    )) }),
    /* @__PURE__ */ jsx143("div", { className: "mt-12 rounded-xl border border-border bg-muted/30 p-5 text-sm text-muted-foreground", children: /* @__PURE__ */ jsxs99("p", { children: [
      "Looking for the machine-readable version? Every component is also a registry item and a markdown file:",
      " ",
      /* @__PURE__ */ jsx143(link_default, { className: "underline underline-offset-4 hover:text-foreground", href: "/r/registry.json", children: "/r/registry.json" }),
      ",",
      " ",
      /* @__PURE__ */ jsx143(link_default, { className: "underline underline-offset-4 hover:text-foreground", href: "/llms.txt", children: "/llms.txt" }),
      "."
    ] }) })
  ] });
}

// app/(site)/docs/[slug]/page.tsx
import { jsx as jsx144, jsxs as jsxs100 } from "react/jsx-runtime";
async function generateMetadata2({ params }) {
  const { slug } = await params;
  const guide = await getGuide(slug);
  if (!guide) return {};
  return { title: guide.title, description: guide.description };
}
async function GuidePage({ params }) {
  const { slug } = await params;
  const guide = await getGuide(slug);
  if (!guide) notFound();
  return /* @__PURE__ */ jsxs100(DocumentEntrance, { as: "article", className: "mx-auto max-w-3xl py-12", children: [
    /* @__PURE__ */ jsx144("h1", { className: "text-3xl font-semibold tracking-tight", children: guide.title }),
    /* @__PURE__ */ jsx144("p", { className: "mt-2 text-base text-muted-foreground", children: guide.description }),
    /* @__PURE__ */ jsx144("div", { className: "mt-8", children: /* @__PURE__ */ jsx144(Mdx, { source: guide.body }) })
  ] });
}

// app/page.tsx
import { jsx as jsx145, jsxs as jsxs101 } from "react/jsx-runtime";
var principles = [
  {
    title: "Same API as shadcn",
    body: "Exports, props, and data-slot values match upstream, so a component is a drop-in replacement rather than a parallel idea."
  },
  {
    title: "Motion with a reason",
    body: "Every animation explains a state change. Components that do not need motion stay still, and every tier has a written budget."
  },
  {
    title: "UI only, no validation",
    body: "Invalid state is rendered from aria-invalid, never computed. Rules, schemas, and form state stay in your code."
  }
];
async function HomePage() {
  const components = await listComponents();
  const featured = components.slice(0, 6);
  return /* @__PURE__ */ jsxs101("div", { className: "mx-auto max-w-6xl px-6", children: [
    /* @__PURE__ */ jsxs101("section", { className: "py-20 sm:py-28", children: [
      /* @__PURE__ */ jsx145("p", { className: "text-xs font-medium uppercase tracking-[0.2em] text-muted-foreground", children: "Animation-first \xB7 shadcn registry" }),
      /* @__PURE__ */ jsx145("h1", { className: "mt-4 max-w-3xl text-4xl font-semibold tracking-tight sm:text-5xl", children: "Every shadcn component, with motion that explains itself." }),
      /* @__PURE__ */ jsx145("p", { className: "mt-6 max-w-xl text-base text-muted-foreground", children: "Cadence mirrors shadcn's API and adds a motion contract: Base UI for behaviour, Tailwind CSS v4 for styling, Motion for animation, and a documented reduced-motion branch for every component." }),
      /* @__PURE__ */ jsx145("div", { className: "mt-8 max-w-md", children: /* @__PURE__ */ jsx145(PackageManagerFence, { source: "npx shadcn@latest add @cadence/button", size: "sm" }) }),
      /* @__PURE__ */ jsxs101("div", { className: "mt-4 flex gap-4 text-sm", children: [
        /* @__PURE__ */ jsx145(link_default, { className: "font-medium underline underline-offset-4", href: "/components", children: "Browse components" }),
        /* @__PURE__ */ jsx145(
          link_default,
          {
            className: "text-muted-foreground underline underline-offset-4 hover:text-foreground",
            href: "/docs/installation",
            children: "Installation"
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxs101("section", { "aria-labelledby": "components-heading", className: "pb-8", children: [
      /* @__PURE__ */ jsxs101("div", { className: "flex items-end justify-between gap-4", children: [
        /* @__PURE__ */ jsx145("h2", { id: "components-heading", className: "text-xl font-semibold tracking-tight", children: "Components" }),
        /* @__PURE__ */ jsxs101(
          link_default,
          {
            className: "text-sm text-muted-foreground underline underline-offset-4 hover:text-foreground",
            href: "/components",
            children: [
              "All ",
              components.length
            ]
          }
        )
      ] }),
      featured.length ? /* @__PURE__ */ jsx145("div", { className: "mt-6 grid gap-4 sm:grid-cols-2", children: featured.map((doc) => /* @__PURE__ */ jsxs101(
        link_default,
        {
          href: `/components/${doc.slug}`,
          className: "block h-full rounded-xl border border-border p-5 transition-colors hover:bg-muted/40",
          children: [
            /* @__PURE__ */ jsxs101("div", { className: "flex items-center justify-between gap-3", children: [
              /* @__PURE__ */ jsx145("h3", { className: "text-sm font-semibold", children: doc.title }),
              /* @__PURE__ */ jsx145("span", { className: "rounded-full border border-border px-2 py-0.5 text-[11px] text-muted-foreground", children: doc.tier ?? doc.intensity ?? "T0" })
            ] }),
            /* @__PURE__ */ jsx145("p", { className: "mt-2 text-sm text-muted-foreground", children: doc.description }),
            /* @__PURE__ */ jsx145("p", { className: "mt-3 font-mono text-[11px] text-muted-foreground", children: doc.slug })
          ]
        },
        doc.slug
      )) }) : /* @__PURE__ */ jsxs101("p", { className: "mt-6 rounded-xl border border-dashed border-border p-6 text-sm text-muted-foreground", children: [
        "The parity rebuild starts with ",
        /* @__PURE__ */ jsx145("code", { className: "font-mono", children: "button" }),
        " and",
        " ",
        /* @__PURE__ */ jsx145("code", { className: "font-mono", children: "dialog" }),
        "."
      ] })
    ] }),
    /* @__PURE__ */ jsxs101("section", { "aria-labelledby": "principles-heading", className: "py-16", children: [
      /* @__PURE__ */ jsx145("h2", { id: "principles-heading", className: "text-xl font-semibold tracking-tight", children: "How it stays coherent" }),
      /* @__PURE__ */ jsx145("div", { className: "mt-6 grid gap-4 sm:grid-cols-3", children: principles.map((principle) => /* @__PURE__ */ jsxs101("div", { className: "h-full rounded-xl border border-border p-5", children: [
        /* @__PURE__ */ jsx145("h3", { className: "text-sm font-semibold", children: principle.title }),
        /* @__PURE__ */ jsx145("p", { className: "mt-2 text-sm text-muted-foreground", children: principle.body })
      ] }, principle.title)) })
    ] }),
    /* @__PURE__ */ jsxs101("section", { className: "rounded-2xl border border-border bg-muted/30 p-8", children: [
      /* @__PURE__ */ jsx145("h2", { className: "text-xl font-semibold tracking-tight", children: "Install one, get the system" }),
      /* @__PURE__ */ jsxs101("p", { className: "mt-2 max-w-xl text-sm text-muted-foreground", children: [
        "Every item pulls in the motion presets, the",
        " ",
        /* @__PURE__ */ jsx145("code", { className: "rounded border border-border bg-background px-1 py-0.5 font-mono text-xs", children: "cn" }),
        " helper, and the optional provider. No runtime package, no global CSS, no lock-in."
      ] }),
      /* @__PURE__ */ jsx145("div", { className: "mt-5 max-w-md", children: /* @__PURE__ */ jsx145(PackageManagerFence, { source: "npx shadcn@latest add @cadence/cadence-theme", size: "sm" }) })
    ] })
  ] });
}

// .cache/button-route-prototype/references.jsx
var references = { PrototypeLink, ComponentCatalog, MotionModeProvider, MotionModeSwitch, MotionSpeedSelect, PackageManagerProvider, ThemeToggle, Sidebar, DocumentEntrance, PreviewFrame, PackageManagerBlock, CodeBlock, CodeBlockHeader, CodeBlockTitle, CodeBlockActions, CodeBlockCopyButton, CodeBlockContent, CodeBlockLine };

// .cache/button-route-prototype/codec.jsx
import { createElement as createElement2, Fragment as Fragment42 } from "react";
function decode(value) {
  if (Array.isArray(value)) return value.map(decode);
  if (!value || typeof value !== "object") return value;
  if (value.$element) {
    const [type, props, key] = value.$element;
    return createElement2(type === "$fragment" ? Fragment42 : references[type] || type, { ...decode(props), key });
  }
  return Object.fromEntries(Object.entries(value).map(([key, v]) => [key, decode(v)]));
}

// .cache/button-route-prototype/server.jsx
var ids = new Map(Object.entries(references).map(([k, v]) => [v, k]));
async function encode(value) {
  if (value == null || typeof value !== "object" && typeof value !== "function") return value;
  if (Array.isArray(value)) return Promise.all(value.map(encode));
  if (isValidElement5(value)) {
    const { type, props, key } = value;
    if (typeof type === "function" && !ids.has(type)) return encode(await type(props));
    const name = type === Fragment43 ? "$fragment" : ids.get(type) || type;
    if (typeof name !== "string") throw Error("Unsupported server element " + String(type));
    return { $element: [name, await encode(props), key] };
  }
  if (typeof value === "function") throw Error("Function crossed server boundary");
  return Object.fromEntries(await Promise.all(Object.entries(value).map(async ([k, v]) => [k, await encode(v)])));
}
async function generate(pathname = "/components/button") {
  globalThis.__prototypePath = pathname;
  let page = pathname === "/components" ? createElement3(ComponentsPage) : pathname === "/docs" ? createElement3(DocsPage) : pathname.startsWith("/docs/") ? createElement3(GuidePage, { params: Promise.resolve({ slug: pathname.split("/")[2] }) }) : pathname === "/" ? createElement3(HomePage) : createElement3(ComponentPage, { params: Promise.resolve({ id: pathname.split("/")[2] }) });
  const tree = await encode(createElement3(RootLayout, null, pathname === "/" ? page : createElement3(SiteLayout, null, page)));
  const head = tree.$element[1].children[0];
  const metadata2 = pathname.startsWith("/components/") ? await generateMetadata({ params: Promise.resolve({ id: pathname.split("/")[2] }) }) : pathname.startsWith("/docs/") ? await generateMetadata2({ params: Promise.resolve({ slug: pathname.split("/")[2] }) }) : { title: pathname === "/components" ? "Components" : pathname === "/docs" ? "Docs" : "Cadence UI \u2014 animation-first components for shadcn" };
  head.$element[1].children.push({ $element: ["title", { children: pathname === "/" ? metadata2.title : metadata2.title + " \xB7 Cadence UI" }, null] });
  if (metadata2.description) head.$element[1].children.push({ $element: ["meta", { name: "description", content: metadata2.description }, null] });
  for (const [property, content] of Object.entries({ "og:title": metadata.openGraph.title, "og:description": metadata.openGraph.description, "og:type": metadata.openGraph.type })) head.$element[1].children.push({ $element: ["meta", { property, content }, null] });
  for (const [name, content] of Object.entries({ "twitter:card": "summary", "twitter:title": metadata.openGraph.title, "twitter:description": metadata.openGraph.description })) head.$element[1].children.push({ $element: ["meta", { name, content }, null] });
  head.$element[1].children.unshift({ $element: ["meta", { charSet: "utf-8" }, null] }, { $element: ["meta", { name: "viewport", content: "width=device-width, initial-scale=1" }, null] });
  head.$element[1].children.push({ $element: ["link", { rel: "stylesheet", href: "/prototype.css" }, null] });
  head.$element[1].children.push({ $element: ["script", { type: "module", src: "/client.js" }, null] });
  return { tree, html: "<!doctype html>" + renderToString(decode(tree)) };
}
export {
  generate
};
