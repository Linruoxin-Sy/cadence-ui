"use client";import{a as t,b as c,c as m,d as B,e as o,f as l,g as d,h as u,i as a,k as f,l as v}from"./chunk-WE4QMECV.js";import"./chunk-C6W2VDOB.js";import"./chunk-JSPAA4YA.js";import"./chunk-UTWWGTFK.js";import{a as C}from"./chunk-C7FEVX5V.js";import"./chunk-4HB2JVV5.js";import"./chunk-U2DFET4V.js";import{r as i}from"./chunk-HSIAVKBB.js";import"./chunk-LU4YRMIX.js";import"./chunk-K6YQSUJM.js";import"./chunk-B53KPZFM.js";import"./chunk-4CVBQZFG.js";import"./chunk-H7EDWM37.js";import{a as k}from"./chunk-ES3E5YRF.js";import"./chunk-MEQW4X44.js";import"./chunk-IN65WUR5.js";import"./chunk-4RJ76ICH.js";import{a as p}from"./chunk-NGNJTYLW.js";import{c as s}from"./chunk-OOJM4CTU.js";var e=s(p(),1),g=["default","destructive"],b=`export async function stream({ prompt, signal }: StreamOptions) {
  const response = await fetch("/api/chat", {
    method: "POST",
    body: JSON.stringify({ prompt }),
    signal,
  });

  if (!response.ok) throw new Error(await response.text());

  const reader = response.body?.pipeThrough(new TextDecoderStream());

  for await (const chunk of reader) {
    controller.enqueue(chunk);
    if (signal.aborted) break;
  }
};`,n={pnpm:"pnpm dlx shadcn@latest add @cadence/code-block",npm:"npx shadcn@latest add @cadence/code-block",yarn:"yarn dlx shadcn@latest add @cadence/code-block"};function P(){let{control:h,choose:r}=C("CodeBlock",g);return(0,e.jsxs)(e.Fragment,{children:[h,(0,e.jsx)(k,{children:(0,e.jsxs)("div",{className:"grid w-full max-w-xl gap-4",children:[(0,e.jsxs)(t,{maxLines:6,language:"tsx",variant:r("default"),children:[(0,e.jsxs)(c,{children:[(0,e.jsxs)(m,{children:[(0,e.jsx)(i,{}),"app/api/chat/route.ts"]}),(0,e.jsx)(l,{children:(0,e.jsx)(d,{value:b})})]}),(0,e.jsx)(u,{lineNumbers:!0,children:b}),(0,e.jsx)(f,{className:"justify-center",children:(0,e.jsx)(v,{})})]}),(0,e.jsxs)(t,{defaultTab:"pnpm",language:"bash",variant:r("default"),children:[(0,e.jsxs)(c,{children:[(0,e.jsxs)(B,{label:"Package manager",children:[(0,e.jsx)(o,{value:"pnpm",children:"pnpm"}),(0,e.jsx)(o,{value:"npm",children:"npm"}),(0,e.jsx)(o,{value:"yarn",children:"yarn"})]}),(0,e.jsx)(l,{children:(0,e.jsx)(d,{values:n})})]}),(0,e.jsx)(a,{value:"pnpm",children:n.pnpm}),(0,e.jsx)(a,{value:"npm",children:n.npm}),(0,e.jsx)(a,{value:"yarn",children:n.yarn})]})]})})]})}export{P as CodeBlockPreview};
