function n(i,e){return{x:i.left-e.left,y:i.top-e.top,scaleX:e.width>0?i.width/e.width:1,scaleY:e.height>0?i.height/e.height:1}}function t(i,e){return Math.max(i,e)}export{n as a,t as b};
