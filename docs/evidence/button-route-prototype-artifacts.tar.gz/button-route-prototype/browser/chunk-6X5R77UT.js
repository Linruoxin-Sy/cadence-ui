import{e as r}from"./chunk-H7EDWM37.js";function n(e){return r(19)?e:e?"true":void 0}export{n as a};
