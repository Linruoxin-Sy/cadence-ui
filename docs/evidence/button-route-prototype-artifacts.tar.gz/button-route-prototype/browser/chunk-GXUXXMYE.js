import{j as n}from"./chunk-H7EDWM37.js";function r(e){return n(e.defaultTagName??"div",e,e)}export{r as a};
