import{a as n}from"./chunk-4RJ76ICH.js";import{c as e}from"./chunk-OOJM4CTU.js";var t=e(n(),1),o=t.createContext(void 0);function i(){return t.useContext(o)?.direction??"ltr"}export{i as a};
