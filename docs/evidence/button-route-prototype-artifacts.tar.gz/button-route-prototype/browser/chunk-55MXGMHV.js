import{b as e}from"./chunk-XGHEKHWF.js";function r(u){return e(u,"base-ui")}export{r as a};
