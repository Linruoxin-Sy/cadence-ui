import{g as t}from"./chunk-H7EDWM37.js";import{a as f}from"./chunk-4RJ76ICH.js";import{c}from"./chunk-OOJM4CTU.js";var e=c(f(),1);function r(o){e.useEffect(o,t)}export{r as a};
