import{a as t}from"./chunk-55MXGMHV.js";import{b as r}from"./chunk-4CVBQZFG.js";function s(u,o){let e=t(u);return r(()=>(o(e),()=>{o(i=>i===e?void 0:i)}),[e,o]),e}export{s as a};
