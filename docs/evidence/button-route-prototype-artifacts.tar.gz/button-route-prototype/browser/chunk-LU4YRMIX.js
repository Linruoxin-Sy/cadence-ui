function e(o){return o?.ownerDocument||document}export{e as a};
