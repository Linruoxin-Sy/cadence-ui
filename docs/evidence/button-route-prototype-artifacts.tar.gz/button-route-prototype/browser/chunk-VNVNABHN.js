import{a as o}from"./chunk-4RJ76ICH.js";import{c as t}from"./chunk-OOJM4CTU.js";var e=t(o(),1),n=e.createContext({disabled:!1});function i(){return e.useContext(n)}export{n as a,i as b};
