import { createElement, Fragment } from "react";
import { references } from "./references";
export function decode(value) {
 if (Array.isArray(value)) return value.map(decode);
 if (!value || typeof value !== "object") return value;
 if (value.$element) { const [type, props, key] = value.$element;
   return createElement(type === "$fragment" ? Fragment : references[type] || type, { ...decode(props), key }); }
 return Object.fromEntries(Object.entries(value).map(([key,v])=>[key,decode(v)]));
}