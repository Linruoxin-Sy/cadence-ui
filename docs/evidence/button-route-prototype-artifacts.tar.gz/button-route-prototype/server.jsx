import {createElement, isValidElement, Fragment} from "react";
import {renderToString} from "react-dom/server";
import Root, {metadata as rootMetadata} from "../../app/layout";
import Layout from "../../app/(site)/layout";
import Page, {generateMetadata as componentMetadata} from "../../app/(site)/components/[id]/page";
import Catalog from "../../app/(site)/components/page";
import Docs from "../../app/(site)/docs/page";
import Guide, {generateMetadata as guideMetadata} from "../../app/(site)/docs/[slug]/page";
import Home from "../../app/page";
import {references} from "./references";
import {decode} from "./codec";
const ids=new Map(Object.entries(references).map(([k,v])=>[v,k]));
async function encode(value){
 if (value == null || typeof value !== "object" && typeof value !== "function") return value;
 if(Array.isArray(value)) return Promise.all(value.map(encode));
 if(isValidElement(value)) {
  const {type,props,key}=value;
  if(typeof type === "function" && !ids.has(type)) return encode(await type(props));
  const name=type===Fragment?"$fragment":ids.get(type)||type;
  if(typeof name!=="string") throw Error("Unsupported server element "+String(type));
  return {$element:[name,await encode(props),key]};
 }
 if(typeof value==="function") throw Error("Function crossed server boundary");
 return Object.fromEntries(await Promise.all(Object.entries(value).map(async([k,v])=>[k,await encode(v)])));
}
export async function generate(pathname="/components/button"){
 globalThis.__prototypePath=pathname;
 let page=pathname==="/components"?createElement(Catalog):pathname==="/docs"?createElement(Docs):pathname.startsWith("/docs/")?createElement(Guide,{params:Promise.resolve({slug:pathname.split("/")[2]})}):pathname==="/"?createElement(Home):createElement(Page,{params:Promise.resolve({id:pathname.split("/")[2]})});
 const tree=await encode(createElement(Root,null,pathname==="/"?page:createElement(Layout,null,page)));
 const head=tree.$element[1].children[0];
 const metadata=pathname.startsWith("/components/")?await componentMetadata({params:Promise.resolve({id:pathname.split("/")[2]})}):pathname.startsWith("/docs/")?await guideMetadata({params:Promise.resolve({slug:pathname.split("/")[2]})}):{title:pathname==="/components"?"Components":pathname==="/docs"?"Docs":"Cadence UI — animation-first components for shadcn"};
 head.$element[1].children.push({$element:["title",{children:pathname==="/"?metadata.title:metadata.title+" · Cadence UI"},null]});
 if(metadata.description)head.$element[1].children.push({$element:["meta",{name:"description",content:metadata.description},null]});
 for(const [property,content]of Object.entries({"og:title":rootMetadata.openGraph.title,"og:description":rootMetadata.openGraph.description,"og:type":rootMetadata.openGraph.type}))head.$element[1].children.push({$element:["meta",{property,content},null]});
 for(const [name,content]of Object.entries({"twitter:card":"summary","twitter:title":rootMetadata.openGraph.title,"twitter:description":rootMetadata.openGraph.description}))head.$element[1].children.push({$element:["meta",{name,content},null]});
 head.$element[1].children.unshift({$element:["meta",{charSet:"utf-8"},null]},{$element:["meta",{name:"viewport",content:"width=device-width, initial-scale=1"},null]});
 head.$element[1].children.push({$element:["link",{rel:"stylesheet",href:"/prototype.css"},null]});
 head.$element[1].children.push({$element:["script",{type:"module",src:"/client.js"},null]});
 return {tree,html:"<!doctype html>"+renderToString(decode(tree))};
}