import {useSyncExternalStore} from "react";
export function usePathname(){return useSyncExternalStore(fn=>{window.addEventListener("prototype-navigation",fn);return ()=>window.removeEventListener("prototype-navigation",fn);},()=>location.pathname,()=>globalThis.__prototypePath || "/components/button");}
export function notFound(){throw Error("Not found");}