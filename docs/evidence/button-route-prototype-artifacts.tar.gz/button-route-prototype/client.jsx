import { hydrateRoot } from "react-dom/client";
import {decode} from "./codec";
import {previews} from "../../components/site/previews";
async function preload(path){const id=path.split("?")[0].split("/")[2];await previews[id]?.preload();}
await preload(location.pathname);
const tree = await fetch("/prototype-tree.json?path="+encodeURIComponent(location.pathname)).then(r=>r.json());
window.__hydrationErrors=[];
const root=hydrateRoot(document, decode(tree), {onRecoverableError(e){window.__hydrationErrors.push(e.message);console.error(e);}});
let serial=0;
window.__navigate=async(href,replace=false,scroll=true,history=true)=>{const current=++serial;const url=new URL(href,location.href);await preload(url.pathname);const next=await fetch("/prototype-tree.json?path="+encodeURIComponent(url.pathname)).then(r=>{if(!r.ok)throw Error("Route "+r.status);return r.json();});if(current!==serial)return;if(history)window.history[replace?"replaceState":"pushState"](null,"",url);root.render(decode(next));window.dispatchEvent(new Event("prototype-navigation"));if(scroll)window.scrollTo(0,0);};
window.addEventListener("popstate",()=>window.__navigate(location.href,false,false,false));
window.__prototypeReady=true;